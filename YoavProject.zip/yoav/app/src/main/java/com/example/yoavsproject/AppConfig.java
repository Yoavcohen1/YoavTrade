package com.example.yoavsproject;

import androidx.annotation.NonNull;

import java.util.ArrayList;
import java.util.List;

public final class AppConfig {

    private AppConfig() {
    }

    public static final String PROJECT_NAME = BuildConfig.PROJECT_NAME;
    public static final String PROJECT_PACKAGE = BuildConfig.PROJECT_PACKAGE;

    public static final String ALPHA_VANTAGE_HOST = "alpha-vantage.p.rapidapi.com";
    public static final String CURRENCY_HOST = "currency-conversion-and-exchange-rates.p.rapidapi.com";
    public static final String NEWS_HOST = "real-time-news-data.p.rapidapi.com";

    public static final String ALPHA_VANTAGE_BASE_URL = "https://alpha-vantage.p.rapidapi.com";
    public static final String CURRENCY_BASE_URL = "https://currency-conversion-and-exchange-rates.p.rapidapi.com";
    public static final String NEWS_BASE_URL = "https://real-time-news-data.p.rapidapi.com";

    public static final String GEMINI_BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models/";

    public static final String GEMINI_MODEL_PRIMARY = "gemini-2.5-flash";
    public static final String GEMINI_MODEL_BACKUP_1 = "gemini-2.0-flash";
    public static final String GEMINI_MODEL_BACKUP_2 = "gemini-2.0-flash-001";

    public static final String FIREBASE_PROJECT_ID = BuildConfig.FIREBASE_PROJECT_ID;
    public static final String FIREBASE_WEB_API_KEY = BuildConfig.FIREBASE_WEB_API_KEY;
    public static final String FIREBASE_APP_ID = BuildConfig.FIREBASE_APP_ID;
    public static final String FIREBASE_STORAGE_BUCKET = BuildConfig.FIREBASE_STORAGE_BUCKET;
    public static final String FIREBASE_DATABASE_URL = BuildConfig.FIREBASE_DATABASE_URL;

    @NonNull
    public static String[] getAlphaVantageKeys() {
        return cleanKeys(new String[]{
                BuildConfig.RAPIDAPI_ALPHA_KEY_1,
                BuildConfig.RAPIDAPI_ALPHA_KEY_2,
                BuildConfig.RAPIDAPI_ALPHA_KEY_3,
                BuildConfig.RAPIDAPI_ALPHA_KEY_4,
                BuildConfig.RAPIDAPI_ALPHA_KEY_5,
                BuildConfig.RAPIDAPI_ALPHA_KEY_6,

                
                BuildConfig.RAPIDAPI_KEY
        });
    }

    @NonNull
    public static String[] getCurrencyKeys() {
        return cleanKeys(new String[]{
                BuildConfig.RAPIDAPI_CURRENCY_KEY_1,
                BuildConfig.RAPIDAPI_CURRENCY_KEY_2,
                BuildConfig.RAPIDAPI_CURRENCY_KEY_3,
                BuildConfig.RAPIDAPI_CURRENCY_KEY_4,
                BuildConfig.RAPIDAPI_CURRENCY_KEY_5,
                BuildConfig.RAPIDAPI_CURRENCY_KEY_6,

                
                BuildConfig.RAPIDAPI_KEY
        });
    }

    @NonNull
    public static String[] getNewsKeys() {
        return cleanKeys(new String[]{
                BuildConfig.RAPIDAPI_NEWS_KEY_1,
                BuildConfig.RAPIDAPI_NEWS_KEY_2,
                BuildConfig.RAPIDAPI_NEWS_KEY_3,
                BuildConfig.RAPIDAPI_NEWS_KEY_4,
                BuildConfig.RAPIDAPI_NEWS_KEY_5,
                BuildConfig.RAPIDAPI_NEWS_KEY_6,

                
                BuildConfig.RAPIDAPI_KEY
        });
    }

    @NonNull
    public static String[] getGeminiKeys() {
        return cleanKeys(new String[]{
                BuildConfig.GEMINI_API_KEY_1,
                BuildConfig.GEMINI_API_KEY_2,
                BuildConfig.GEMINI_API_KEY_3,
                BuildConfig.GEMINI_API_KEY_4,
                BuildConfig.GEMINI_API_KEY_5,
                BuildConfig.GEMINI_API_KEY_6,
                BuildConfig.GEMINI_API_KEY_7,

                
                BuildConfig.GEMINI_API_KEY
        });
    }

    @NonNull
    public static String[] getGeminiModels() {
        return new String[]{
                GEMINI_MODEL_PRIMARY,
                GEMINI_MODEL_BACKUP_1,
                GEMINI_MODEL_BACKUP_2
        };
    }

    @NonNull
    public static String getDefaultRapidApiKey() {
        String[] keys = getAlphaVantageKeys();
        return keys.length == 0 ? "" : keys[0];
    }

    @NonNull
    public static String getDefaultGeminiKey() {
        String[] keys = getGeminiKeys();
        return keys.length == 0 ? "" : keys[0];
    }

    public static boolean hasGeminiKeys() {
        return getGeminiKeys().length > 0;
    }

    public static boolean hasAlphaVantageKeys() {
        return getAlphaVantageKeys().length > 0;
    }

    public static boolean hasCurrencyKeys() {
        return getCurrencyKeys().length > 0;
    }

    public static boolean hasNewsKeys() {
        return getNewsKeys().length > 0;
    }

    @NonNull
    private static String[] cleanKeys(@NonNull String[] rawKeys) {
        List<String> result = new ArrayList<>();

        for (String key : rawKeys) {
            if (key == null) {
                continue;
            }

            String clean = key.trim();

            if (clean.isEmpty()) {
                continue;
            }

            if (clean.equalsIgnoreCase("null")) {
                continue;
            }

            if (clean.contains("PASTE_")) {
                continue;
            }

            if (result.contains(clean)) {
                continue;
            }

            result.add(clean);
        }

        return result.toArray(new String[0]);
    }
}
