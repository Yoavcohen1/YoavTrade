package com.example.yoavsproject;

import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ClipDescription;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.net.Uri;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Base64;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.DrawableRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.view.ContentInfoCompat;
import androidx.core.view.OnReceiveContentListener;
import androidx.core.view.ViewCompat;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseException;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.ListenerRegistration;

import com.bumptech.glide.Glide;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class GlobalChatActivity extends AppCompatActivity {

    private static final String CHAT_PATH = "GlobalChat";
    private static final String PRESENCE_PATH = "GlobalChatPresence";
    private static final String TYPING_PATH = "GlobalChatTyping";

    private static final int MAX_MESSAGES = 120;
    private static final int MAX_MESSAGE_LENGTH = 248;
    private static final int MAX_REPLY_PREVIEW_LENGTH = 90;
    private static final int REQUEST_PICK_GIF = 5107;
    private static final int MAX_GIF_BYTES = 2_500_000;

    private TextView btnBackChat;
    private TextView tvChatTitle;
    private TextView tvOnlineCount;
    private TextView tvTypingStatus;
    private RecyclerView recyclerGlobalChat;
    private EditText etMessage;
    private TextView btnSendMessage;

    private LinearLayout replyPreviewBar;
    private TextView tvReplyPreviewName;
    private TextView tvReplyPreviewText;
    private TextView btnCloseReplyPreview;
    private ChatMessage replyTarget;

    private FirebaseAuth auth;
    private FirebaseUser currentUser;
    private FirebaseFirestore firestore;

    private FirebaseDatabase database;
    private DatabaseReference chatRef;
    private DatabaseReference presenceRef;
    private DatabaseReference typingRef;
    private DatabaseReference connectedRef;

    private ValueEventListener connectedListener;
    private ValueEventListener messagesListener;
    private ValueEventListener presenceListener;
    private ValueEventListener typingListener;

    private ChatAdapter adapter;
    private final ArrayList<ChatMessage> messages = new ArrayList<>();
    private final Map<String, ChatUserProfile> profileCache = new HashMap<>();
    private final Map<String, ListenerRegistration> profileListeners = new HashMap<>();

    private String userId = "";
    private String username = "Trader";
    private String profilePhotoBase64 = "";
    private boolean profilePrivate = false;

    private String deviceId = "";
    private String sessionId = "";

    private boolean firebaseConnected = false;
    private boolean sending = false;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        AppSettingsManager.applySavedUi(this);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_global_chat);

        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        auth = FirebaseAuth.getInstance();
        currentUser = auth.getCurrentUser();
        firestore = FirebaseFirestore.getInstance();

        if (currentUser == null) {
            Toast.makeText(this, "Please sign in to use Global Chat", Toast.LENGTH_SHORT).show();
            openAuthChoice();
            return;
        }

        userId = currentUser.getUid();
        username = buildFallbackUsername(currentUser);

        deviceId = getSharedPreferences("global_chat_device", MODE_PRIVATE)
                .getString("device_id", "");

        if (deviceId == null || deviceId.trim().isEmpty()) {
            deviceId = UUID.randomUUID().toString();

            getSharedPreferences("global_chat_device", MODE_PRIVATE)
                    .edit()
                    .putString("device_id", deviceId)
                    .apply();
        }

        sessionId = deviceId + "_" + System.currentTimeMillis();

        bindViews();
        setupRecycler();
        setupDatabase();
        setupClicks();
        setupTypingWatcher();
        setupGifKeyboardInput();
        playChatOpenAnimation();
        loadUserProfileThenStart();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopTyping();
        removePresence();
        detachListeners();
    }

    private void bindViews() {
        btnBackChat = findViewById(R.id.btnBackChat);
        tvChatTitle = findViewById(R.id.tvChatTitle);
        tvOnlineCount = findViewById(R.id.tvOnlineCount);
        tvTypingStatus = findViewById(R.id.tvTypingStatus);
        recyclerGlobalChat = findViewById(R.id.recyclerGlobalChat);
        etMessage = findViewById(R.id.etMessage);
        btnSendMessage = findViewById(R.id.btnSendMessage);

        replyPreviewBar = findViewById(R.id.replyPreviewBar);
        tvReplyPreviewName = findViewById(R.id.tvReplyPreviewName);
        tvReplyPreviewText = findViewById(R.id.tvReplyPreviewText);
        btnCloseReplyPreview = findViewById(R.id.btnCloseReplyPreview);
    }

    private void setupRecycler() {
        adapter = new ChatAdapter();

        if (recyclerGlobalChat != null) {
            LinearLayoutManager manager = new LinearLayoutManager(this);
            manager.setStackFromEnd(true);

            recyclerGlobalChat.setLayoutManager(manager);
            recyclerGlobalChat.setAdapter(adapter);
            recyclerGlobalChat.setItemAnimator(null);
            recyclerGlobalChat.setClipToPadding(false);
            recyclerGlobalChat.setOverScrollMode(View.OVER_SCROLL_NEVER);

            setupSwipeToReply();
        }
    }

    private void setupSwipeToReply() {
        ItemTouchHelper helper = new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(
                    @NonNull RecyclerView recyclerView,
                    @NonNull RecyclerView.ViewHolder viewHolder,
                    @NonNull RecyclerView.ViewHolder target
            ) {
                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                int position = viewHolder.getBindingAdapterPosition();

                if (position != RecyclerView.NO_POSITION && position < messages.size()) {
                    startReplyTo(messages.get(position));
                    adapter.notifyItemChanged(position);
                }
            }

            @Override
            public float getSwipeThreshold(@NonNull RecyclerView.ViewHolder viewHolder) {
                return 0.22f;
            }

            @Override
            public float getSwipeEscapeVelocity(float defaultValue) {
                return defaultValue * 3.5f;
            }

            @Override
            public void onChildDraw(
                    @NonNull Canvas c,
                    @NonNull RecyclerView recyclerView,
                    @NonNull RecyclerView.ViewHolder viewHolder,
                    float dX,
                    float dY,
                    int actionState,
                    boolean isCurrentlyActive
            ) {
                float limitedDx = Math.min(dX, dp(92));
                super.onChildDraw(c, recyclerView, viewHolder, limitedDx, dY, actionState, isCurrentlyActive);
            }
        });

        helper.attachToRecyclerView(recyclerGlobalChat);
    }

    private void setupDatabase() {
        String url = AppConfig.FIREBASE_DATABASE_URL == null
                ? ""
                : AppConfig.FIREBASE_DATABASE_URL.trim();

        try {
            if (!url.isEmpty()) {
                database = FirebaseDatabase.getInstance(url);
            } else {
                database = FirebaseDatabase.getInstance();
            }
        } catch (DatabaseException e) {
            database = FirebaseDatabase.getInstance();
        }

        chatRef = database.getReference(CHAT_PATH);
        presenceRef = database.getReference(PRESENCE_PATH);
        typingRef = database.getReference(TYPING_PATH);
        connectedRef = database.getReference(".info/connected");
    }

    private void setupClicks() {
        if (btnBackChat != null) {
            btnBackChat.setOnClickListener(v -> finish());
        }

        if (btnSendMessage != null) {
            btnSendMessage.setOnClickListener(v -> sendMessage());
        }


        if (btnCloseReplyPreview != null) {
            btnCloseReplyPreview.setOnClickListener(v -> clearReplyTarget());
        }

        if (etMessage != null) {
            etMessage.setOnEditorActionListener((v, actionId, event) -> {
                boolean imeSend = actionId == EditorInfo.IME_ACTION_SEND;
                boolean enterDown = event != null
                        && event.getKeyCode() == KeyEvent.KEYCODE_ENTER
                        && event.getAction() == KeyEvent.ACTION_DOWN;

                if (imeSend && etMessage.getText() != null && etMessage.getText().toString().trim().length() > 0) {
                    sendMessage();
                    return true;
                }

                if (enterDown && actionId == EditorInfo.IME_NULL) {
                    return false;
                }

                return false;
            });
        }
    }

    private void setupTypingWatcher() {
        if (etMessage == null) {
            return;
        }

        etMessage.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                
                updateSendButtonState();
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        updateSendButtonState();
    }


    private void setupGifKeyboardInput() {
        if (etMessage == null) {
            return;
        }

        try {
            ViewCompat.setOnReceiveContentListener(
                    etMessage,
                    new String[]{"image/gif", "image/*"},
                    new OnReceiveContentListener() {
                        @Override
                        public ContentInfoCompat onReceiveContent(@NonNull View view, @NonNull ContentInfoCompat payload) {
                            ClipData clip = payload.getClip();

                            if (clip == null || clip.getItemCount() <= 0) {
                                return payload;
                            }

                            boolean handled = false;

                            for (int i = 0; i < clip.getItemCount(); i++) {
                                ClipData.Item item = clip.getItemAt(i);

                                if (item == null || item.getUri() == null) {
                                    continue;
                                }

                                Uri uri = item.getUri();

                                if (isGifUri(uri, clip.getDescription())) {
                                    sendGifMessage(uri);
                                    handled = true;
                                    break;
                                }
                            }

                            return handled ? null : payload;
                        }
                    }
            );
        } catch (Exception ignored) {
        }
    }

    private boolean isGifUri(@NonNull Uri uri, @Nullable ClipDescription description) {
        try {
            String mime = getContentResolver().getType(uri);

            if (mime != null && mime.toLowerCase(Locale.US).contains("gif")) {
                return true;
            }

            if (description != null) {
                for (int i = 0; i < description.getMimeTypeCount(); i++) {
                    String type = description.getMimeType(i);

                    if (type != null && type.toLowerCase(Locale.US).contains("gif")) {
                        return true;
                    }
                }
            }
        } catch (Exception ignored) {
        }

        return false;
    }

    private void playChatOpenAnimation() {
        View header = findViewById(R.id.chatHeaderCard);
        View inputCard = findViewById(R.id.messageComposerCard);

        animateIn(header, 0, -12);
        animateIn(recyclerGlobalChat, 100, 22);
        animateIn(inputCard, 180, 18);
    }

    private void animateIn(View view, long delay, int translationYDp) {
        if (view == null) {
            return;
        }

        view.setAlpha(0f);
        view.setTranslationY(dp(translationYDp));
        view.animate()
                .alpha(1f)
                .translationY(0f)
                .setStartDelay(delay)
                .setDuration(430)
                .setInterpolator(new DecelerateInterpolator())
                .start();
    }

    private void loadUserProfileThenStart() {
        try {
            username = firstNonEmpty(
                    AppSettingsManager.getLocalDisplayName(this),
                    ProfilePrefs.getDisplayName(this),
                    buildFallbackUsername(currentUser)
            );

            profilePhotoBase64 = firstNonEmpty(
                    AppSettingsManager.getLocalProfilePhotoBase64(this),
                    ProfilePrefs.getPhotoBase64(this),
                    ""
            );

            profilePrivate = ProfilePrefs.isProfilePrivate(this);
        } catch (Exception ignored) {
        }

        updateHeaderConnecting();

        firestore.collection("users")
                .document(userId)
                .get()
                .addOnSuccessListener(snapshot -> {
                    username = firstNonEmpty(
                            snapshot.getString("displayName"),
                            snapshot.getString("fullName"),
                            snapshot.getString("username"),
                            username,
                            "Trader"
                    );

                    profilePhotoBase64 = firstNonEmpty(
                            snapshot.getString("profilePhotoBase64"),
                            snapshot.getString("photoBase64"),
                            snapshot.getString("profileImageBase64"),
                            profilePhotoBase64,
                            ""
                    );

                    profilePrivate = readProfilePrivate(snapshot, profilePrivate);

                    syncProfilePhotoToFirestoreIfNeeded(snapshot);

                    startRealtimeChat();
                })
                .addOnFailureListener(e -> startRealtimeChat());
    }

    private boolean readProfilePrivate(DocumentSnapshot snapshot, boolean fallback) {
        if (snapshot == null) {
            return fallback;
        }

        Boolean profilePrivateValue = snapshot.getBoolean("profilePrivate");
        if (profilePrivateValue != null) {
            return profilePrivateValue;
        }

        Boolean privateProfileValue = snapshot.getBoolean("privateProfile");
        if (privateProfileValue != null) {
            return privateProfileValue;
        }

        Boolean isPrivateValue = snapshot.getBoolean("isPrivate");
        if (isPrivateValue != null) {
            return isPrivateValue;
        }

        String privacy = firstNonEmpty(
                snapshot.getString("privacy"),
                snapshot.getString("profilePrivacy"),
                snapshot.getString("privacyMode")
        );

        if (!privacy.isEmpty()) {
            String normalized = privacy.trim().toLowerCase(Locale.US);
            return normalized.equals("private") || normalized.equals("privacy_private");
        }

        return fallback;
    }

    private void syncProfilePhotoToFirestoreIfNeeded(DocumentSnapshot snapshot) {
        try {
            if (firestore == null || userId == null || userId.trim().isEmpty()) {
                return;
            }

            String localPhoto = firstNonEmpty(
                    profilePhotoBase64,
                    AppSettingsManager.getLocalProfilePhotoBase64(this),
                    ProfilePrefs.getPhotoBase64(this),
                    ""
            );

            if (localPhoto.isEmpty()) {
                return;
            }

            String firestorePhoto = "";
            if (snapshot != null) {
                firestorePhoto = firstNonEmpty(
                        snapshot.getString("profilePhotoBase64"),
                        snapshot.getString("photoBase64"),
                        snapshot.getString("profileImageBase64"),
                        ""
                );
            }

            if (!firestorePhoto.isEmpty()) {
                return;
            }

            Map<String, Object> patch = new HashMap<>();
            patch.put("profilePhotoBase64", localPhoto);
            patch.put("photoBase64", localPhoto);
            patch.put("profileImageBase64", localPhoto);
            boolean currentPrivate = ProfilePrefs.isProfilePrivate(this);
            patch.put("profilePrivate", currentPrivate);
            patch.put("privateProfile", currentPrivate);
            patch.put("isPrivate", currentPrivate);
            patch.put("privacy", currentPrivate ? "private" : "public");
            patch.put("profilePrivacy", currentPrivate ? "private" : "public");
            patch.put("privacyMode", currentPrivate ? "private" : "public");

            firestore.collection("users")
                    .document(userId)
                    .set(patch, com.google.firebase.firestore.SetOptions.merge());
        } catch (Exception ignored) {
        }
    }

    private void startRealtimeChat() {
        updateHeaderConnecting();
        attachConnectedListener();
        attachMessagesListener();
        attachPresenceListener();
        attachTypingListener();
    }

    private void updateHeaderConnecting() {
        if (tvChatTitle != null) {
            tvChatTitle.setText("Global Community");
        }

        if (tvOnlineCount != null) {
            tvOnlineCount.setText("Connecting...");
            tvOnlineCount.setTextColor(Color.rgb(143, 163, 196));
        }
    }

    private void attachConnectedListener() {
        connectedListener = connectedRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Boolean connected = snapshot.getValue(Boolean.class);
                firebaseConnected = connected != null && connected;

                if (firebaseConnected) {
                    if (tvOnlineCount != null) {
                        tvOnlineCount.setText("Connected");
                        tvOnlineCount.setTextColor(Color.rgb(53, 229, 138));
                    }

                    setupPresence();
                } else {
                    if (tvOnlineCount != null) {
                        tvOnlineCount.setText("Connecting...");
                        tvOnlineCount.setTextColor(Color.rgb(143, 163, 196));
                    }
                }

                updateSendButtonState();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                firebaseConnected = false;

                if (tvOnlineCount != null) {
                    tvOnlineCount.setText("Connection blocked");
                    tvOnlineCount.setTextColor(Color.rgb(255, 130, 150));
                }

                Toast.makeText(
                        GlobalChatActivity.this,
                        "Firebase connection blocked: " + error.getMessage(),
                        Toast.LENGTH_LONG
                ).show();

                updateSendButtonState();
            }
        });
    }

    private void attachMessagesListener() {
        Query query = chatRef.orderByChild("timestamp").limitToLast(MAX_MESSAGES);

        messagesListener = query.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                messages.clear();

                for (DataSnapshot child : snapshot.getChildren()) {
                    ChatMessage message = child.getValue(ChatMessage.class);

                    if (message == null) {
                        continue;
                    }

                    if (message.id == null || message.id.trim().isEmpty()) {
                        message.id = child.getKey();
                    }

                    if (message.id == null || message.text == null || message.text.trim().isEmpty()) {
                        continue;
                    }

                    messages.add(message);
                }

                loadMissingProfilesForMessages();
                adapter.notifyDataSetChanged();
                scrollToBottom();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(
                        GlobalChatActivity.this,
                        "Chat read blocked: " + error.getMessage(),
                        Toast.LENGTH_LONG
                ).show();
            }
        });
    }


    private void loadMissingProfilesForMessages() {
        if (firestore == null || messages.isEmpty()) {
            return;
        }

        for (ChatMessage message : messages) {
            if (message == null || message.userId == null || message.userId.trim().isEmpty()) {
                continue;
            }

            String uid = message.userId.trim();

            if (uid.equals(userId)) {
                continue;
            }

            ensureLiveProfileListener(uid);
        }
    }

    private void ensureLiveProfileListener(@NonNull String uid) {
        String cleanUid = uid.trim();

        if (cleanUid.isEmpty() || cleanUid.equals(userId) || profileListeners.containsKey(cleanUid)) {
            return;
        }

        profileCache.put(cleanUid, new ChatUserProfile("", "", false));

        ListenerRegistration registration = firestore.collection("users")
                .document(cleanUid)
                .addSnapshotListener((snapshot, error) -> {
                    if (error != null || snapshot == null || !snapshot.exists()) {
                        return;
                    }

                    ChatUserProfile profile = new ChatUserProfile(
                            firstNonEmpty(
                                    snapshot.getString("displayName"),
                                    snapshot.getString("fullName"),
                                    snapshot.getString("username"),
                                    ""
                            ),
                            firstNonEmpty(
                                    snapshot.getString("profilePhotoBase64"),
                                    snapshot.getString("photoBase64"),
                                    snapshot.getString("profileImageBase64"),
                                    ""
                            ),
                            readProfilePrivate(snapshot, false)
                    );

                    profileCache.put(cleanUid, profile);

                    if (adapter != null) {
                        adapter.notifyDataSetChanged();
                    }
                });

        profileListeners.put(cleanUid, registration);
    }

    private void attachPresenceListener() {
        presenceListener = presenceRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Set<String> onlineUsers = new HashSet<>();
                long now = System.currentTimeMillis();

                for (DataSnapshot userSnapshot : snapshot.getChildren()) {
                    String uid = userSnapshot.getKey();

                    for (DataSnapshot sessionSnapshot : userSnapshot.getChildren()) {
                        Boolean online = sessionSnapshot.child("online").getValue(Boolean.class);
                        Long updatedAt = sessionSnapshot.child("updatedAt").getValue(Long.class);

                        if (online != null && online && updatedAt != null && now - updatedAt < 90_000L) {
                            if (uid != null) {
                                onlineUsers.add(uid);
                            }
                        }
                    }
                }

                if (firebaseConnected && userId != null && !userId.trim().isEmpty()) {
                    onlineUsers.add(userId);
                }

                int otherUsersOnline = onlineUsers.size();
                if (userId != null && onlineUsers.contains(userId)) {
                    otherUsersOnline = Math.max(0, otherUsersOnline - 1);
                }

                if (tvOnlineCount != null) {
                    if (!firebaseConnected) {
                        tvOnlineCount.setText("Connecting...");
                    } else if (otherUsersOnline <= 0) {
                        tvOnlineCount.setText("Only you are online");
                        tvOnlineCount.setTextColor(Color.rgb(53, 229, 138));
                    } else {
                        tvOnlineCount.setText(otherUsersOnline == 1 ? "1 online" : otherUsersOnline + " online");
                        tvOnlineCount.setTextColor(Color.rgb(53, 229, 138));
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                if (tvOnlineCount != null) {
                    tvOnlineCount.setText("Presence blocked");
                    tvOnlineCount.setTextColor(Color.rgb(255, 130, 150));
                }
            }
        });
    }

    private void attachTypingListener() {
        
        
        if (tvTypingStatus != null) {
            tvTypingStatus.setVisibility(View.GONE);
            tvTypingStatus.setText("");
        }
    }

    private void setupPresence() {
        if (presenceRef == null || userId == null || userId.trim().isEmpty()) {
            return;
        }

        DatabaseReference myPresenceRef = presenceRef.child(userId).child(sessionId);

        Map<String, Object> presence = new HashMap<>();
        presence.put("online", true);
        presence.put("userId", userId);
        presence.put("username", firstNonEmpty(username, "Trader"));
        presence.put("deviceId", deviceId);
        presence.put("sessionId", sessionId);
        presence.put("updatedAt", System.currentTimeMillis());

        myPresenceRef.setValue(presence)
                .addOnFailureListener(e ->
                        Toast.makeText(
                                this,
                                "Presence failed: " + e.getMessage(),
                                Toast.LENGTH_LONG
                        ).show()
                );

        myPresenceRef.onDisconnect().removeValue();
    }

    private void removePresence() {
        try {
            if (presenceRef != null && userId != null && !userId.trim().isEmpty()) {
                presenceRef.child(userId).child(sessionId).removeValue();
            }
        } catch (Exception ignored) {
        }
    }

    private void detachListeners() {
        try {
            if (connectedRef != null && connectedListener != null) {
                connectedRef.removeEventListener(connectedListener);
            }
        } catch (Exception ignored) {
        }

        try {
            if (chatRef != null && messagesListener != null) {
                chatRef.removeEventListener(messagesListener);
            }
        } catch (Exception ignored) {
        }

        try {
            if (presenceRef != null && presenceListener != null) {
                presenceRef.removeEventListener(presenceListener);
            }
        } catch (Exception ignored) {
        }

        try {
            if (typingRef != null && typingListener != null) {
                typingRef.removeEventListener(typingListener);
            }
        } catch (Exception ignored) {
        }

        try {
            for (ListenerRegistration registration : profileListeners.values()) {
                if (registration != null) {
                    registration.remove();
                }
            }
            profileListeners.clear();
            profileCache.clear();
        } catch (Exception ignored) {
        }
    }

    private void openGifPicker() {
        try {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("image/gif");
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivityForResult(intent, REQUEST_PICK_GIF);
        } catch (Exception e) {
            Toast.makeText(this, "Could not open GIF picker", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_PICK_GIF && resultCode == RESULT_OK && data != null) {
            Uri gifUri = data.getData();

            if (gifUri == null) {
                Toast.makeText(this, "GIF was not selected", Toast.LENGTH_SHORT).show();
                return;
            }

            sendGifMessage(gifUri);
        }
    }

    private void sendGifMessage(@NonNull Uri gifUri) {
        if (sending) {
            return;
        }

        if (currentUser == null) {
            Toast.makeText(this, "Please sign in again", Toast.LENGTH_SHORT).show();
            return;
        }

        String gifBase64 = readGifAsBase64(gifUri);

        if (gifBase64.isEmpty()) {
            return;
        }

        DatabaseReference newRef = chatRef.push();
        String id = newRef.getKey();

        if (id == null || id.trim().isEmpty()) {
            Toast.makeText(this, "Could not create GIF message", Toast.LENGTH_SHORT).show();
            return;
        }

        Map<String, Object> message = buildFullMessageMap(id, "[GIF]");
        message.put("messageType", "gif");
        message.put("gifBase64", gifBase64);
        message.put("gifMimeType", "image/gif");

        setSendLoading(true);

        newRef.setValue(message)
                .addOnSuccessListener(unused -> onMessageSent())
                .addOnFailureListener(e -> {
                    setSendLoading(false);
                    Toast.makeText(this, "Could not send GIF: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
    }

    @NonNull
    private String readGifAsBase64(@NonNull Uri gifUri) {
        try (InputStream inputStream = getContentResolver().openInputStream(gifUri);
             ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {

            if (inputStream == null) {
                Toast.makeText(this, "Could not read GIF", Toast.LENGTH_SHORT).show();
                return "";
            }

            byte[] buffer = new byte[8192];
            int total = 0;
            int read;

            while ((read = inputStream.read(buffer)) != -1) {
                total += read;

                if (total > MAX_GIF_BYTES) {
                    Toast.makeText(this, "GIF is too large. Please choose a smaller GIF.", Toast.LENGTH_LONG).show();
                    return "";
                }

                outputStream.write(buffer, 0, read);
            }

            byte[] bytes = outputStream.toByteArray();

            if (bytes.length == 0) {
                Toast.makeText(this, "Selected GIF is empty", Toast.LENGTH_SHORT).show();
                return "";
            }

            return Base64.encodeToString(bytes, Base64.NO_WRAP);
        } catch (Exception e) {
            Toast.makeText(this, "Could not read GIF: " + e.getMessage(), Toast.LENGTH_LONG).show();
            return "";
        }
    }

    private void sendMessage() {
        if (sending) {
            return;
        }

        if (currentUser == null) {
            Toast.makeText(this, "Please sign in again", Toast.LENGTH_SHORT).show();
            return;
        }

        String text = etMessage == null || etMessage.getText() == null
                ? ""
                : etMessage.getText().toString().trim();

        if (text.isEmpty()) {
            return;
        }

        if (text.length() > MAX_MESSAGE_LENGTH) {
            Toast.makeText(this, "Message is too long", Toast.LENGTH_SHORT).show();
            return;
        }

        DatabaseReference newRef = chatRef.push();
        String id = newRef.getKey();

        if (id == null || id.trim().isEmpty()) {
            Toast.makeText(this, "Could not create message", Toast.LENGTH_SHORT).show();
            return;
        }

        Map<String, Object> fullMessage = buildFullMessageMap(id, text);
        Map<String, Object> minimalMessage = buildMinimalMessageMap(id, text);

        setSendLoading(true);

        newRef.setValue(fullMessage)
                .addOnSuccessListener(unused -> onMessageSent())
                .addOnFailureListener(firstError -> {
                    String raw = firstError.getMessage() == null ? "" : firstError.getMessage();

                    if (raw.toLowerCase(Locale.US).contains("permission")) {
                        newRef.setValue(minimalMessage)
                                .addOnSuccessListener(unused -> onMessageSent())
                                .addOnFailureListener(secondError -> {
                                    setSendLoading(false);

                                    Toast.makeText(
                                            this,
                                            "Firebase blocked the message. Check Realtime Database rules for /GlobalChat.",
                                            Toast.LENGTH_LONG
                                    ).show();
                                });
                    } else {
                        setSendLoading(false);

                        Toast.makeText(
                                this,
                                "Could not send message: " + raw,
                                Toast.LENGTH_LONG
                        ).show();
                    }
                });
    }

    private Map<String, Object> buildMinimalMessageMap(String id, String text) {
        Map<String, Object> message = new HashMap<>();
        message.put("id", id);
        message.put("userId", userId);
        message.put("username", firstNonEmpty(username, "Trader"));
        message.put("text", text);
        message.put("timestamp", System.currentTimeMillis());
        return message;
    }

    private Map<String, Object> buildFullMessageMap(String id, String text) {
        Map<String, Object> message = buildMinimalMessageMap(id, text);

        String chatPhotoBase64 = firstNonEmpty(
                profilePhotoBase64,
                AppSettingsManager.getLocalProfilePhotoBase64(this),
                ProfilePrefs.getPhotoBase64(this),
                ""
        );

        boolean currentPrivate = profilePrivate || ProfilePrefs.isProfilePrivate(this);
        String visiblePhotoBase64 = currentPrivate ? "" : chatPhotoBase64;

        
        
        message.put("profilePrivate", currentPrivate);
        message.put("privateProfile", currentPrivate);
        message.put("isPrivate", currentPrivate);
        message.put("privacy", currentPrivate ? "private" : "public");
        message.put("profilePrivacy", currentPrivate ? "private" : "public");
        message.put("privacyMode", currentPrivate ? "private" : "public");
        message.put("profilePhotoBase64", visiblePhotoBase64);
        message.put("photoBase64", visiblePhotoBase64);
        message.put("profileImageBase64", visiblePhotoBase64);

        if (replyTarget != null) {
            message.put("replyToMessageId", firstNonEmpty(replyTarget.id, ""));
            message.put("replyToUserId", firstNonEmpty(replyTarget.userId, ""));
            message.put("replyToUsername", firstNonEmpty(replyTarget.username, "Trader"));
            message.put("replyToText", limitText(replyTarget.text, MAX_REPLY_PREVIEW_LENGTH));
        }

        return message;
    }

    private void onMessageSent() {
        setSendLoading(false);

        if (etMessage != null) {
            etMessage.setText("");
        }

        clearReplyTarget();
        stopTyping();
        scrollToBottom();
    }

    private void editMessage(ChatMessage message) {
        if (message == null || message.id == null || !userId.equals(message.userId)) {
            return;
        }

        EditText input = new EditText(this);
        input.setText(message.text == null ? "" : message.text);
        input.setSelection(input.getText() == null ? 0 : input.getText().length());
        input.setSingleLine(false);
        input.setMinLines(2);
        input.setMaxLines(5);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Edit message")
                .setView(input)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Save", null)
                .create();

        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String newText = input.getText() == null ? "" : input.getText().toString().trim();

            if (newText.isEmpty()) {
                input.setError("Message cannot be empty");
                return;
            }

            if (newText.length() > MAX_MESSAGE_LENGTH) {
                input.setError("Message is too long");
                return;
            }

            Map<String, Object> patch = new HashMap<>();
            patch.put("text", newText);
            patch.put("edited", true);
            patch.put("editedAt", System.currentTimeMillis());

            chatRef.child(message.id)
                    .updateChildren(patch)
                    .addOnSuccessListener(unused -> dialog.dismiss())
                    .addOnFailureListener(e ->
                            Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show()
                    );
        }));

        dialog.show();
    }

    private void deleteMessage(ChatMessage message) {
        if (message == null || message.id == null || !userId.equals(message.userId)) {
            return;
        }

        chatRef.child(message.id)
                .removeValue()
                .addOnFailureListener(e ->
                        Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show()
                );
    }

    private void copyMessage(ChatMessage message) {
        if (message == null || message.text == null) {
            return;
        }

        ClipboardManager manager = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);

        if (manager != null) {
            manager.setPrimaryClip(ClipData.newPlainText("Global Chat Message", message.text));
            Toast.makeText(this, "Message copied", Toast.LENGTH_SHORT).show();
        }
    }

    private void showMessageActions(ChatMessage message) {
        if (message == null) {
            return;
        }

        boolean mine = userId.equals(message.userId);

        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setPadding(dp(16), dp(10), dp(16), dp(18));
        outer.setBackgroundColor(Color.TRANSPARENT);

        LinearLayout sheet = new LinearLayout(this);
        sheet.setOrientation(LinearLayout.VERTICAL);
        sheet.setPadding(dp(18), dp(18), dp(18), dp(16));
        sheet.setBackground(rounded(
                Color.rgb(8, 15, 29),
                28,
                Color.rgb(43, 68, 112)
        ));

        TextView title = new TextView(this);
        title.setText("Message options");
        title.setGravity(Gravity.CENTER);
        title.setTextColor(Color.WHITE);
        title.setTextSize(18);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setIncludeFontPadding(false);

        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        titleParams.bottomMargin = dp(16);
        sheet.addView(title, titleParams);

        sheet.addView(createMessageMenuRow(
                "Copy message",
                R.drawable.ic_chat_copy,
                Color.rgb(105, 135, 255),
                false,
                v -> {
                    dialog.dismiss();
                    copyMessage(message);
                }
        ));

        if (mine) {
            sheet.addView(menuSpacer());

            sheet.addView(createMessageMenuRow(
                    "Edit message",
                    R.drawable.ic_chat_edit,
                    Color.rgb(73, 229, 154),
                    false,
                    v -> {
                        dialog.dismiss();
                        editMessage(message);
                    }
            ));

            sheet.addView(menuSpacer());

            sheet.addView(createMessageMenuRow(
                    "Delete message",
                    R.drawable.ic_chat_delete,
                    Color.rgb(255, 104, 126),
                    true,
                    v -> {
                        dialog.dismiss();
                        deleteMessage(message);
                    }
            ));
        }

        sheet.addView(menuLargeSpacer());

        TextView cancel = new TextView(this);
        cancel.setText("Cancel");
        cancel.setGravity(Gravity.CENTER);
        cancel.setTextSize(15);
        cancel.setTypeface(Typeface.DEFAULT_BOLD);
        cancel.setTextColor(Color.rgb(220, 228, 246));
        cancel.setPadding(0, dp(14), 0, dp(14));
        cancel.setBackground(rounded(
                Color.rgb(15, 26, 46),
                18,
                Color.rgb(44, 64, 100)
        ));
        cancel.setOnClickListener(v -> dialog.dismiss());

        sheet.addView(cancel);

        outer.addView(sheet, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));

        dialog.setContentView(outer);
        dialog.setCanceledOnTouchOutside(true);
        dialog.show();

        Window window = dialog.getWindow();

        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            window.setLayout(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
            );
            window.setGravity(Gravity.BOTTOM);
            window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);

            WindowManager.LayoutParams params = window.getAttributes();
            params.dimAmount = 0.55f;
            window.setAttributes(params);
        }
    }

    private View createMessageMenuRow(
            String titleText,
            @DrawableRes int iconRes,
            int iconColor,
            boolean dangerous,
            View.OnClickListener listener
    ) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(14), dp(12), dp(14), dp(12));
        row.setClickable(true);
        row.setFocusable(true);
        row.setOnClickListener(listener);

        row.setBackground(rounded(
                dangerous ? Color.rgb(35, 16, 26) : Color.rgb(13, 24, 43),
                18,
                dangerous ? Color.rgb(92, 42, 58) : Color.rgb(36, 55, 91)
        ));

        ImageView icon = new ImageView(this);
        icon.setImageResource(iconRes);
        icon.setColorFilter(iconColor);
        icon.setPadding(dp(10), dp(10), dp(10), dp(10));
        icon.setBackground(rounded(
                dangerous ? Color.rgb(58, 24, 36) : Color.rgb(24, 39, 69),
                14,
                dangerous ? Color.rgb(120, 48, 70) : Color.rgb(61, 86, 145)
        ));

        LinearLayout.LayoutParams iconParams = new LinearLayout.LayoutParams(dp(42), dp(42));
        iconParams.rightMargin = dp(12);
        row.addView(icon, iconParams);

        TextView title = new TextView(this);
        title.setText(titleText);
        title.setTextSize(15);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setIncludeFontPadding(false);
        title.setTextColor(dangerous
                ? Color.rgb(255, 128, 148)
                : Color.rgb(245, 248, 255));

        row.addView(title, new LinearLayout.LayoutParams(
                0,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                1f
        ));

        TextView arrow = new TextView(this);
        arrow.setText(">");
        arrow.setTextSize(22);
        arrow.setGravity(Gravity.CENTER);
        arrow.setTextColor(dangerous
                ? Color.rgb(255, 128, 148)
                : Color.rgb(112, 132, 168));

        row.addView(arrow, new LinearLayout.LayoutParams(
                dp(24),
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));

        return row;
    }

    private View menuSpacer() {
        View spacer = new View(this);
        spacer.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(10)
        ));
        return spacer;
    }

    private View menuLargeSpacer() {
        View spacer = new View(this);
        spacer.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(14)
        ));
        return spacer;
    }

    private void startReplyTo(ChatMessage message) {
        if (message == null || replyPreviewBar == null) {
            return;
        }

        replyTarget = message;

        String name = userId.equals(message.userId)
                ? "yourself"
                : firstNonEmpty(message.username, "Trader");

        if (tvReplyPreviewName != null) {
            tvReplyPreviewName.setText("Replying to " + name);
        }

        if (tvReplyPreviewText != null) {
            tvReplyPreviewText.setText(limitText(message.text, MAX_REPLY_PREVIEW_LENGTH));
        }

        replyPreviewBar.setVisibility(View.VISIBLE);
        replyPreviewBar.setAlpha(0f);
        replyPreviewBar.setTranslationY(dp(6));
        replyPreviewBar.animate()
                .alpha(1f)
                .translationY(0f)
                .setDuration(180)
                .setInterpolator(new DecelerateInterpolator())
                .start();

        if (etMessage != null) {
            etMessage.requestFocus();
            etMessage.setSelection(etMessage.getText() == null ? 0 : etMessage.getText().length());
            showKeyboard();
        }
    }

    private void clearReplyTarget() {
        replyTarget = null;

        if (replyPreviewBar != null) {
            replyPreviewBar.clearAnimation();
            replyPreviewBar.setVisibility(View.GONE);
        }
    }

    private void startTyping() {
        
    }

    private void stopTyping() {
        try {
            if (typingRef != null && userId != null && !userId.trim().isEmpty()) {
                typingRef.child(userId).removeValue();
            }
        } catch (Exception ignored) {
        }
    }

    private void setSendLoading(boolean loading) {
        sending = loading;

        if (btnSendMessage == null) {
            return;
        }

        btnSendMessage.setEnabled(!loading);
        btnSendMessage.setAlpha(loading ? 0.55f : 1.0f);
        btnSendMessage.setText(loading ? "..." : "Send");

        if (!loading) {
            updateSendButtonState();
        }
    }

    private void updateSendButtonState() {
        if (btnSendMessage == null || etMessage == null || etMessage.getText() == null) {
            return;
        }

        boolean hasText = etMessage.getText().toString().trim().length() > 0;
        boolean enabled = hasText && !sending;

        btnSendMessage.setEnabled(enabled);
        btnSendMessage.setAlpha(enabled ? 1.0f : 0.45f);
    }

    private void scrollToBottom() {
        if (recyclerGlobalChat == null || adapter == null || adapter.getItemCount() == 0) {
            return;
        }

        recyclerGlobalChat.post(() ->
                recyclerGlobalChat.smoothScrollToPosition(Math.max(0, adapter.getItemCount() - 1))
        );
    }

    private void openAuthChoice() {
        Intent intent = new Intent(this, AuthChoiceActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    private String buildFallbackUsername(FirebaseUser user) {
        if (user == null) {
            return "Trader";
        }

        String displayName = user.getDisplayName();
        if (displayName != null && !displayName.trim().isEmpty()) {
            return displayName.trim();
        }

        String email = user.getEmail();
        if (email != null && email.contains("@")) {
            return email.substring(0, email.indexOf("@"));
        }

        return "Trader";
    }

    private String firstNonEmpty(String... values) {
        if (values == null) {
            return "";
        }

        for (String value : values) {
            if (value != null && !value.trim().isEmpty()) {
                return value.trim();
            }
        }

        return "";
    }

    private String limitText(String text, int maxLength) {
        String safe = firstNonEmpty(text, "");

        if (safe.length() <= maxLength) {
            return safe;
        }

        return safe.substring(0, Math.max(0, maxLength - 1)).trim() + "...";
    }

    private int dp(int value) {
        return Math.round(getResources().getDisplayMetrics().density * value);
    }

    private GradientDrawable rounded(int color, int radiusDp, int strokeColor) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radiusDp));
        drawable.setStroke(dp(1), strokeColor);
        return drawable;
    }

    private void hideKeyboard() {
        try {
            View view = getCurrentFocus();

            if (view == null) {
                view = etMessage;
            }

            if (view == null) {
                return;
            }

            InputMethodManager manager = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);

            if (manager != null) {
                manager.hideSoftInputFromWindow(view.getWindowToken(), 0);
            }
        } catch (Exception ignored) {
        }
    }

    private void showKeyboard() {
        try {
            if (etMessage == null) {
                return;
            }

            InputMethodManager manager = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);

            if (manager != null) {
                manager.showSoftInput(etMessage, InputMethodManager.SHOW_IMPLICIT);
            }
        } catch (Exception ignored) {
        }
    }

    private Bitmap decodeBase64Bitmap(String value) {
        try {
            String clean = firstNonEmpty(value, "");

            if (clean.contains(",")) {
                clean = clean.substring(clean.indexOf(",") + 1);
            }

            byte[] data = Base64.decode(clean, Base64.DEFAULT);
            return BitmapFactory.decodeByteArray(data, 0, data.length);
        } catch (Exception e) {
            return null;
        }
    }

    private static class ChatUserProfile {
        final String displayName;
        final String photoBase64;
        final boolean profilePrivate;

        ChatUserProfile(String displayName, String photoBase64, boolean profilePrivate) {
            this.displayName = displayName == null ? "" : displayName;
            this.photoBase64 = photoBase64 == null ? "" : photoBase64;
            this.profilePrivate = profilePrivate;
        }
    }

    public static class ChatMessage {
        public String id;
        public String userId;
        public String username;
        public String text;
        public long timestamp;
        public boolean edited;
        public long editedAt;

        public String profilePhotoBase64;
        public String photoBase64;
        public String profileImageBase64;
        public boolean profilePrivate;

        public String messageType;
        public String gifBase64;
        public String gifMimeType;

        public String replyToMessageId;
        public String replyToUserId;
        public String replyToUsername;
        public String replyToText;

        public ChatMessage() {
        }
    }

    private boolean isGifMessage(@Nullable ChatMessage message) {
        if (message == null) {
            return false;
        }

        String type = firstNonEmpty(message.messageType, "").toLowerCase(Locale.US);
        return "gif".equals(type) && !firstNonEmpty(message.gifBase64, "").isEmpty();
    }

    private void loadGifIntoView(@Nullable String gifBase64, @NonNull ImageView imageView) {
        try {
            String safeGif = firstNonEmpty(gifBase64, "");

            if (safeGif.isEmpty()) {
                imageView.setVisibility(View.GONE);
                Glide.with(imageView.getContext()).clear(imageView);
                return;
            }

            byte[] bytes = Base64.decode(safeGif, Base64.DEFAULT);

            Glide.with(imageView.getContext())
                    .asGif()
                    .load(bytes)
                    .into(imageView);
        } catch (Exception e) {
            imageView.setVisibility(View.GONE);
            Glide.with(imageView.getContext()).clear(imageView);
        }
    }

    private class ChatAdapter extends RecyclerView.Adapter<ChatAdapter.ChatViewHolder> {

        @NonNull
        @Override
        public ChatViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            LinearLayout root = new LinearLayout(GlobalChatActivity.this);
            root.setOrientation(LinearLayout.HORIZONTAL);
            root.setPadding(dp(12), dp(6), dp(12), dp(6));
            root.setGravity(Gravity.BOTTOM);
            root.setLayoutParams(new RecyclerView.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
            ));

            AvatarView avatar = new AvatarView(GlobalChatActivity.this);

            LinearLayout.LayoutParams avatarParams = new LinearLayout.LayoutParams(dp(36), dp(36));
            avatarParams.rightMargin = dp(10);

            LinearLayout bubbleWrap = new LinearLayout(GlobalChatActivity.this);
            bubbleWrap.setOrientation(LinearLayout.VERTICAL);
            bubbleWrap.setPadding(dp(14), dp(10), dp(14), dp(8));
            bubbleWrap.setMinimumHeight(dp(44));

            TextView meta = new TextView(GlobalChatActivity.this);
            meta.setTextSize(11);
            meta.setTypeface(Typeface.DEFAULT_BOLD);
            meta.setSingleLine(true);
            meta.setIncludeFontPadding(false);
            meta.setMaxWidth(dp(238));
            meta.setEllipsize(TextUtils.TruncateAt.END);

            LinearLayout replyWrap = new LinearLayout(GlobalChatActivity.this);
            replyWrap.setOrientation(LinearLayout.HORIZONTAL);
            replyWrap.setGravity(Gravity.CENTER_VERTICAL);
            replyWrap.setPadding(dp(10), dp(8), dp(10), dp(8));
            replyWrap.setMinimumHeight(dp(48));

            View replyLine = new View(GlobalChatActivity.this);
            LinearLayout.LayoutParams replyLineParams = new LinearLayout.LayoutParams(dp(3), dp(34));
            replyLineParams.rightMargin = dp(9);
            replyWrap.addView(replyLine, replyLineParams);

            LinearLayout replyTextWrap = new LinearLayout(GlobalChatActivity.this);
            replyTextWrap.setOrientation(LinearLayout.VERTICAL);
            replyTextWrap.setGravity(Gravity.CENTER_VERTICAL);

            TextView replyName = new TextView(GlobalChatActivity.this);
            replyName.setTextSize(11);
            replyName.setTypeface(Typeface.DEFAULT_BOLD);
            replyName.setSingleLine(true);
            replyName.setEllipsize(TextUtils.TruncateAt.END);
            replyName.setIncludeFontPadding(false);
            replyName.setMaxWidth(dp(172));

            TextView replyText = new TextView(GlobalChatActivity.this);
            replyText.setTextSize(11);
            replyText.setSingleLine(true);
            replyText.setEllipsize(TextUtils.TruncateAt.END);
            replyText.setPadding(0, dp(4), 0, 0);
            replyText.setIncludeFontPadding(false);
            replyText.setMaxWidth(dp(172));

            replyTextWrap.addView(replyName, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
            ));

            replyTextWrap.addView(replyText, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
            ));

            replyWrap.addView(replyTextWrap, new LinearLayout.LayoutParams(
                    0,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    1f
            ));

            TextView body = new TextView(GlobalChatActivity.this);
            body.setTextSize(15);
            body.setTextColor(Color.WHITE);
            body.setLineSpacing(dp(3), 1f);
            body.setPadding(0, dp(7), 0, 0);
            body.setMaxWidth(dp(238));
            body.setIncludeFontPadding(false);
            body.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
            body.setGravity(Gravity.START);

            ImageView gifView = new ImageView(GlobalChatActivity.this);
            gifView.setVisibility(View.GONE);
            gifView.setAdjustViewBounds(true);
            gifView.setScaleType(ImageView.ScaleType.CENTER_CROP);
            gifView.setBackground(rounded(
                    Color.rgb(8, 14, 25),
                    16,
                    Color.rgb(54, 78, 120)
            ));

            TextView edited = new TextView(GlobalChatActivity.this);
            edited.setTextSize(10);
            edited.setPadding(0, dp(7), 0, 0);
            edited.setIncludeFontPadding(false);
            edited.setSingleLine(true);

            bubbleWrap.addView(meta, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
            ));

            LinearLayout.LayoutParams replyParams = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
            );
            replyParams.topMargin = dp(8);
            bubbleWrap.addView(replyWrap, replyParams);

            bubbleWrap.addView(body, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
            ));

            LinearLayout.LayoutParams gifParams = new LinearLayout.LayoutParams(dp(210), dp(158));
            gifParams.topMargin = dp(8);
            bubbleWrap.addView(gifView, gifParams);

            bubbleWrap.addView(edited, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
            ));

            root.addView(avatar, avatarParams);
            root.addView(bubbleWrap, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
            ));

            return new ChatViewHolder(root, avatar, bubbleWrap, meta, replyWrap, replyLine, replyName, replyText, body, gifView, edited);
        }

        @Override
        public void onBindViewHolder(@NonNull ChatViewHolder holder, int position) {
            ChatMessage message = messages.get(position);
            boolean mine = userId.equals(message.userId);

            String senderName = firstNonEmpty(message.username, "Trader");
            String avatarPhoto = "";
            boolean avatarPrivate = false;

            if (!mine) {
                ChatUserProfile cachedProfile = profileCache.get(message.userId);

                if (cachedProfile != null) {
                    
                    
                    senderName = firstNonEmpty(cachedProfile.displayName, senderName, "Trader");
                    avatarPrivate = cachedProfile.profilePrivate;
                    avatarPhoto = avatarPrivate ? "" : firstNonEmpty(cachedProfile.photoBase64, "");
                } else {
                    avatarPrivate = message.profilePrivate;

                    if (!avatarPrivate) {
                        avatarPhoto = firstNonEmpty(
                                message.profilePhotoBase64,
                                message.photoBase64,
                                message.profileImageBase64,
                                ""
                        );
                    }
                }
            }

            holder.avatar.setAvatar(senderName, avatarPhoto, avatarPrivate);
            holder.meta.setText(mine ? "You" : senderName);
            boolean hasGif = isGifMessage(message);

            if (hasGif) {
                holder.body.setVisibility(View.GONE);
                holder.gifView.setVisibility(View.VISIBLE);
                loadGifIntoView(message.gifBase64, holder.gifView);
            } else {
                holder.gifView.setVisibility(View.GONE);
                holder.body.setVisibility(View.VISIBLE);
                holder.body.setText(message.text == null ? "" : message.text.trim());
                Glide.with(holder.gifView.getContext()).clear(holder.gifView);
            }

            holder.edited.setText(message.edited
                    ? formatTimeAgo(message.timestamp) + " · edited"
                    : formatTimeAgo(message.timestamp));

            holder.edited.setVisibility(View.VISIBLE);

            boolean hasReply = !firstNonEmpty(message.replyToText, "").isEmpty();
            holder.replyWrap.setVisibility(hasReply ? View.VISIBLE : View.GONE);

            if (hasReply) {
                String replyName = firstNonEmpty(message.replyToUsername, "Message");
                String replyBody = limitText(message.replyToText, 58);

                holder.replyName.setText("Reply to " + replyName);
                holder.replyText.setText(replyBody);
                holder.bubbleWrap.setMinimumWidth(dp(188));
            } else {
                holder.bubbleWrap.setMinimumWidth(dp(44));
            }

            LinearLayout.LayoutParams avatarParams =
                    (LinearLayout.LayoutParams) holder.avatar.getLayoutParams();

            LinearLayout.LayoutParams bubbleParams =
                    (LinearLayout.LayoutParams) holder.bubbleWrap.getLayoutParams();

            if (mine) {
                holder.root.setGravity(Gravity.RIGHT | Gravity.BOTTOM);

                holder.avatar.setVisibility(View.GONE);
                avatarParams.width = 0;
                avatarParams.height = 0;
                avatarParams.rightMargin = 0;

                bubbleParams.leftMargin = dp(76);
                bubbleParams.rightMargin = 0;

                holder.bubbleWrap.setBackground(messageBubble(true));
                holder.meta.setTextColor(Color.rgb(235, 241, 255));
                holder.body.setTextColor(Color.WHITE);
                holder.edited.setTextColor(Color.rgb(211, 222, 255));

                holder.replyWrap.setBackground(rounded(
                        Color.rgb(38, 76, 198),
                        15,
                        Color.rgb(103, 137, 255)
                ));
                holder.replyLine.setBackground(rounded(
                        Color.rgb(222, 230, 255),
                        4,
                        Color.rgb(222, 230, 255)
                ));
                holder.replyName.setTextColor(Color.rgb(245, 248, 255));
                holder.replyText.setTextColor(Color.rgb(213, 224, 255));
            } else {
                holder.root.setGravity(Gravity.LEFT | Gravity.BOTTOM);

                holder.avatar.setVisibility(View.VISIBLE);
                avatarParams.width = dp(36);
                avatarParams.height = dp(36);
                avatarParams.rightMargin = dp(10);

                bubbleParams.leftMargin = 0;
                bubbleParams.rightMargin = dp(64);

                holder.bubbleWrap.setBackground(messageBubble(false));
                holder.meta.setTextColor(Color.rgb(205, 218, 243));
                holder.body.setTextColor(Color.rgb(248, 250, 255));
                holder.edited.setTextColor(Color.rgb(142, 161, 196));

                holder.replyWrap.setBackground(rounded(
                        Color.rgb(24, 40, 66),
                        15,
                        Color.rgb(54, 78, 120)
                ));
                holder.replyLine.setBackground(rounded(
                        Color.rgb(96, 136, 255),
                        4,
                        Color.rgb(96, 136, 255)
                ));
                holder.replyName.setTextColor(Color.rgb(230, 237, 255));
                holder.replyText.setTextColor(Color.rgb(156, 175, 210));
            }

            holder.avatar.setLayoutParams(avatarParams);
            holder.bubbleWrap.setLayoutParams(bubbleParams);

            holder.bubbleWrap.setOnLongClickListener(v -> {
                showMessageActions(message);
                return true;
            });

            holder.root.setOnLongClickListener(v -> {
                showMessageActions(message);
                return true;
            });

            holder.root.setOnClickListener(v -> hideKeyboard());
        }

        @Override
        public int getItemCount() {
            return messages.size();
        }

        private GradientDrawable messageBubble(boolean mine) {
            GradientDrawable drawable = new GradientDrawable();
            drawable.setShape(GradientDrawable.RECTANGLE);

            drawable.setColor(mine
                    ? Color.rgb(54, 98, 255)
                    : Color.rgb(16, 27, 45));

            float large = dp(22);
            float small = dp(7);

            if (mine) {
                drawable.setCornerRadii(new float[]{
                        large, large,
                        large, large,
                        small, small,
                        large, large
                });

                drawable.setStroke(dp(1), Color.rgb(101, 136, 255));
            } else {
                drawable.setCornerRadii(new float[]{
                        large, large,
                        large, large,
                        large, large,
                        small, small
                });

                drawable.setStroke(dp(1), Color.rgb(42, 61, 93));
            }

            return drawable;
        }

        private String formatTimeAgo(long timestamp) {
            if (timestamp <= 0L) {
                return "now";
            }

            long diff = Math.max(0L, System.currentTimeMillis() - timestamp);

            long minute = 60_000L;
            long hour = 60L * minute;
            long day = 24L * hour;

            if (diff < minute) {
                return "now";
            }

            if (diff < hour) {
                return (diff / minute) + "m";
            }

            if (diff < day) {
                return (diff / hour) + "h";
            }

            return (diff / day) + "d";
        }

        class ChatViewHolder extends RecyclerView.ViewHolder {
            LinearLayout root;
            AvatarView avatar;
            LinearLayout bubbleWrap;
            TextView meta;
            LinearLayout replyWrap;
            View replyLine;
            TextView replyName;
            TextView replyText;
            TextView body;
            ImageView gifView;
            TextView edited;

            ChatViewHolder(
                    @NonNull View itemView,
                    AvatarView avatar,
                    LinearLayout bubbleWrap,
                    TextView meta,
                    LinearLayout replyWrap,
                    View replyLine,
                    TextView replyName,
                    TextView replyText,
                    TextView body,
                    ImageView gifView,
                    TextView edited
            ) {
                super(itemView);
                this.root = (LinearLayout) itemView;
                this.avatar = avatar;
                this.bubbleWrap = bubbleWrap;
                this.meta = meta;
                this.replyWrap = replyWrap;
                this.replyLine = replyLine;
                this.replyName = replyName;
                this.replyText = replyText;
                this.body = body;
                this.gifView = gifView;
                this.edited = edited;
            }
        }
    }

    private class AvatarView extends View {
        private final Paint fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint borderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint imagePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Matrix shaderMatrix = new Matrix();

        private String initial = "T";
        private Bitmap bitmap;
        private BitmapShader shader;

        AvatarView(GlobalChatActivity context) {
            super(context);

            fillPaint.setColor(Color.rgb(31, 51, 83));
            borderPaint.setColor(Color.rgb(67, 94, 142));
            borderPaint.setStyle(Paint.Style.STROKE);
            borderPaint.setStrokeWidth(dp(1));

            textPaint.setColor(Color.WHITE);
            textPaint.setTextAlign(Paint.Align.CENTER);
            textPaint.setTypeface(Typeface.DEFAULT_BOLD);
            textPaint.setTextSize(dp(14));
        }

        void setAvatar(String name, String photoBase64, boolean isPrivate) {
            String safeName = firstNonEmpty(name, "Trader");
            initial = safeName.substring(0, 1).toUpperCase(Locale.US);

            bitmap = null;
            shader = null;
            imagePaint.setShader(null);

            if (!isPrivate && !firstNonEmpty(photoBase64, "").isEmpty()) {
                bitmap = decodeBase64Bitmap(photoBase64);

                if (bitmap != null) {
                    shader = new BitmapShader(bitmap, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
                    imagePaint.setShader(shader);
                }
            }

            invalidate();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);

            float width = getWidth();
            float height = getHeight();
            float radius = Math.min(width, height) / 2f;
            float cx = width / 2f;
            float cy = height / 2f;

            if (bitmap != null && shader != null) {
                float scale = Math.max(width / bitmap.getWidth(), height / bitmap.getHeight());
                float dx = (width - bitmap.getWidth() * scale) / 2f;
                float dy = (height - bitmap.getHeight() * scale) / 2f;

                shaderMatrix.reset();
                shaderMatrix.setScale(scale, scale);
                shaderMatrix.postTranslate(dx, dy);
                shader.setLocalMatrix(shaderMatrix);

                canvas.drawCircle(cx, cy, radius - dp(1), imagePaint);
            } else {
                canvas.drawCircle(cx, cy, radius - dp(1), fillPaint);

                Paint.FontMetrics metrics = textPaint.getFontMetrics();
                float textY = cy - (metrics.ascent + metrics.descent) / 2f;
                canvas.drawText(initial, cx, textY, textPaint);
            }

            canvas.drawCircle(cx, cy, radius - dp(1), borderPaint);
        }
    }
}
