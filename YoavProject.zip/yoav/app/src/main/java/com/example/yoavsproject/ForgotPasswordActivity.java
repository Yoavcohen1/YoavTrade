package com.example.yoavsproject;

import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import com.google.firebase.auth.FirebaseAuth;

public class ForgotPasswordActivity extends AppCompatActivity {

    private EditText etForgotEmail;
    private Button btnResetPassword;
    private TextView tvBackToLogin;

    private FirebaseAuth auth;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        AppSettingsManager.applySavedUi(this);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);

        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        auth = FirebaseAuth.getInstance();

        bindViews();
        setupClicks();
    }

    private void bindViews() {
        etForgotEmail = findViewById(R.id.etForgotEmail);
        btnResetPassword = findViewById(R.id.btnResetPassword);
        tvBackToLogin = findViewById(R.id.tvBackToLogin);
    }

    private void setupClicks() {
        if (etForgotEmail != null) {
            etForgotEmail.setOnFocusChangeListener((v, hasFocus) -> {
                if (!hasFocus && etForgotEmail.getText() != null) {
                    String original = etForgotEmail.getText().toString();
                    String corrected = EmailCorrectionUtil.correct(original);
                    if (EmailCorrectionUtil.wasCorrected(original, corrected)) {
                        etForgotEmail.setText(corrected);
                        etForgotEmail.setSelection(etForgotEmail.getText().length());
                    }
                }
            });
        }

        if (btnResetPassword != null) {
            btnResetPassword.setOnClickListener(v -> sendResetEmail());
        }

        if (tvBackToLogin != null) {
            tvBackToLogin.setOnClickListener(v -> finish());
        }
    }

    private void sendResetEmail() {
        String originalEmail = safeText(etForgotEmail);
        String email = EmailCorrectionUtil.correct(originalEmail);

        if (etForgotEmail != null && EmailCorrectionUtil.wasCorrected(originalEmail, email)) {
            etForgotEmail.setText(email);
            etForgotEmail.setSelection(etForgotEmail.getText().length());
        }

        if (TextUtils.isEmpty(email) || !Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            etForgotEmail.setError("Enter valid email");
            etForgotEmail.requestFocus();
            return;
        }

        btnResetPassword.setEnabled(false);
        btnResetPassword.setText("Sending...");

        auth.sendPasswordResetEmail(email)
                .addOnCompleteListener(task -> {
                    btnResetPassword.setEnabled(true);
                    btnResetPassword.setText("Send reset link");

                    if (task.isSuccessful()) {
                        Toast.makeText(
                                this,
                                "Password reset link sent. Check your email.",
                                Toast.LENGTH_LONG
                        ).show();

                        finish();
                    } else {
                        String message = task.getException() != null
                                ? task.getException().getMessage()
                                : "Could not send reset email";

                        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
                    }
                });
    }

    private String safeText(EditText editText) {
        return editText == null || editText.getText() == null
                ? ""
                : editText.getText().toString().trim();
    }
}