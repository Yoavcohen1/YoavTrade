package com.example.yoavsproject;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;







public class NewsAdapter extends RecyclerView.Adapter<NewsAdapter.VH> {

    private final List<NewsArticle> items = new ArrayList<>();

    public void submit(List<NewsArticle> list) {
        final List<NewsArticle> newItems = new ArrayList<>();

        if (list != null) {
            for (NewsArticle article : list) {
                if (article == null) {
                    continue;
                }

                String title = clean(article.title);
                String link = clean(article.link);

                
                if (title.isEmpty() && link.isEmpty()) {
                    continue;
                }

                newItems.add(article);
            }
        }

        DiffUtil.DiffResult diffResult = DiffUtil.calculateDiff(new DiffUtil.Callback() {
            @Override
            public int getOldListSize() {
                return items.size();
            }

            @Override
            public int getNewListSize() {
                return newItems.size();
            }

            @Override
            public boolean areItemsTheSame(int oldItemPosition, int newItemPosition) {
                NewsArticle oldItem = items.get(oldItemPosition);
                NewsArticle newItem = newItems.get(newItemPosition);

                String oldStableId = stableId(oldItem);
                String newStableId = stableId(newItem);

                return !oldStableId.isEmpty() && oldStableId.equals(newStableId);
            }

            @Override
            public boolean areContentsTheSame(int oldItemPosition, int newItemPosition) {
                NewsArticle oldItem = items.get(oldItemPosition);
                NewsArticle newItem = newItems.get(newItemPosition);

                return clean(oldItem.title).equals(clean(newItem.title))
                        && clean(oldItem.snippet).equals(clean(newItem.snippet))
                        && clean(oldItem.sourceName).equals(clean(newItem.sourceName))
                        && clean(oldItem.publishedUtc).equals(clean(newItem.publishedUtc))
                        && clean(oldItem.imageUrl).equals(clean(newItem.imageUrl))
                        && clean(oldItem.link).equals(clean(newItem.link));
            }
        });

        items.clear();
        items.addAll(newItems);
        diffResult.dispatchUpdatesTo(this);
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_news_article, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        NewsArticle article = items.get(position);

        String title = clean(article.title);
        String snippet = clean(article.snippet);
        String link = clean(article.link);

        h.tvTitle.setText(title.isEmpty() ? "Untitled market update" : title);
        h.tvSnippet.setText(snippet.isEmpty() ? "Tap to read the full story and market context." : snippet);
        h.tvMeta.setText(buildMeta(article));

        bindImage(h.imgThumb, article.imageUrl);

        boolean canOpen = !link.isEmpty();
        h.itemView.setEnabled(canOpen);
        h.itemView.setAlpha(canOpen ? 1f : 0.92f);
        h.itemView.setOnClickListener(v -> openLink(v.getContext(), link));
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class VH extends RecyclerView.ViewHolder {
        final ImageView imgThumb;
        final TextView tvTitle;
        final TextView tvSnippet;
        final TextView tvMeta;

        VH(@NonNull View itemView) {
            super(itemView);
            imgThumb = itemView.findViewById(R.id.imgThumb);
            tvTitle = itemView.findViewById(R.id.tvTitle);
            tvSnippet = itemView.findViewById(R.id.tvSnippet);
            tvMeta = itemView.findViewById(R.id.tvMeta);
        }
    }

    private void bindImage(ImageView imageView, String rawUrl) {
        String imageUrl = cleanImageUrl(rawUrl);

        if (imageUrl.isEmpty()) {
            imageView.setImageResource(R.drawable.bg_placeholder_square);
            return;
        }

        Glide.with(imageView)
                .load(imageUrl)
                .thumbnail(0.25f)
                .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
                .placeholder(R.drawable.bg_placeholder_square)
                .error(R.drawable.bg_placeholder_square)
                .fallback(R.drawable.bg_placeholder_square)
                .centerCrop()
                .dontAnimate()
                .into(imageView);
    }

    private String buildMeta(NewsArticle article) {
        String source = clean(article.sourceName);
        String time = toRelativeTime(article.publishedUtc);
        String domain = extractDomain(article.link);

        if (source.isEmpty()) {
            source = domain.isEmpty() ? "Market News" : domain;
        }

        if (!domain.isEmpty() && !source.equalsIgnoreCase(domain)) {
            return source + " • " + time + " • " + domain;
        }

        return source + " • " + time;
    }

    private String toRelativeTime(String utcIso) {
        Date date = parseDate(utcIso);

        if (date == null) {
            return "Latest";
        }

        long diffMs = Math.max(0, System.currentTimeMillis() - date.getTime());
        long minutes = diffMs / 60000L;

        if (minutes < 1) {
            return "Just now";
        }

        if (minutes < 60) {
            return minutes + "m ago";
        }

        long hours = minutes / 60L;
        if (hours < 24) {
            return hours + "h ago";
        }

        long days = hours / 24L;
        if (days < 7) {
            return days + "d ago";
        }

        SimpleDateFormat display = new SimpleDateFormat("MMM d", Locale.US);
        return display.format(date);
    }

    private Date parseDate(String rawDate) {
        String value = clean(rawDate);

        if (value.isEmpty()) {
            return null;
        }

        String[] patterns = new String[]{
                "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
                "yyyy-MM-dd'T'HH:mm:ss'Z'",
                "yyyy-MM-dd'T'HH:mm:ssXXX",
                "yyyy-MM-dd HH:mm:ss",
                "EEE, dd MMM yyyy HH:mm:ss zzz"
        };

        for (String pattern : patterns) {
            try {
                SimpleDateFormat format = new SimpleDateFormat(pattern, Locale.US);
                format.setTimeZone(TimeZone.getTimeZone("UTC"));
                Date parsed = format.parse(value);
                if (parsed != null) {
                    return parsed;
                }
            } catch (Exception ignored) {
            }
        }

        return null;
    }

    private String extractDomain(String rawUrl) {
        String url = clean(rawUrl);

        if (url.isEmpty()) {
            return "";
        }

        try {
            Uri uri = Uri.parse(url);
            String host = uri.getHost();

            if (host == null || host.trim().isEmpty()) {
                return "";
            }

            host = host.toLowerCase(Locale.US).trim();

            if (host.startsWith("www.")) {
                host = host.substring(4);
            }

            if (host.startsWith("m.")) {
                host = host.substring(2);
            }

            return host;
        } catch (Exception ignored) {
            return "";
        }
    }

    private void openLink(Context ctx, String rawUrl) {
        String url = clean(rawUrl);

        if (ctx == null || url.isEmpty()) {
            return;
        }

        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            intent.addCategory(Intent.CATEGORY_BROWSABLE);
            ctx.startActivity(intent);
        } catch (Exception ignored) {
        }
    }

    private static String stableId(NewsArticle article) {
        if (article == null) {
            return "";
        }

        String id = clean(article.id);
        if (!id.isEmpty()) {
            return id;
        }

        String link = clean(article.link);
        if (!link.isEmpty()) {
            return link;
        }

        return clean(article.title);
    }

    private static String cleanImageUrl(String value) {
        String url = clean(value);

        if (url.isEmpty()) {
            return "";
        }

        String lower = url.toLowerCase(Locale.US);

        if (!lower.startsWith("http://") && !lower.startsWith("https://")) {
            return "";
        }

        return url;
    }

    private static String clean(String value) {
        if (value == null) {
            return "";
        }

        String clean = value.trim();

        if (clean.isEmpty()) {
            return "";
        }

        if ("null".equalsIgnoreCase(clean)
                || "none".equalsIgnoreCase(clean)
                || "undefined".equalsIgnoreCase(clean)
                || "n/a".equalsIgnoreCase(clean)) {
            return "";
        }

        return clean;
    }
}