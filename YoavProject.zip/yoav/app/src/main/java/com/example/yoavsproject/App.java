
package com.example.yoavsproject;

import android.app.Application;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;





public class App extends Application {

    private static boolean didWarmDiscover = false;
    private static final Map<String, List<NewsArticle>> discoverSessionCache = new HashMap<>();
    private static final List<NewsArticle> latestDiscoverArticles = new ArrayList<>();

    @Override
    

    public void onCreate() {
        super.onCreate();
        AppSettingsManager.applySavedUi(this);
        discoverSessionCache.clear();
        latestDiscoverArticles.clear();
        warmDiscoverFeedOnce();
    }

    public static synchronized List<NewsArticle> getDiscoverSessionCache(String timeKey) {
        List<NewsArticle> list = discoverSessionCache.get(timeKey);
        return list == null ? null : new ArrayList<>(list);
    }

    public static synchronized void setDiscoverSessionCache(String timeKey, List<NewsArticle> articles) {
        if (timeKey == null || articles == null || articles.isEmpty()) return;
        discoverSessionCache.put(timeKey, new ArrayList<>(articles));
        setLatestDiscoverArticles(articles);
    }

    public static synchronized void setLatestDiscoverArticles(List<NewsArticle> articles) {
        latestDiscoverArticles.clear();
        if (articles == null || articles.isEmpty()) return;

        LinkedHashMap<String, NewsArticle> dedup = new LinkedHashMap<>();
        for (NewsArticle a : articles) {
            if (a == null || a.title == null || a.title.trim().isEmpty()) continue;
            String key = a.title.trim().toLowerCase();
            if (!dedup.containsKey(key)) dedup.put(key, a);
            if (dedup.size() >= 8) break;
        }
        latestDiscoverArticles.addAll(dedup.values());
    }

    public static synchronized List<NewsArticle> getLatestDiscoverArticles() {
        return new ArrayList<>(latestDiscoverArticles);
    }

    private synchronized void warmDiscoverFeedOnce() {
        if (didWarmDiscover) return;
        didWarmDiscover = true;

        NewsApiClient.fetchNewsAsync("news", "1h", new NewsApiClient.NewsCallback() {
            @Override
            public void onSuccess(List<NewsArticle> articles) {
                if (articles != null && !articles.isEmpty()) {
                    setDiscoverSessionCache("1h", articles);
                }
            }

            @Override
            public void onError(Exception e) {
            }
        });
    }
}
