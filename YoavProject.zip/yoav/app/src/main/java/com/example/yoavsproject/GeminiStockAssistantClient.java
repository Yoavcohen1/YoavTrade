package com.example.yoavsproject;

public class GeminiStockAssistantClient {

    public interface Callback {
        void onSuccess(String text);
        void onError(Exception e);
    }

    private GeminiStockAssistantClient() {
    }

    public static void ask(String question, String context, final Callback cb) {
        if (cb == null) return;

        String q = question == null ? "" : question.trim();
        String c = context == null ? "" : context.trim();

        StringBuilder prompt = new StringBuilder();

        prompt.append("You are the AI assistant inside an Android finance and virtual trading app.\n");
        prompt.append("Your job is to help the user understand stocks, portfolio data, financial news articles, and app features.\n");
        prompt.append("Answer in a clear, friendly, useful style that fits a mobile chat screen.\n");
        prompt.append("Use short paragraphs and bullet points when helpful.\n");
        prompt.append("Do not write very long answers unless the user asks for detail.\n");
        prompt.append("Do not give guaranteed investment advice. Explain risk and uncertainty when discussing stocks.\n");
        prompt.append("Do not pretend to have live market data unless it appears in the context.\n");
        prompt.append("If the user asks about an article, use the cached article information from the context.\n");
        prompt.append("When discussing an article, include: short summary, why it matters, possible stock/sector impact, risks, and what the user may watch next.\n");
        prompt.append("If there are multiple cached articles, choose the most relevant one based on the user's question.\n");
        prompt.append("If the context does not contain enough information, say what is missing and answer only from the available context.\n");
        prompt.append("If portfolio data is available, connect the answer to the user's cash balance or holdings when relevant.\n");
        prompt.append("Do not tell the user to open an article before answering. Discuss articles directly inside the AI chat.\n\n");

        prompt.append("APP AND ARTICLE CONTEXT:\n");
        prompt.append(c.isEmpty() ? "No extra context available.\n" : c + "\n");

        prompt.append("\nUSER QUESTION:\n");
        prompt.append(q.isEmpty() ? "Hello" : q);

        GeminiApiManager.getInstance().requestDebounced(
                prompt.toString(),
                new GeminiApiManager.Callback() {
                    @Override
                    public void onSuccess(String text) {
                        cb.onSuccess(text);
                    }

                    @Override
                    public void onError(Exception e) {
                        cb.onError(e);
                    }
                }
        );
    }
}
