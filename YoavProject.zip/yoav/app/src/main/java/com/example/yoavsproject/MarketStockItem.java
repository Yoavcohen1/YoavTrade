package com.example.yoavsproject;




public class MarketStockItem {
    public final String symbol;
    public final String name;
    public final String priceText;
    public final String changeText;
    public final boolean positive;
    public final int logoResId;

    public MarketStockItem(
            String symbol,
            String name,
            String priceText,
            String changeText,
            boolean positive,
            int logoResId
    ) {
        this.symbol = symbol;
        this.name = name;
        this.priceText = priceText;
        this.changeText = changeText;
        this.positive = positive;
        this.logoResId = logoResId;
    }

    public MarketStockItem withQuote(String newPriceText, String newChangeText, boolean newPositive) {
        return new MarketStockItem(
                symbol,
                name,
                newPriceText,
                newChangeText,
                newPositive,
                logoResId
        );
    }
}