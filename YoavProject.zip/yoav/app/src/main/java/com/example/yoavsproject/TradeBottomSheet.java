package com.example.yoavsproject;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;

import java.util.Locale;

public class TradeBottomSheet {

    public enum Mode { BUY, SELL }
    public enum InputMode { SHARES, AMOUNT }

    public static void show(
            Context ctx,
            String symbol,
            String companyName,
            Double livePrice,
            Mode initialMode,
            Runnable onDone
    ) {
        BottomSheetDialog dialog = new BottomSheetDialog(ctx);
        View view = LayoutInflater.from(ctx).inflate(R.layout.bottomsheet_trade, null, false);
        dialog.setContentView(view);
        dialog.setOnShowListener(d -> makeDialogFullWidthAndTransparent(dialog));

        ImageView ivTradeLogo = view.findViewById(R.id.ivTradeLogo);
        TextView tvSymbol = view.findViewById(R.id.tvTradeSymbol);
        TextView tvName = view.findViewById(R.id.tvTradeName);
        TextView tvPrice = view.findViewById(R.id.tvTradePrice);

        TextView btnModeBuy = view.findViewById(R.id.btnModeBuy);
        TextView btnModeSell = view.findViewById(R.id.btnModeSell);

        TextView btnInputShares = view.findViewById(R.id.btnInputShares);
        TextView btnInputAmount = view.findViewById(R.id.btnInputAmount);

        EditText etTradeInput = view.findViewById(R.id.etTradeInput);
        TextView tvTradeComputedQty = view.findViewById(R.id.tvTradeComputedQty);
        TextView tvTotalLabel = view.findViewById(R.id.tvTradeTotalLabel);
        TextView tvTotal = view.findViewById(R.id.tvTradeTotal);
        TextView tvBudgetHint = view.findViewById(R.id.tvTradeBudgetHint);
        TextView btnConfirm = view.findViewById(R.id.btnTradeConfirm);

        final String safeSymbol = symbol == null ? "" : symbol.trim().toUpperCase(Locale.US);
        final String safeCompanyName = (companyName == null || companyName.trim().isEmpty())
                ? (safeSymbol.isEmpty() ? "Stock" : safeSymbol)
                : companyName.trim();

        final double[] currentPrice = new double[]{livePrice == null ? 0.0 : livePrice};
        final Mode[] currentMode = new Mode[]{initialMode == null ? Mode.BUY : initialMode};
        final InputMode[] currentInputMode = new InputMode[]{InputMode.SHARES};

        final double[] availableCash = new double[]{0.0};
        final boolean[] cashLoaded = new boolean[]{false};

        final double[] ownedShares = new double[]{0.0};
        final boolean[] holdingsLoaded = new boolean[]{false};

        StockLogoMapper.bind(ivTradeLogo, safeSymbol);
        tvSymbol.setText(safeSymbol.isEmpty() ? "-" : safeSymbol);
        tvName.setText(safeCompanyName);
        tvPrice.setText(currentPrice[0] > 0 ? formatMoney(currentPrice[0]) : "Loading...");

        applyModeStyles(btnModeBuy, btnModeSell, btnConfirm, currentMode[0], safeSymbol);
        applyInputModeStyles(btnInputShares, btnInputAmount, etTradeInput, currentInputMode[0]);

        PortfolioManager.getInstance().fetchCashBalance((cash, errorMessage) -> {
            cashLoaded[0] = errorMessage == null;
            availableCash[0] = cash;

            refreshSummary(
                    safeSymbol,
                    etTradeInput,
                    tvTradeComputedQty,
                    tvTotalLabel,
                    tvTotal,
                    tvBudgetHint,
                    btnConfirm,
                    currentPrice[0],
                    currentMode[0],
                    currentInputMode[0],
                    availableCash[0],
                    cashLoaded[0],
                    ownedShares[0],
                    holdingsLoaded[0]
            );
        });

        PortfolioManager.getInstance().fetchHoldingQuantity(safeSymbol, (quantity, errorMessage) -> {
            holdingsLoaded[0] = errorMessage == null;
            ownedShares[0] = quantity;

            refreshSummary(
                    safeSymbol,
                    etTradeInput,
                    tvTradeComputedQty,
                    tvTotalLabel,
                    tvTotal,
                    tvBudgetHint,
                    btnConfirm,
                    currentPrice[0],
                    currentMode[0],
                    currentInputMode[0],
                    availableCash[0],
                    cashLoaded[0],
                    ownedShares[0],
                    holdingsLoaded[0]
            );
        });

        if (currentPrice[0] <= 0 && !safeSymbol.isEmpty()) {
            AlphaVantageClient.lastPriceAsync(safeSymbol, new AlphaVantageClient.PriceCallback() {
                @Override
                public void onSuccess(double price) {
                    currentPrice[0] = price;
                    tvPrice.setText(formatMoney(price));

                    refreshSummary(
                            safeSymbol,
                            etTradeInput,
                            tvTradeComputedQty,
                            tvTotalLabel,
                            tvTotal,
                            tvBudgetHint,
                            btnConfirm,
                            currentPrice[0],
                            currentMode[0],
                            currentInputMode[0],
                            availableCash[0],
                            cashLoaded[0],
                            ownedShares[0],
                            holdingsLoaded[0]
                    );
                }

                @Override
                public void onError(Exception e) {
                    tvPrice.setText("--");

                    refreshSummary(
                            safeSymbol,
                            etTradeInput,
                            tvTradeComputedQty,
                            tvTotalLabel,
                            tvTotal,
                            tvBudgetHint,
                            btnConfirm,
                            currentPrice[0],
                            currentMode[0],
                            currentInputMode[0],
                            availableCash[0],
                            cashLoaded[0],
                            ownedShares[0],
                            holdingsLoaded[0]
                    );
                }
            });
        }

        etTradeInput.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                refreshSummary(
                        safeSymbol,
                        etTradeInput,
                        tvTradeComputedQty,
                        tvTotalLabel,
                        tvTotal,
                        tvBudgetHint,
                        btnConfirm,
                        currentPrice[0],
                        currentMode[0],
                        currentInputMode[0],
                        availableCash[0],
                        cashLoaded[0],
                        ownedShares[0],
                        holdingsLoaded[0]
                );
            }
        });

        btnModeBuy.setOnClickListener(v -> {
            currentMode[0] = Mode.BUY;
            applyModeStyles(btnModeBuy, btnModeSell, btnConfirm, currentMode[0], safeSymbol);

            refreshSummary(
                    safeSymbol,
                    etTradeInput,
                    tvTradeComputedQty,
                    tvTotalLabel,
                    tvTotal,
                    tvBudgetHint,
                    btnConfirm,
                    currentPrice[0],
                    currentMode[0],
                    currentInputMode[0],
                    availableCash[0],
                    cashLoaded[0],
                    ownedShares[0],
                    holdingsLoaded[0]
            );
        });

        btnModeSell.setOnClickListener(v -> {
            currentMode[0] = Mode.SELL;
            applyModeStyles(btnModeBuy, btnModeSell, btnConfirm, currentMode[0], safeSymbol);

            refreshSummary(
                    safeSymbol,
                    etTradeInput,
                    tvTradeComputedQty,
                    tvTotalLabel,
                    tvTotal,
                    tvBudgetHint,
                    btnConfirm,
                    currentPrice[0],
                    currentMode[0],
                    currentInputMode[0],
                    availableCash[0],
                    cashLoaded[0],
                    ownedShares[0],
                    holdingsLoaded[0]
            );
        });

        btnInputShares.setOnClickListener(v -> {
            currentInputMode[0] = InputMode.SHARES;
            applyInputModeStyles(btnInputShares, btnInputAmount, etTradeInput, currentInputMode[0]);

            refreshSummary(
                    safeSymbol,
                    etTradeInput,
                    tvTradeComputedQty,
                    tvTotalLabel,
                    tvTotal,
                    tvBudgetHint,
                    btnConfirm,
                    currentPrice[0],
                    currentMode[0],
                    currentInputMode[0],
                    availableCash[0],
                    cashLoaded[0],
                    ownedShares[0],
                    holdingsLoaded[0]
            );
        });

        btnInputAmount.setOnClickListener(v -> {
            currentInputMode[0] = InputMode.AMOUNT;
            applyInputModeStyles(btnInputShares, btnInputAmount, etTradeInput, currentInputMode[0]);

            refreshSummary(
                    safeSymbol,
                    etTradeInput,
                    tvTradeComputedQty,
                    tvTotalLabel,
                    tvTotal,
                    tvBudgetHint,
                    btnConfirm,
                    currentPrice[0],
                    currentMode[0],
                    currentInputMode[0],
                    availableCash[0],
                    cashLoaded[0],
                    ownedShares[0],
                    holdingsLoaded[0]
            );
        });

        btnConfirm.setOnClickListener(v -> {
            if (currentPrice[0] <= 0) {
                Toast.makeText(ctx, "Live price unavailable right now", Toast.LENGTH_SHORT).show();
                return;
            }

            double entered = parseDouble(etTradeInput.getText() == null ? "" : etTradeInput.getText().toString());
            if (entered <= 0) {
                Toast.makeText(ctx,
                        currentInputMode[0] == InputMode.SHARES
                                ? "Enter number of shares"
                                : "Enter amount",
                        Toast.LENGTH_SHORT
                ).show();
                return;
            }

            double quantity = currentInputMode[0] == InputMode.SHARES
                    ? entered
                    : entered / currentPrice[0];

            if (quantity <= 0) {
                Toast.makeText(ctx, "Invalid order", Toast.LENGTH_SHORT).show();
                return;
            }

            if (currentMode[0] == Mode.BUY) {
                if (!cashLoaded[0]) {
                    Toast.makeText(ctx, "Still checking available cash", Toast.LENGTH_SHORT).show();
                    return;
                }

                double total = quantity * currentPrice[0];
                if (total > availableCash[0] + 0.000001d) {
                    Toast.makeText(ctx, "Not enough cash for this purchase", Toast.LENGTH_SHORT).show();
                    return;
                }
            } else {
                if (!holdingsLoaded[0]) {
                    Toast.makeText(ctx, "Still checking your holdings", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (quantity > ownedShares[0] + 0.000001d) {
                    Toast.makeText(ctx, "You do not own enough shares to sell", Toast.LENGTH_SHORT).show();
                    return;
                }
            }

            setConfirmEnabled(btnConfirm, false);

            PortfolioManager.SimpleCallback callback = (success, message) -> {
                setConfirmEnabled(btnConfirm, true);
                Toast.makeText(ctx, message, Toast.LENGTH_LONG).show();

                if (success) {
                    dialog.dismiss();
                    if (onDone != null) {
                        onDone.run();
                    }
                } else {
                    PortfolioManager.getInstance().fetchCashBalance((cash, errorMessage) -> {
                        cashLoaded[0] = errorMessage == null;
                        availableCash[0] = cash;

                        refreshSummary(
                                safeSymbol,
                                etTradeInput,
                                tvTradeComputedQty,
                                tvTotalLabel,
                                tvTotal,
                                tvBudgetHint,
                                btnConfirm,
                                currentPrice[0],
                                currentMode[0],
                                currentInputMode[0],
                                availableCash[0],
                                cashLoaded[0],
                                ownedShares[0],
                                holdingsLoaded[0]
                        );
                    });

                    PortfolioManager.getInstance().fetchHoldingQuantity(safeSymbol, (quantity1, errorMessage) -> {
                        holdingsLoaded[0] = errorMessage == null;
                        ownedShares[0] = quantity1;

                        refreshSummary(
                                safeSymbol,
                                etTradeInput,
                                tvTradeComputedQty,
                                tvTotalLabel,
                                tvTotal,
                                tvBudgetHint,
                                btnConfirm,
                                currentPrice[0],
                                currentMode[0],
                                currentInputMode[0],
                                availableCash[0],
                                cashLoaded[0],
                                ownedShares[0],
                                holdingsLoaded[0]
                        );
                    });
                }
            };

            if (currentMode[0] == Mode.BUY) {
                PortfolioManager.getInstance().buyStock(safeSymbol, quantity, currentPrice[0], callback);
            } else {
                PortfolioManager.getInstance().sellStock(safeSymbol, quantity, currentPrice[0], callback);
            }
        });

        refreshSummary(
                safeSymbol,
                etTradeInput,
                tvTradeComputedQty,
                tvTotalLabel,
                tvTotal,
                tvBudgetHint,
                btnConfirm,
                currentPrice[0],
                currentMode[0],
                currentInputMode[0],
                availableCash[0],
                cashLoaded[0],
                ownedShares[0],
                holdingsLoaded[0]
        );

        dialog.show();
    }

    private static void makeDialogFullWidthAndTransparent(BottomSheetDialog dialog) {
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }

        FrameLayout bottomSheet = dialog.findViewById(com.google.android.material.R.id.design_bottom_sheet);
        if (bottomSheet == null) return;

        bottomSheet.setBackgroundColor(Color.TRANSPARENT);
        bottomSheet.setPadding(0, 0, 0, 0);

        ViewGroup.LayoutParams layoutParams = bottomSheet.getLayoutParams();
        if (layoutParams != null) {
            layoutParams.width = ViewGroup.LayoutParams.MATCH_PARENT;
            bottomSheet.setLayoutParams(layoutParams);
        }

        BottomSheetBehavior<FrameLayout> behavior = BottomSheetBehavior.from(bottomSheet);
        behavior.setSkipCollapsed(true);
        behavior.setState(BottomSheetBehavior.STATE_EXPANDED);
    }

    private static void refreshSummary(
            String symbol,
            EditText input,
            TextView tvComputedQty,
            TextView tvTotalLabel,
            TextView tvTotal,
            TextView tvBudgetHint,
            TextView btnConfirm,
            double price,
            Mode mode,
            InputMode inputMode,
            double availableCash,
            boolean cashLoaded,
            double ownedShares,
            boolean holdingsLoaded
    ) {
        double entered = parseDouble(input.getText() == null ? "" : input.getText().toString());

        double quantity = inputMode == InputMode.SHARES
                ? entered
                : (price > 0 ? entered / price : 0.0);

        double total = quantity * price;

        String qtyLabel = inputMode == InputMode.SHARES
                ? "Shares"
                : "Estimated shares";

        tvComputedQty.setText(qtyLabel + ": " + formatQty(quantity));
        tvTotalLabel.setText(mode == Mode.BUY ? "Order value" : "Estimated proceeds");
        tvTotal.setText(price > 0 ? formatMoney(total) : "--");

        if (price <= 0) {
            tvBudgetHint.setText("Loading live price...");
            tvBudgetHint.setTextColor(0xFFFF9A9A);
            setConfirmEnabled(btnConfirm, false);
            return;
        }

        if (entered <= 0) {
            if (mode == Mode.BUY) {
                tvBudgetHint.setText(inputMode == InputMode.SHARES
                        ? "Enter how many shares you want to buy"
                        : "Enter amount");
            } else {
                tvBudgetHint.setText(inputMode == InputMode.SHARES
                        ? "Enter how many shares you want to sell"
                        : "");
            }

            tvBudgetHint.setTextColor(0xFF9AA7BA);
            setConfirmEnabled(btnConfirm, false);
            return;
        }

        if (mode == Mode.BUY) {
            if (!cashLoaded) {
                tvBudgetHint.setText("Checking available cash...");
                tvBudgetHint.setTextColor(0xFF9AA7BA);
                setConfirmEnabled(btnConfirm, false);
                return;
            }

            if (total > availableCash + 0.000001d) {
                double missing = total - availableCash;

                tvBudgetHint.setText(
                        "Missing " + formatMoney(missing)
                                + " • Available " + formatMoney(availableCash)
                );

                tvBudgetHint.setTextColor(0xFFFF9A9A);
                setConfirmEnabled(btnConfirm, false);
            } else {
                double after = availableCash - total;

                tvBudgetHint.setText(
                        "Available " + formatMoney(availableCash)
                                + " • After buy " + formatMoney(after)
                );

                tvBudgetHint.setTextColor(0xFF9EE0B0);
                setConfirmEnabled(btnConfirm, true);
            }
        } else {
            if (!holdingsLoaded) {
                tvBudgetHint.setText("Checking your holdings...");
                tvBudgetHint.setTextColor(0xFF9AA7BA);
                setConfirmEnabled(btnConfirm, false);
                return;
            }

            if (ownedShares <= 0.0000001d) {
                tvBudgetHint.setText("You do not own any " + symbol + " shares");
                tvBudgetHint.setTextColor(0xFFFF9A9A);
                setConfirmEnabled(btnConfirm, false);
                return;
            }

            if (quantity > ownedShares + 0.000001d) {
                tvBudgetHint.setText(
                        "You own " + formatQty(ownedShares)
                                + " shares • Trying to sell " + formatQty(quantity)
                );

                tvBudgetHint.setTextColor(0xFFFF9A9A);
                setConfirmEnabled(btnConfirm, false);
            } else {
                double remaining = ownedShares - quantity;

                tvBudgetHint.setText(
                        "Owned " + formatQty(ownedShares)
                                + " shares • Remaining " + formatQty(remaining)
                );

                tvBudgetHint.setTextColor(0xFF9EE0B0);
                setConfirmEnabled(btnConfirm, true);
            }
        }
    }

    private static void applyModeStyles(
            TextView buy,
            TextView sell,
            TextView confirm,
            Mode mode,
            String symbol
    ) {
        if (mode == Mode.BUY) {
            buy.setBackgroundResource(R.drawable.bg_trade_segment_active);
            buy.setTextColor(0xFFFFFFFF);

            sell.setBackgroundResource(R.drawable.bg_trade_segment_inactive);
            sell.setTextColor(0xFFDCE7F6);

            confirm.setBackgroundResource(R.drawable.bg_trade_confirm_buy);
            confirm.setText(symbol == null || symbol.isEmpty() ? "Buy" : "Buy " + symbol);
        } else {
            buy.setBackgroundResource(R.drawable.bg_trade_segment_inactive);
            buy.setTextColor(0xFFDCE7F6);

            sell.setBackgroundResource(R.drawable.bg_trade_confirm_sell);
            sell.setTextColor(0xFFFFFFFF);

            confirm.setBackgroundResource(R.drawable.bg_trade_confirm_sell);
            confirm.setText(symbol == null || symbol.isEmpty() ? "Sell" : "Sell " + symbol);
        }
    }

    private static void applyInputModeStyles(
            TextView shares,
            TextView amount,
            EditText input,
            InputMode mode
    ) {
        if (mode == InputMode.SHARES) {
            shares.setBackgroundResource(R.drawable.bg_trade_segment_active);
            shares.setTextColor(0xFFFFFFFF);

            amount.setBackgroundResource(R.drawable.bg_trade_segment_inactive);
            amount.setTextColor(0xFFDCE7F6);

            input.setHint("Enter shares");
        } else {
            shares.setBackgroundResource(R.drawable.bg_trade_segment_inactive);
            shares.setTextColor(0xFFDCE7F6);

            amount.setBackgroundResource(R.drawable.bg_trade_segment_active);
            amount.setTextColor(0xFFFFFFFF);

            input.setHint("Enter amount");
        }
    }

    private static void setConfirmEnabled(TextView confirm, boolean enabled) {
        confirm.setEnabled(enabled);
        confirm.setClickable(enabled);
        confirm.setAlpha(enabled ? 1f : 0.55f);
    }

    private static double parseDouble(String raw) {
        try {
            if (raw == null) return 0.0;

            raw = raw.replace("$", "")
                    .replace(",", "")
                    .trim();

            if (raw.isEmpty()) return 0.0;

            return Double.parseDouble(raw);
        } catch (Exception ignored) {
            return 0.0;
        }
    }

    private static String formatMoney(double value) {
        return String.format(Locale.US, "$%,.2f", value);
    }

    private static String formatQty(double qty) {
        String raw = String.format(Locale.US, "%.4f", qty);

        while (raw.contains(".") && (raw.endsWith("0") || raw.endsWith("."))) {
            raw = raw.substring(0, raw.length() - 1);
        }

        return raw;
    }
}