package com.example.yoavsproject;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import androidx.annotation.NonNull;

import java.util.List;

public final class PriceAlertMonitor {

    private static final long CHECK_INTERVAL_MS = 60_000L;
    private static final long SAME_ALERT_COOLDOWN_MS = 6L * 60L * 60L * 1000L;

    private static Handler handler;
    private static boolean running = false;
    private static Context appContext;

    private PriceAlertMonitor() {
    }

    public static void start(@NonNull Context context) {
        appContext = context.getApplicationContext();

        if (handler == null) {
            handler = new Handler(Looper.getMainLooper());
        }

        if (running) {
            return;
        }

        running = true;
        scheduleNext(1000L);
    }

    public static void stop() {
        running = false;

        if (handler != null) {
            handler.removeCallbacksAndMessages(null);
        }
    }

    private static void scheduleNext(long delay) {
        if (!running || handler == null) {
            return;
        }

        handler.postDelayed(PriceAlertMonitor::checkAlerts, delay);
    }

    private static void checkAlerts() {
        if (!running || appContext == null) {
            return;
        }

        if (!AppSettingsManager.arePriceAlertsEnabled(appContext)) {
            scheduleNext(CHECK_INTERVAL_MS);
            return;
        }

        List<PriceAlert> alerts = PriceAlertStore.getAlerts(appContext);

        for (PriceAlert alert : alerts) {
            if (alert == null || !alert.enabled) {
                continue;
            }

            LivePriceFetcher.fetchPrice(alert.symbol, new LivePriceFetcher.Callback() {
                @Override
                public void onPrice(double price) {
                    if (!alert.shouldTrigger(price)) {
                        return;
                    }

                    long now = System.currentTimeMillis();

                    if (now - alert.lastTriggeredAt < SAME_ALERT_COOLDOWN_MS) {
                        return;
                    }

                    alert.lastTriggeredAt = now;
                    PriceAlertStore.updateAlert(appContext, alert);

                    NotificationHelper.showPriceAlert(
                            appContext,
                            alert.symbol,
                            price,
                            alert.targetPrice,
                            alert.mode
                    );
                }

                @Override
                public void onError(Exception e) {
                    
                }
            });
        }

        scheduleNext(CHECK_INTERVAL_MS);
    }
}