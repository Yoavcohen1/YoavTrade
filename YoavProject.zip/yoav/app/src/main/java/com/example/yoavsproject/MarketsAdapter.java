package com.example.yoavsproject;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MarketsAdapter extends RecyclerView.Adapter<MarketsAdapter.VH> {

    public interface OnStockClickListener {
        void onStockClick(MarketStockItem item);
    }

    private final List<MarketStockItem> items = new ArrayList<>();
    private final OnStockClickListener listener;

    public MarketsAdapter(List<MarketStockItem> items, OnStockClickListener listener) {
        this.listener = listener;
        setItems(items);
    }

    public void setItems(List<MarketStockItem> newItems) {
        items.clear();

        if (newItems != null) {
            items.addAll(newItems);
        }

        notifyDataSetChanged();
    }

    public void updateQuote(String symbol, String priceText, String changeText, boolean positive) {
        String cleanSymbol = symbol == null
                ? ""
                : symbol.trim().toUpperCase(Locale.US);

        if (cleanSymbol.isEmpty()) {
            return;
        }

        for (int i = 0; i < items.size(); i++) {
            MarketStockItem oldItem = items.get(i);

            if (oldItem == null || oldItem.symbol == null) {
                continue;
            }

            String itemSymbol = oldItem.symbol.trim().toUpperCase(Locale.US);

            if (cleanSymbol.equals(itemSymbol)) {
                MarketStockItem updatedItem = oldItem.withQuote(
                        priceText,
                        changeText,
                        positive
                );

                items.set(i, updatedItem);
                notifyItemChanged(i);
                return;
            }
        }
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_market_stock, parent, false);

        return new VH(view);
    }

    @Override
    public void onBindViewHolder(@NonNull VH holder, int position) {
        MarketStockItem item = items.get(position);

        StockLogoMapper.bind(holder.imgLogo, item.symbol);

        holder.tvName.setText(item.name);
        holder.tvSymbol.setText(item.symbol);
        holder.tvPrice.setText(item.priceText);
        holder.tvChange.setText(item.changeText);

        holder.tvChange.setBackgroundResource(
                item.positive
                        ? R.drawable.bg_market_change_positive
                        : R.drawable.bg_market_change_negative
        );

        holder.tvChange.setTextColor(
                item.positive
                        ? 0xFFD9FFE9
                        : 0xFFFFD6DF
        );

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onStockClick(item);
            }
        });
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class VH extends RecyclerView.ViewHolder {

        ImageView imgLogo;
        TextView tvName;
        TextView tvSymbol;
        TextView tvPrice;
        TextView tvChange;

        VH(@NonNull View itemView) {
            super(itemView);

            imgLogo = itemView.findViewById(R.id.imgStockLogo);
            tvName = itemView.findViewById(R.id.tvStockName);
            tvSymbol = itemView.findViewById(R.id.tvStockSymbol);
            tvPrice = itemView.findViewById(R.id.tvStockPrice);
            tvChange = itemView.findViewById(R.id.tvStockChange);
        }
    }
}