package com.example.yoavsproject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;




public class LocalAiFallback {

    public static String answer(String question, String context) {
        String q = question == null ? "" : question.toLowerCase(Locale.US).trim();
        String c = context == null ? "" : context.trim();

        if (q.isEmpty()) {
            return "Ask me about your portfolio, stocks, or the latest financial articles. I can summarize an article, explain why it matters, and connect it to your portfolio when possible.";
        }

        if (q.equals("hi") || q.equals("hello") || q.equals("hey") || q.equals("help")) {
            return "I can help with three main things:\n\n" +
                    "1. Explain your portfolio.\n" +
                    "2. Discuss recent financial articles.\n" +
                    "3. Explain stock ideas, risks, and what to watch next.";
        }

        NewsArticle matched = findBestMatchingArticle(q, App.getLatestDiscoverArticles());
        if (mentionsNews(q) && matched != null) {
            return formatArticleDiscussion(matched);
        }

        if (mentionsPortfolio(q) && !c.isEmpty()) {
            return "Gemini is unavailable right now, but I can still show the latest portfolio context I have:\n\n" + c;
        }

        if (!c.isEmpty() && c.contains("CACHED DISCOVER ARTICLES")) {
            return "Gemini is unavailable right now. I still have recent article context, so try asking about a specific headline or company name. Example: 'Explain the latest article about Apple'.";
        }

        return "Gemini is unavailable right now. Check that the emulator has internet access and that gemini.key in local.properties is valid, then try again.";
    }

    private static boolean mentionsNews(String q) {
        return q.contains("article")
                || q.contains("news")
                || q.contains("headline")
                || q.contains("latest")
                || q.contains("market")
                || q.contains("story")
                || q.contains("report");
    }

    private static boolean mentionsPortfolio(String q) {
        return q.contains("portfolio")
                || q.contains("holding")
                || q.contains("stock")
                || q.contains("invest")
                || q.contains("cash")
                || q.contains("balance");
    }

    private static NewsArticle findBestMatchingArticle(String question, List<NewsArticle> articles) {
        if (articles == null || articles.isEmpty()) return null;

        List<String> tokens = tokenize(question);
        if (tokens.isEmpty()) return articles.get(0);

        int bestScore = -1;
        NewsArticle best = null;

        for (int i = 0; i < articles.size(); i++) {
            NewsArticle a = articles.get(i);
            if (a == null) continue;

            String title = safe(NewsArticleCompatUtil.getTitle(a)).toLowerCase(Locale.US);
            String source = safe(NewsArticleCompatUtil.getSource(a)).toLowerCase(Locale.US);
            String body = safe(NewsArticleCompatUtil.getBody(a)).toLowerCase(Locale.US);
            String all = title + " " + source + " " + body;

            int score = 0;
            for (int j = 0; j < tokens.size(); j++) {
                String token = tokens.get(j);
                if (all.contains(token)) score += 2;
                if (title.contains(token)) score += 3;
            }

            if (score > bestScore) {
                bestScore = score;
                best = a;
            }
        }

        return best == null ? articles.get(0) : best;
    }

    private static List<String> tokenize(String text) {
        List<String> out = new ArrayList<String>();
        if (text == null) return out;

        String[] stop = new String[] {
                "hi","hello","hey","can","could","would","please","give","show","send","me",
                "the","a","an","about","related","to","for","of","on","and","article","articles",
                "news","latest","recent","stock","stocks","what","is","are","right","now","tell","with",
                "summarize","summary","explain","discuss"
        };

        String[] parts = text.toLowerCase(Locale.US).split("\\s+");
        for (int i = 0; i < parts.length; i++) {
            String clean = parts[i].replaceAll("[^a-z0-9]", "").trim();
            if (clean.isEmpty()) continue;

            boolean blocked = false;
            for (int j = 0; j < stop.length; j++) {
                if (stop[j].equals(clean)) {
                    blocked = true;
                    break;
                }
            }

            if (!blocked) out.add(clean);
        }

        return out;
    }

    private static String formatArticleDiscussion(NewsArticle a) {
        String title = safe(NewsArticleCompatUtil.getTitle(a));
        String source = safe(NewsArticleCompatUtil.getSource(a));
        String body = safe(NewsArticleCompatUtil.getBody(a));

        if (body.length() > 520) body = body.substring(0, 520) + "...";

        StringBuilder sb = new StringBuilder();
        sb.append("I found an article to discuss.\n\n");
        sb.append("Title: ").append(title.isEmpty() ? "Recent article" : title).append("\n");
        if (!source.isEmpty()) sb.append("Source: ").append(source).append("\n");

        if (!body.isEmpty()) {
            sb.append("\nSummary:\n").append(body).append("\n");
        }

        sb.append("\nWhy it may matter:\n");
        sb.append("- It may affect investor sentiment around the company, sector, or market topic mentioned.\n");
        sb.append("- Before making a trade, compare the article with price movement, portfolio risk, and other sources.\n");
        sb.append("- This is not a guaranteed buy or sell signal.");

        return sb.toString();
    }

    private static String safe(String v) {
        if (v == null) return "";
        String clean = v.trim();
        if (clean.equalsIgnoreCase("null")
                || clean.equalsIgnoreCase("none")
                || clean.equalsIgnoreCase("undefined")
                || clean.equalsIgnoreCase("n/a")) {
            return "";
        }
        return clean;
    }
}
