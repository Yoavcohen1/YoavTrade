package com.example.yoavsproject;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.List;
import java.util.Locale;

public class TradingDashboardActivity extends AppCompatActivity {

    private static final String NEWS_CACHE_PREFS = "yoav_discover_news_cache";
    private static final String NEWS_KEY_CACHE_JSON = "cached_articles_json";
    private static final String NEWS_KEY_CACHE_TIME = "cached_articles_time";
    private static final long NEWS_CACHE_VALID_MS = 1000L * 60L * 15L;

    private TextView tvGreeting;
    private TextView tvBalance;
    private TextView tvPortfolioValue;
    private TextView tvBuyingPower;

    private FirebaseAuth auth;
    private FirebaseFirestore db;

    private double balance = 0.0;
    private double portfolioValue = 0.0;
    private double buyingPower = 0.0;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        AppSettingsManager.applySavedUi(this);

        super.onCreate(savedInstanceState);

        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        auth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        if (!ensureVerifiedUser()) {
            return;
        }

        buildScreen();
        loadUserData();
        preloadDiscoverNews();

        try {
            PriceAlertMonitor.start(this);
        } catch (Exception ignored) {
        }
    }


    private boolean ensureVerifiedUser() {
        FirebaseUser user = auth.getCurrentUser();

        if (user == null) {
            Intent intent = new Intent(this, AuthChoiceActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
            return false;
        }

        if (user.getEmail() != null && !user.isEmailVerified()) {
            Intent intent = new Intent(this, EmailVerificationActivity.class);
            intent.putExtra(EmailVerificationActivity.EXTRA_AFTER_VERIFY_TO_WELCOME, false);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
            return false;
        }

        return true;
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadUserData();
    }

    private void buildScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(9, 17, 31));

        ScrollView scrollView = new ScrollView(this);
        scrollView.setFillViewport(true);
        scrollView.setOverScrollMode(ScrollView.OVER_SCROLL_NEVER);
        scrollView.setVerticalScrollBarEnabled(false);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(30), dp(72), dp(30), dp(26));

        tvGreeting = new TextView(this);
        tvGreeting.setText("Welcome back");
        tvGreeting.setTextColor(Color.WHITE);
        tvGreeting.setTextSize(28);
        tvGreeting.setTypeface(null, Typeface.BOLD);
        tvGreeting.setGravity(Gravity.CENTER);
        tvGreeting.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);

        TextView subtitle = new TextView(this);
        subtitle.setText("Here is your trading overview");
        subtitle.setTextColor(Color.rgb(142, 160, 188));
        subtitle.setTextSize(14);
        subtitle.setPadding(0, dp(8), 0, dp(22));
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);

        LinearLayout balanceCard = createCard();
        balanceCard.setPadding(dp(18), dp(18), dp(18), dp(18));
        balanceCard.setGravity(Gravity.CENTER);

        TextView balanceLabel = new TextView(this);
        balanceLabel.setText("Available balance");
        balanceLabel.setTextColor(Color.rgb(142, 160, 188));
        balanceLabel.setTextSize(13);
        balanceLabel.setTypeface(null, Typeface.BOLD);
        balanceLabel.setGravity(Gravity.CENTER);
        balanceLabel.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);

        tvBalance = new TextView(this);
        tvBalance.setText("$0.00");
        tvBalance.setTextColor(Color.WHITE);
        tvBalance.setTextSize(34);
        tvBalance.setTypeface(null, Typeface.BOLD);
        tvBalance.setPadding(0, dp(8), 0, 0);
        tvBalance.setGravity(Gravity.CENTER);
        tvBalance.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);

        TextView manageMoney = new TextView(this);
        manageMoney.setText("Manage your money in Settings");
        manageMoney.setTextColor(Color.rgb(34, 197, 94));
        manageMoney.setTextSize(13);
        manageMoney.setTypeface(null, Typeface.BOLD);
        manageMoney.setPadding(0, dp(10), 0, 0);
        manageMoney.setGravity(Gravity.CENTER);
        manageMoney.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        manageMoney.setOnClickListener(v -> openScreen("SettingsActivity"));

        balanceCard.addView(balanceLabel);
        balanceCard.addView(tvBalance);
        balanceCard.addView(manageMoney);

        LinearLayout statsRow = new LinearLayout(this);
        statsRow.setOrientation(LinearLayout.HORIZONTAL);
        statsRow.setPadding(0, dp(16), 0, 0);

        tvPortfolioValue = createStatCard(statsRow, "Portfolio", "$0.00");
        tvBuyingPower = createStatCard(statsRow, "Buying power", "$0.00");

        LinearLayout actionRow = new LinearLayout(this);
        actionRow.setOrientation(LinearLayout.HORIZONTAL);
        actionRow.setPadding(0, dp(18), 0, 0);

        TextView discoverStocks = createPrimaryButton("Discover stocks");
        TextView portfolioButton = createSecondaryButton("Portfolio");

        discoverStocks.setOnClickListener(v -> openScreen("StocksActivity"));
        portfolioButton.setOnClickListener(v -> openScreen("SimplePortfolioActivity"));

        LinearLayout.LayoutParams leftButtonParams = new LinearLayout.LayoutParams(0, dp(52), 1f);
        leftButtonParams.rightMargin = dp(8);

        LinearLayout.LayoutParams rightButtonParams = new LinearLayout.LayoutParams(0, dp(52), 1f);
        rightButtonParams.leftMargin = dp(8);

        actionRow.addView(discoverStocks, leftButtonParams);
        actionRow.addView(portfolioButton, rightButtonParams);

        TextView quickTitle = new TextView(this);
        quickTitle.setText("Quick actions");
        quickTitle.setTextColor(Color.WHITE);
        quickTitle.setTextSize(20);
        quickTitle.setTypeface(null, Typeface.BOLD);
        quickTitle.setPadding(0, dp(26), 0, dp(12));
        quickTitle.setGravity(Gravity.CENTER);
        quickTitle.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);

        LinearLayout quickGrid = new LinearLayout(this);
        quickGrid.setOrientation(LinearLayout.VERTICAL);

        quickGrid.addView(createQuickRow(
                "Markets",
                "",
                "MarketsActivity",
                "News",
                "",
                "DiscoverActivity"
        ));

        quickGrid.addView(createQuickRow(
                "AI Chat",
                "",
                "AiAssistantActivity",
                "Global Chat",
                "",
                "GlobalChatActivity"
        ));

        quickGrid.addView(createQuickRow(
                "Stocks",
                "",
                "StocksActivity",
                "Portfolio",
                "",
                "SimplePortfolioActivity"
        ));

        content.addView(tvGreeting);
        content.addView(subtitle);
        content.addView(balanceCard);
        content.addView(statsRow);
        content.addView(actionRow);
        content.addView(quickTitle);
        content.addView(quickGrid);

        scrollView.addView(content);

        root.addView(scrollView, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1f
        ));

        root.addView(createBottomNav());

        setContentView(root);
    }

    private LinearLayout createCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(makeRoundedDrawable(
                Color.rgb(16, 26, 45),
                dp(24),
                Color.rgb(38, 52, 77)
        ));
        return card;
    }

    private TextView createStatCard(LinearLayout parent, String label, String value) {
        LinearLayout card = createCard();
        card.setPadding(dp(14), dp(14), dp(14), dp(14));
        card.setGravity(Gravity.CENTER);

        TextView title = new TextView(this);
        title.setText(label);
        title.setTextColor(Color.rgb(142, 160, 188));
        title.setTextSize(12);
        title.setGravity(Gravity.CENTER);
        title.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);

        TextView amount = new TextView(this);
        amount.setText(value);
        amount.setTextColor(Color.WHITE);
        amount.setTextSize(18);
        amount.setTypeface(null, Typeface.BOLD);
        amount.setPadding(0, dp(8), 0, 0);
        amount.setGravity(Gravity.CENTER);
        amount.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);

        card.addView(title);
        card.addView(amount);

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, dp(74), 1f);

        if (parent.getChildCount() == 0) {
            params.rightMargin = dp(7);
        } else {
            params.leftMargin = dp(7);
        }

        parent.addView(card, params);

        return amount;
    }

    private LinearLayout createQuickRow(
            String title1,
            String subtitle1,
            String target1,
            String title2,
            String subtitle2,
            String target2
    ) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);

        LinearLayout.LayoutParams leftParams = new LinearLayout.LayoutParams(0, dp(92), 1f);
        leftParams.rightMargin = dp(7);
        leftParams.bottomMargin = dp(14);

        LinearLayout.LayoutParams rightParams = new LinearLayout.LayoutParams(0, dp(92), 1f);
        rightParams.leftMargin = dp(7);
        rightParams.bottomMargin = dp(14);

        row.addView(createQuickCard(title1, target1), leftParams);
        row.addView(createQuickCard(title2, target2), rightParams);

        return row;
    }

    private LinearLayout createQuickCard(String titleText, String targetActivity) {
        LinearLayout card = createCard();
        card.setPadding(dp(14), dp(12), dp(14), dp(12));
        card.setGravity(Gravity.CENTER);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setOnClickListener(v -> openScreen(targetActivity));

        ImageView icon = new ImageView(this);
        icon.setImageResource(getQuickActionIcon(targetActivity));
        icon.setColorFilter(Color.WHITE);
        icon.setPadding(dp(8), dp(8), dp(8), dp(8));
        icon.setBackground(makeRoundedDrawable(
                Color.rgb(49, 93, 255),
                dp(18),
                Color.rgb(49, 93, 255)
        ));

        LinearLayout.LayoutParams iconParams = new LinearLayout.LayoutParams(dp(42), dp(42));
        iconParams.bottomMargin = dp(8);

        TextView title = new TextView(this);
        title.setText(titleText);
        title.setTextColor(Color.WHITE);
        title.setTextSize(15);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(null, Typeface.BOLD);

        card.addView(icon, iconParams);
        card.addView(title);

        return card;
    }

    private int getQuickActionIcon(String targetActivity) {
        if ("AiAssistantActivity".equals(targetActivity)) {
            return R.drawable.ic_quick_ai;
        }

        if ("GlobalChatActivity".equals(targetActivity)) {
            return R.drawable.ic_quick_global_chat;
        }

        if ("DiscoverActivity".equals(targetActivity)) {
            return R.drawable.ic_quick_news;
        }

        if ("MarketsActivity".equals(targetActivity)) {
            return R.drawable.ic_quick_markets;
        }

        if ("StocksActivity".equals(targetActivity)) {
            return R.drawable.ic_quick_stocks;
        }

        if ("SimplePortfolioActivity".equals(targetActivity)) {
            return R.drawable.ic_quick_portfolio;
        }

        return R.drawable.ic_quick_stocks;
    }

    private TextView createPrimaryButton(String text) {
        TextView button = new TextView(this);
        button.setText(text);
        button.setGravity(Gravity.CENTER);
        button.setTextColor(Color.WHITE);
        button.setTextSize(15);
        button.setTypeface(null, Typeface.BOLD);
        button.setBackground(makeRoundedDrawable(
                Color.rgb(49, 93, 255),
                dp(18),
                Color.rgb(49, 93, 255)
        ));
        return button;
    }

    private TextView createSecondaryButton(String text) {
        TextView button = new TextView(this);
        button.setText(text);
        button.setGravity(Gravity.CENTER);
        button.setTextColor(Color.WHITE);
        button.setTextSize(15);
        button.setTypeface(null, Typeface.BOLD);
        button.setBackground(makeRoundedDrawable(
                Color.rgb(9, 17, 31),
                dp(18),
                Color.WHITE
        ));
        return button;
    }

    private BottomNavigationView createBottomNav() {
        BottomNavigationView bottomNav = new BottomNavigationView(this);
        bottomNav.setId(View.generateViewId());
        bottomNav.inflateMenu(R.menu.bottom_nav);

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(76)
        );

        bottomNav.setLayoutParams(params);

        NavBarUtil.setup(this, bottomNav, R.id.nav_home);

        return bottomNav;
    }

    private void loadUserData() {
        FirebaseUser user = auth.getCurrentUser();

        if (user == null) {
            updateNumbers();
            return;
        }

        String name = user.getDisplayName();

        if (name == null || name.trim().isEmpty()) {
            name = "Trader";
        }

        if (tvGreeting != null) {
            tvGreeting.setText("Welcome, " + name);
        }

        db.collection("users")
                .document(user.getUid())
                .get()
                .addOnSuccessListener(snapshot -> {
                    balance = readDouble(snapshot.get("cashBalance"),
                            readDouble(snapshot.get("availableCash"),
                                    readDouble(snapshot.get("balance"), 0.0)));

                    buyingPower = readDouble(snapshot.get("buyingPower"), balance);

                    double savedPortfolioValue = readDouble(snapshot.get("portfolioValue"), balance);
                    portfolioValue = savedPortfolioValue <= 0.0 ? balance : savedPortfolioValue;

                    updateNumbers();

                    PortfolioManager.getInstance().fetchPortfolio((portfolio, errorMessage) -> runOnUiThread(() -> {
                        if (portfolio == null) {
                            return;
                        }

                        balance = portfolio.cashBalance;
                        buyingPower = balance;
                        portfolioValue = calculatePortfolioTotal(portfolio);

                        updateNumbers();
                    }));
                })
                .addOnFailureListener(e -> updateNumbers());
    }

    private double calculatePortfolioTotal(PortfolioManager.Portfolio portfolio) {
        if (portfolio == null) {
            return balance;
        }

        double total = portfolio.cashBalance;

        if (portfolio.holdings != null) {
            for (PortfolioManager.Holding holding : portfolio.holdings) {
                if (holding == null) {
                    continue;
                }

                total += holding.quantity * holding.avgBuyPrice;
            }
        }

        return total;
    }

    private void updateNumbers() {
        if (tvBalance != null) {
            tvBalance.setText(formatMoney(balance));
        }

        if (tvPortfolioValue != null) {
            tvPortfolioValue.setText(formatMoney(portfolioValue));
        }

        if (tvBuyingPower != null) {
            tvBuyingPower.setText(formatMoney(buyingPower));
        }
    }

    private double readDouble(Object value, double fallback) {
        if (value instanceof Number) {
            return ((Number) value).doubleValue();
        }

        if (value instanceof String) {
            try {
                return Double.parseDouble((String) value);
            } catch (Exception ignored) {
            }
        }

        return fallback;
    }

    private String formatMoney(double value) {
        return AppSettingsManager.formatUsdAmount(this, value);
    }



    private void preloadDiscoverNews() {
        try {
            long cacheTime = getSharedPreferences(NEWS_CACHE_PREFS, MODE_PRIVATE)
                    .getLong(NEWS_KEY_CACHE_TIME, 0L);

            boolean cacheFresh = System.currentTimeMillis() - cacheTime < NEWS_CACHE_VALID_MS;

            if (cacheFresh) {
                String cachedJson = getSharedPreferences(NEWS_CACHE_PREFS, MODE_PRIVATE)
                        .getString(NEWS_KEY_CACHE_JSON, "");

                if (cachedJson != null && !cachedJson.trim().isEmpty()) {
                    return;
                }
            }
        } catch (Exception ignored) {
        }

        try {
            Class<?> clientClass = Class.forName(getPackageName() + ".NewsApiClient");
            Class<?> callbackClass = Class.forName(getPackageName() + ".NewsApiClient$NewsCallback");

            Object callback = java.lang.reflect.Proxy.newProxyInstance(
                    callbackClass.getClassLoader(),
                    new Class[]{callbackClass},
                    (proxy, method, args) -> {
                        String methodName = method == null ? "" : method.getName();

                        if ("onSuccess".equals(methodName) && args != null && args.length > 0) {
                            saveDiscoverNewsToCache(args[0]);
                        }

                        return null;
                    }
            );

            try {
                clientClass
                        .getMethod("fetchNewsAsync", String.class, String.class, callbackClass)
                        .invoke(
                                null,
                                "stock market finance investing earnings economy business",
                                "1d",
                                callback
                        );
                return;
            } catch (NoSuchMethodException ignored) {
            }

            try {
                clientClass
                        .getMethod("fetchNewsAsync", String.class, callbackClass)
                        .invoke(
                                null,
                                "stock market finance investing earnings economy business",
                                callback
                        );
            } catch (NoSuchMethodException ignored) {
            }
        } catch (Exception ignored) {
        }
    }

    private void saveDiscoverNewsToCache(Object articlesObject) {
        if (!(articlesObject instanceof Iterable)) {
            return;
        }

        try {
            JSONArray array = new JSONArray();

            for (Object article : (Iterable<?>) articlesObject) {
                if (article == null) {
                    continue;
                }

                String title = readArticleString(article, "title", "headline", "name");

                if (title.isEmpty()) {
                    continue;
                }

                JSONObject object = new JSONObject();
                object.put("id", readArticleString(article, "id", "uuid"));
                object.put("title", title);
                object.put("link", readArticleString(article, "link", "url"));
                object.put("snippet", readArticleString(article, "snippet", "description", "summary"));
                object.put("sourceName", readArticleString(article, "sourceName", "source", "publisher"));
                object.put("published", readArticleString(article, "publishedUtc", "published", "publishedAt", "date"));
                object.put("image", readArticleString(article, "imageUrl", "image", "thumbnail"));

                array.put(object);
            }

            if (array.length() == 0) {
                return;
            }

            getSharedPreferences(NEWS_CACHE_PREFS, MODE_PRIVATE)
                    .edit()
                    .putString(NEWS_KEY_CACHE_JSON, array.toString())
                    .putLong(NEWS_KEY_CACHE_TIME, System.currentTimeMillis())
                    .apply();
        } catch (Exception ignored) {
        }
    }

    private String readArticleString(Object object, String... names) {
        if (object == null || names == null) {
            return "";
        }

        for (String name : names) {
            if (name == null || name.trim().isEmpty()) {
                continue;
            }

            try {
                java.lang.reflect.Field field = object.getClass().getField(name);
                Object value = field.get(object);

                if (value != null) {
                    return value.toString().trim();
                }
            } catch (Exception ignored) {
            }

            try {
                java.lang.reflect.Field field = object.getClass().getDeclaredField(name);
                field.setAccessible(true);
                Object value = field.get(object);

                if (value != null) {
                    return value.toString().trim();
                }
            } catch (Exception ignored) {
            }

            try {
                String getterName = "get" + name.substring(0, 1).toUpperCase(Locale.US) + name.substring(1);
                java.lang.reflect.Method getter = object.getClass().getMethod(getterName);
                Object value = getter.invoke(object);

                if (value != null) {
                    return value.toString().trim();
                }
            } catch (Exception ignored) {
            }
        }

        return "";
    }


    private String safeString(String value) {
        return value == null ? "" : value.trim();
    }

    private void openScreen(String activityClassName) {
        try {
            Class<?> target = Class.forName(getPackageName() + "." + activityClassName);

            if (getClass().equals(target)) {
                return;
            }

            Intent intent = new Intent(this, target);
            startActivity(intent);
            overridePendingTransition(0, 0);
        } catch (Exception e) {
            Toast.makeText(this, "Screen is not available", Toast.LENGTH_SHORT).show();
        }
    }

    private android.graphics.drawable.GradientDrawable makeRoundedDrawable(
            int color,
            int radius,
            int strokeColor
    ) {
        android.graphics.drawable.GradientDrawable drawable =
                new android.graphics.drawable.GradientDrawable();

        drawable.setColor(color);
        drawable.setCornerRadius(radius);
        drawable.setStroke(dp(1), strokeColor);

        return drawable;
    }

    private int dp(int value) {
        return Math.round(getResources().getDisplayMetrics().density * value);
    }
}