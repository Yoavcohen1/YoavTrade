package com.example.yoavsproject;





public class StockQuote {
    public final double price;
    public final double changePercent;

    public StockQuote(double price, double changePercent) {
        this.price = price;
        this.changePercent = changePercent;
    }
}
