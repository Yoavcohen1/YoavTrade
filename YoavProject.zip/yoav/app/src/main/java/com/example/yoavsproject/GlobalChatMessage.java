package com.example.yoavsproject;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.HashMap;
import java.util.Map;










public class GlobalChatMessage {

    public String id;
    public String userId;
    public String username;
    public String text;
    public long timestamp;

    public boolean edited;
    public long editedAt;

    public String replyToMessageId;
    public String replyToUsername;
    public String replyToText;

    public String profilePhotoBase64;
    public String photoBase64;
    public String profileImageBase64;
    public boolean profilePrivate;

    public String messageType;
    public String gifBase64;
    public String gifMimeType;

    public String clientId;
    public String deviceId;

    public GlobalChatMessage() {
        
    }

    public GlobalChatMessage(
            @NonNull String id,
            @NonNull String userId,
            @NonNull String username,
            @NonNull String text,
            long timestamp
    ) {
        this.id = id;
        this.userId = userId;
        this.username = username;
        this.text = text;
        this.timestamp = timestamp;

        this.edited = false;
        this.editedAt = 0L;

        this.replyToMessageId = "";
        this.replyToUsername = "";
        this.replyToText = "";

        this.profilePhotoBase64 = "";
        this.photoBase64 = "";
        this.profileImageBase64 = "";
        this.profilePrivate = false;

        this.messageType = "text";
        this.gifBase64 = "";
        this.gifMimeType = "";

        this.clientId = "";
        this.deviceId = "";
    }

    @NonNull
    public static GlobalChatMessage create(
            @NonNull String id,
            @NonNull String userId,
            @Nullable String username,
            @Nullable String text,
            long timestamp
    ) {
        GlobalChatMessage message = new GlobalChatMessage();
        message.id = safe(id);
        message.userId = safe(userId);
        message.username = fallback(username, "Trader");
        message.text = safe(text);
        message.timestamp = timestamp;

        message.edited = false;
        message.editedAt = 0L;

        message.replyToMessageId = "";
        message.replyToUsername = "";
        message.replyToText = "";

        message.profilePhotoBase64 = "";
        message.photoBase64 = "";
        message.profileImageBase64 = "";
        message.profilePrivate = false;

        message.messageType = "text";
        message.gifBase64 = "";
        message.gifMimeType = "";

        message.clientId = "";
        message.deviceId = "";

        return message;
    }

    public void normalize(@Nullable String fallbackId) {
        id = firstNonEmpty(id, fallbackId);
        userId = safe(userId);
        username = fallback(username, "Trader");
        text = safe(text);

        if (timestamp <= 0L) {
            timestamp = System.currentTimeMillis();
        }

        if (editedAt < 0L) {
            editedAt = 0L;
        }

        replyToMessageId = safe(replyToMessageId);
        replyToUsername = safe(replyToUsername);
        replyToText = safe(replyToText);

        profilePhotoBase64 = firstNonEmpty(profilePhotoBase64, photoBase64, profileImageBase64);
        photoBase64 = safe(photoBase64);
        profileImageBase64 = safe(profileImageBase64);
        profilePrivate = false;

        messageType = fallback(messageType, gifBase64 == null || gifBase64.trim().isEmpty() ? "text" : "gif");
        gifBase64 = safe(gifBase64);
        gifMimeType = fallback(gifMimeType, gifBase64.isEmpty() ? "" : "image/gif");

        clientId = safe(clientId);
        deviceId = safe(deviceId);
    }

    public boolean isValidForDisplay() {
        return !safe(id).isEmpty()
                && !safe(userId).isEmpty()
                && !safe(text).isEmpty();
    }

    public boolean isMine(@Nullable String currentUserId) {
        return !safe(currentUserId).isEmpty() && safe(currentUserId).equals(userId);
    }

    public boolean hasReply() {
        return !safe(replyToMessageId).isEmpty() && !safe(replyToText).isEmpty();
    }

    @NonNull
    public String safeUsername() {
        return fallback(username, "Trader");
    }

    @NonNull
    public String safeText() {
        return safe(text);
    }

    @NonNull
    public Map<String, Object> toFirebaseMap() {
        normalize(id);

        Map<String, Object> map = new HashMap<>();
        map.put("id", safe(id));
        map.put("userId", safe(userId));
        map.put("username", fallback(username, "Trader"));
        map.put("text", safe(text));
        map.put("timestamp", timestamp);

        map.put("edited", edited);
        map.put("editedAt", editedAt);

        map.put("replyToMessageId", safe(replyToMessageId));
        map.put("replyToUsername", safe(replyToUsername));
        map.put("replyToText", safe(replyToText));

        String photo = firstNonEmpty(profilePhotoBase64, photoBase64, profileImageBase64);
        map.put("profilePhotoBase64", photo);
        map.put("photoBase64", photo);
        map.put("profileImageBase64", photo);
        map.put("profilePrivate", false);

        map.put("messageType", fallback(messageType, gifBase64 == null || gifBase64.trim().isEmpty() ? "text" : "gif"));
        map.put("gifBase64", safe(gifBase64));
        map.put("gifMimeType", fallback(gifMimeType, safe(gifBase64).isEmpty() ? "" : "image/gif"));

        map.put("clientId", safe(clientId));
        map.put("deviceId", safe(deviceId));

        return map;
    }

    @NonNull
    public GlobalChatMessage copy() {
        GlobalChatMessage copy = new GlobalChatMessage();

        copy.id = safe(id);
        copy.userId = safe(userId);
        copy.username = safe(username);
        copy.text = safe(text);
        copy.timestamp = timestamp;

        copy.edited = edited;
        copy.editedAt = editedAt;

        copy.replyToMessageId = safe(replyToMessageId);
        copy.replyToUsername = safe(replyToUsername);
        copy.replyToText = safe(replyToText);

        copy.profilePhotoBase64 = safe(profilePhotoBase64);
        copy.photoBase64 = safe(photoBase64);
        copy.profileImageBase64 = safe(profileImageBase64);
        copy.profilePrivate = false;

        copy.messageType = safe(messageType);
        copy.gifBase64 = safe(gifBase64);
        copy.gifMimeType = safe(gifMimeType);

        copy.clientId = safe(clientId);
        copy.deviceId = safe(deviceId);

        return copy;
    }

    @NonNull
    private static String safe(@Nullable String value) {
        return value == null ? "" : value.trim();
    }

    @NonNull
    private static String fallback(@Nullable String value, @NonNull String fallback) {
        String cleaned = safe(value);
        return cleaned.isEmpty() ? fallback : cleaned;
    }

    @NonNull
    private static String firstNonEmpty(@Nullable String... values) {
        if (values == null) {
            return "";
        }

        for (String value : values) {
            String cleaned = safe(value);
            if (!cleaned.isEmpty()) {
                return cleaned;
            }
        }

        return "";
    }
}