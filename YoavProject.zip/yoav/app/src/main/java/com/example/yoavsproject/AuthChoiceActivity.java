package com.example.yoavsproject;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;





public class AuthChoiceActivity extends AppCompatActivity {

    private Button btnLogin;
    private Button btnRegister;
    private TextView tvTitle;
    private TextView tvSubtitle;
    private TextView tvPrivacyTerms;
    private ImageView imageHeader;

    @Override
    

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (FirebaseAuth.getInstance().getCurrentUser() != null) {
            goToMain();
            return;
        }

        try {
            setContentView(R.layout.activity_auth_choice);

            tvTitle = findViewById(R.id.tvTitle);
            tvSubtitle = findViewById(R.id.tvSubtitle);
            tvPrivacyTerms = findViewById(R.id.tvPrivacyTerms);
            btnRegister = findViewById(R.id.btnRegister);
            btnLogin = findViewById(R.id.btnLogin);

            if (btnRegister != null) {
                btnRegister.setOnClickListener(v -> {
                    Intent intent = new Intent(AuthChoiceActivity.this, RegisterActivity.class);
                    startActivity(intent);
                });
            }

            if (btnLogin != null) {
                btnLogin.setOnClickListener(v -> {
                    Intent intent = new Intent(AuthChoiceActivity.this, LoginActivity.class);
                    startActivity(intent);
                });
            }

        } catch (Exception e) {
            e.printStackTrace();
            TextView tvError = new TextView(this);
            tvError.setText("AuthChoiceActivity error: " + e.toString());
            tvError.setPadding(32, 32, 32, 32);
            setContentView(tvError);
        }
    }

    private void goToMain() {
        Intent intent = new Intent(AuthChoiceActivity.this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }
}
