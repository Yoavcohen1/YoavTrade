package com.example.yoavsproject;

import androidx.annotation.NonNull;

import org.json.JSONObject;

import java.util.Locale;
import java.util.UUID;

public class PriceAlert {

    public static final String MODE_ABOVE = "ABOVE";
    public static final String MODE_BELOW = "BELOW";

    public String id;
    public String symbol;
    public double targetPrice;
    public String mode;
    public boolean enabled;
    public long createdAt;
    public long lastTriggeredAt;

    public PriceAlert() {
        this.id = UUID.randomUUID().toString();
        this.symbol = "AAPL";
        this.targetPrice = 0.0;
        this.mode = MODE_ABOVE;
        this.enabled = true;
        this.createdAt = System.currentTimeMillis();
        this.lastTriggeredAt = 0L;
    }

    public PriceAlert(String symbol, double targetPrice, String mode) {
        this.id = UUID.randomUUID().toString();
        this.symbol = cleanSymbol(symbol);
        this.targetPrice = targetPrice;
        this.mode = MODE_BELOW.equals(mode) ? MODE_BELOW : MODE_ABOVE;
        this.enabled = true;
        this.createdAt = System.currentTimeMillis();
        this.lastTriggeredAt = 0L;
    }

    public boolean shouldTrigger(double currentPrice) {
        if (!enabled || targetPrice <= 0) {
            return false;
        }

        if (MODE_ABOVE.equals(mode)) {
            return currentPrice >= targetPrice;
        }

        return currentPrice <= targetPrice;
    }

    public String getReadableCondition() {
        if (MODE_ABOVE.equals(mode)) {
            return "Above $" + format(targetPrice);
        }

        return "Below $" + format(targetPrice);
    }

    public JSONObject toJson() {
        JSONObject json = new JSONObject();

        try {
            json.put("id", id);
            json.put("symbol", symbol);
            json.put("targetPrice", targetPrice);
            json.put("mode", mode);
            json.put("enabled", enabled);
            json.put("createdAt", createdAt);
            json.put("lastTriggeredAt", lastTriggeredAt);
        } catch (Exception ignored) {
        }

        return json;
    }

    public static PriceAlert fromJson(JSONObject json) {
        PriceAlert alert = new PriceAlert();

        if (json == null) {
            return alert;
        }

        try {
            alert.id = json.optString("id", UUID.randomUUID().toString());
            alert.symbol = cleanSymbol(json.optString("symbol", "AAPL"));
            alert.targetPrice = json.optDouble("targetPrice", 0.0);
            alert.mode = json.optString("mode", MODE_ABOVE);
            alert.enabled = json.optBoolean("enabled", true);
            alert.createdAt = json.optLong("createdAt", System.currentTimeMillis());
            alert.lastTriggeredAt = json.optLong("lastTriggeredAt", 0L);
        } catch (Exception ignored) {
        }

        return alert;
    }

    private static String cleanSymbol(String value) {
        if (value == null || value.trim().isEmpty()) {
            return "AAPL";
        }

        return value.trim().toUpperCase(Locale.US);
    }

    @NonNull
    private String format(double value) {
        return String.format(Locale.US, "%,.2f", value);
    }
}