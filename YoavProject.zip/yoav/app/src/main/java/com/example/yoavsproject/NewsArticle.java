package com.example.yoavsproject;

public class NewsArticle {

    public String id;
    public String title;
    public String link;
    public String snippet;
    public String sourceName;
    public String publishedUtc;
    public String imageUrl;

    public NewsArticle() {
    }

    public NewsArticle(
            String id,
            String title,
            String link,
            String snippet,
            String sourceName,
            String publishedUtc,
            String imageUrl
    ) {
        this.id = clean(id);
        this.title = clean(title);
        this.link = clean(link);
        this.snippet = clean(snippet);
        this.sourceName = clean(sourceName);
        this.publishedUtc = clean(publishedUtc);
        this.imageUrl = clean(imageUrl);
    }

    public String getId() {
        return clean(id);
    }

    public String getTitle() {
        return clean(title);
    }

    public String getLink() {
        return clean(link);
    }

    public String getSnippet() {
        return clean(snippet);
    }

    public String getSourceName() {
        return clean(sourceName);
    }

    public String getPublishedUtc() {
        return clean(publishedUtc);
    }

    public String getImageUrl() {
        return clean(imageUrl);
    }

    private static String clean(String value) {
        if (value == null) {
            return "";
        }

        String clean = value.trim();

        if (clean.isEmpty()) {
            return "";
        }

        if ("null".equalsIgnoreCase(clean)
                || "none".equalsIgnoreCase(clean)
                || "undefined".equalsIgnoreCase(clean)
                || "n/a".equalsIgnoreCase(clean)) {
            return "";
        }

        return clean;
    }
}
