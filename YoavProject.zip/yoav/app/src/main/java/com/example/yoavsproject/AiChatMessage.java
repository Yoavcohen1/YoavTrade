package com.example.yoavsproject;





public class AiChatMessage {

    public static final int TYPE_USER = 1;
    public static final int TYPE_AI = 2;
    public static final int TYPE_THINKING = 3;
    public static final int TYPE_ARTICLE = 4;

    public final int type;
    public final String text;
    public final String title;
    public final String subtitle;
    public final String body;
    public final String imageUrl;
    public final String link;

    private AiChatMessage(int type, String text, String title, String subtitle, String body, String imageUrl, String link) {
        this.type = type;
        this.text = text;
        this.title = title;
        this.subtitle = subtitle;
        this.body = body;
        this.imageUrl = imageUrl;
        this.link = link;
    }

    public static AiChatMessage user(String text) {
        return new AiChatMessage(TYPE_USER, text, "", "", "", "", "");
    }

    public static AiChatMessage ai(String text) {
        return new AiChatMessage(TYPE_AI, text, "", "", "", "", "");
    }

    public static AiChatMessage thinking() {
        return new AiChatMessage(TYPE_THINKING, "", "", "", "", "", "");
    }

    public static AiChatMessage article(String title, String subtitle, String body, String imageUrl, String link) {
        return new AiChatMessage(TYPE_ARTICLE, "", title, subtitle, body, imageUrl, link);
    }
}
