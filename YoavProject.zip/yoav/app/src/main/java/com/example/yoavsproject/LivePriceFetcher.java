package com.example.yoavsproject;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Locale;

public final class LivePriceFetcher {

    public interface Callback {
        void onPrice(double price);
        void onError(Exception e);
    }

    private static final String HOST = "alpha-vantage.p.rapidapi.com";

    private LivePriceFetcher() {
    }

    public static void fetchPrice(String symbol, Callback callback) {
        new Thread(() -> {
            try {
                String cleanSymbol = symbol == null ? "AAPL" : symbol.trim().toUpperCase(Locale.US);
                String apiKey = getFirstAvailableRapidApiKey();

                if (apiKey.isEmpty()) {
                    throw new IllegalStateException("Missing RapidAPI key");
                }

                String urlString =
                        "https://alpha-vantage.p.rapidapi.com/query?function=GLOBAL_QUOTE&symbol=" +
                                cleanSymbol +
                                "&datatype=json";

                URL url = new URL(urlString);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();

                connection.setRequestMethod("GET");
                connection.setConnectTimeout(12000);
                connection.setReadTimeout(12000);
                connection.setRequestProperty("Content-Type", "application/json");
                connection.setRequestProperty("x-rapidapi-host", HOST);
                connection.setRequestProperty("x-rapidapi-key", apiKey);

                int code = connection.getResponseCode();

                BufferedReader reader = new BufferedReader(new InputStreamReader(
                        code >= 200 && code < 300
                                ? connection.getInputStream()
                                : connection.getErrorStream()
                ));

                StringBuilder response = new StringBuilder();
                String line;

                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }

                reader.close();
                connection.disconnect();

                JSONObject root = new JSONObject(response.toString());
                JSONObject quote = root.optJSONObject("Global Quote");

                if (quote == null) {
                    throw new IllegalStateException("Missing Global Quote");
                }

                String priceText = quote.optString("05. price", "");

                if (priceText.isEmpty()) {
                    throw new IllegalStateException("Missing price");
                }

                double price = Double.parseDouble(priceText);

                if (callback != null) {
                    callback.onPrice(price);
                }
            } catch (Exception e) {
                if (callback != null) {
                    callback.onError(e);
                }
            }
        }).start();
    }

    private static String getFirstAvailableRapidApiKey() {
        String[] names = new String[]{
                "RAPIDAPI_KEY",
                "RAPIDAPI_KEY_1",
                "RAPIDAPI_KEY_2",
                "RAPIDAPI_KEY_3",
                "RAPIDAPI_KEY_4",
                "RAPIDAPI_KEY_5",
                "RAPIDAPI_KEY_6",
                "RAPIDAPI_KEY_7"
        };

        for (String name : names) {
            try {
                Field field = BuildConfig.class.getField(name);
                Object value = field.get(null);

                if (value != null) {
                    String key = String.valueOf(value).trim();

                    if (!key.isEmpty()) {
                        return key;
                    }
                }
            } catch (Exception ignored) {
            }
        }

        return "";
    }
}