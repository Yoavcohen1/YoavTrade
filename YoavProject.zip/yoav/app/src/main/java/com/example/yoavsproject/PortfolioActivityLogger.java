package com.example.yoavsproject;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Set;
















public final class PortfolioActivityLogger {

    private static final String PREFS = "yoav_portfolio_activity_logger";
    private static final String KEY_HISTORY = "history_json";
    private static final String KEY_SNAPSHOT = "snapshot_json";

    private static final int MAX_HISTORY = 60;

    private PortfolioActivityLogger() {
    }

    public static void syncSnapshot(
            @NonNull Context context,
            double currentCash,
            @Nullable List<PortfolioManager.Holding> currentHoldings
    ) {
        try {
            SharedPreferences prefs = prefs(context);

            JSONObject oldSnapshot = readObject(prefs.getString(KEY_SNAPSHOT, ""));

            JSONObject newSnapshot = buildSnapshot(currentCash, currentHoldings);

            if (oldSnapshot == null) {
                prefs.edit()
                        .putString(KEY_SNAPSHOT, newSnapshot.toString())
                        .apply();
                return;
            }

            detectCashChange(context, oldSnapshot, newSnapshot);
            detectHoldingChanges(context, oldSnapshot, newSnapshot);

            prefs.edit()
                    .putString(KEY_SNAPSHOT, newSnapshot.toString())
                    .apply();
        } catch (Exception ignored) {
        }
    }

    public static List<Entry> getRecent(@NonNull Context context, int limit) {
        List<Entry> entries = new ArrayList<>();

        try {
            JSONArray array = readHistoryArray(context);
            int count = Math.min(limit, array.length());

            for (int i = 0; i < count; i++) {
                JSONObject object = array.optJSONObject(i);

                if (object == null) {
                    continue;
                }

                Entry entry = Entry.fromJson(object);

                if (entry != null) {
                    entries.add(entry);
                }
            }
        } catch (Exception ignored) {
        }

        return entries;
    }

    public static void clear(@NonNull Context context) {
        prefs(context)
                .edit()
                .remove(KEY_HISTORY)
                .remove(KEY_SNAPSHOT)
                .apply();
    }

    public static void addMoneyEvent(
            @NonNull Context context,
            double amount,
            @NonNull String label
    ) {
        String type = amount >= 0.0 ? "money_in" : "money_out";
        String title = amount >= 0.0 ? "Added money" : "Money removed";

        Entry entry = new Entry(
                type,
                title,
                label,
                formatSignedMoney(amount),
                System.currentTimeMillis()
        );

        addEntry(context, entry);
    }

    public static void addStockTradeEvent(
            @NonNull Context context,
            @NonNull String symbol,
            boolean buy,
            double quantity,
            double estimatedAmount
    ) {
        String cleanSymbol = cleanSymbol(symbol);

        Entry entry = new Entry(
                buy ? "buy" : "sell",
                buy ? "Bought " + cleanSymbol : "Sold " + cleanSymbol,
                formatQty(quantity) + " shares",
                buy ? "-" + formatMoney(Math.abs(estimatedAmount)) : "+" + formatMoney(Math.abs(estimatedAmount)),
                System.currentTimeMillis()
        );

        addEntry(context, entry);
    }

    private static void detectCashChange(
            @NonNull Context context,
            @NonNull JSONObject oldSnapshot,
            @NonNull JSONObject newSnapshot
    ) {
        double oldCash = oldSnapshot.optDouble("cash", 0.0);
        double newCash = newSnapshot.optDouble("cash", 0.0);

        double diff = newCash - oldCash;

        if (Math.abs(diff) < 0.01) {
            return;
        }

        addMoneyEvent(
                context,
                diff,
                diff > 0.0 ? "Cash balance increased" : "Cash balance decreased"
        );
    }

    private static void detectHoldingChanges(
            @NonNull Context context,
            @NonNull JSONObject oldSnapshot,
            @NonNull JSONObject newSnapshot
    ) {
        JSONObject oldHoldings = oldSnapshot.optJSONObject("holdings");
        JSONObject newHoldings = newSnapshot.optJSONObject("holdings");

        if (oldHoldings == null) {
            oldHoldings = new JSONObject();
        }

        if (newHoldings == null) {
            newHoldings = new JSONObject();
        }

        Set<String> symbols = new HashSet<>();

        Iterator<String> oldKeys = oldHoldings.keys();
        while (oldKeys.hasNext()) {
            symbols.add(oldKeys.next());
        }

        Iterator<String> newKeys = newHoldings.keys();
        while (newKeys.hasNext()) {
            symbols.add(newKeys.next());
        }

        for (String symbol : symbols) {
            JSONObject oldItem = oldHoldings.optJSONObject(symbol);
            JSONObject newItem = newHoldings.optJSONObject(symbol);

            double oldQty = oldItem == null ? 0.0 : oldItem.optDouble("quantity", 0.0);
            double newQty = newItem == null ? 0.0 : newItem.optDouble("quantity", 0.0);

            double diffQty = newQty - oldQty;

            if (Math.abs(diffQty) < 0.0001) {
                continue;
            }

            double price = 0.0;

            if (newItem != null) {
                price = newItem.optDouble("avgBuyPrice", 0.0);
            }

            if (price <= 0.0 && oldItem != null) {
                price = oldItem.optDouble("avgBuyPrice", 0.0);
            }

            double estimatedAmount = Math.abs(diffQty) * Math.max(0.0, price);

            addStockTradeEvent(
                    context,
                    symbol,
                    diffQty > 0.0,
                    Math.abs(diffQty),
                    estimatedAmount
            );
        }
    }

    @NonNull
    private static JSONObject buildSnapshot(
            double cash,
            @Nullable List<PortfolioManager.Holding> holdings
    ) throws Exception {
        JSONObject root = new JSONObject();
        root.put("cash", cash);

        JSONObject holdingsJson = new JSONObject();

        if (holdings != null) {
            for (PortfolioManager.Holding holding : holdings) {
                if (holding == null || holding.symbol == null || holding.symbol.trim().isEmpty()) {
                    continue;
                }

                String symbol = cleanSymbol(holding.symbol);

                JSONObject item = new JSONObject();
                item.put("quantity", holding.quantity);
                item.put("avgBuyPrice", holding.avgBuyPrice);

                holdingsJson.put(symbol, item);
            }
        }

        root.put("holdings", holdingsJson);
        root.put("timestamp", System.currentTimeMillis());

        return root;
    }

    private static void addEntry(@NonNull Context context, @NonNull Entry entry) {
        try {
            JSONArray oldArray = readHistoryArray(context);
            JSONArray newArray = new JSONArray();

            newArray.put(entry.toJson());

            for (int i = 0; i < oldArray.length() && newArray.length() < MAX_HISTORY; i++) {
                JSONObject object = oldArray.optJSONObject(i);

                if (object != null) {
                    newArray.put(object);
                }
            }

            prefs(context)
                    .edit()
                    .putString(KEY_HISTORY, newArray.toString())
                    .apply();
        } catch (Exception ignored) {
        }
    }

    @NonNull
    private static JSONArray readHistoryArray(@NonNull Context context) {
        try {
            String raw = prefs(context).getString(KEY_HISTORY, "");

            if (raw == null || raw.trim().isEmpty()) {
                return new JSONArray();
            }

            return new JSONArray(raw);
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    @Nullable
    private static JSONObject readObject(@Nullable String raw) {
        try {
            if (raw == null || raw.trim().isEmpty()) {
                return null;
            }

            return new JSONObject(raw);
        } catch (Exception e) {
            return null;
        }
    }

    private static SharedPreferences prefs(@NonNull Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private static String cleanSymbol(String raw) {
        if (raw == null || raw.trim().isEmpty()) {
            return "-";
        }

        return raw.trim().toUpperCase(Locale.US);
    }

    private static String formatMoney(double value) {
        return String.format(Locale.US, "$%,.2f", Math.abs(value));
    }

    private static String formatSignedMoney(double value) {
        return value >= 0.0
                ? "+" + formatMoney(value)
                : "-" + formatMoney(value);
    }

    private static String formatQty(double value) {
        String raw = String.format(Locale.US, "%.4f", value);

        while (raw.contains(".") && (raw.endsWith("0") || raw.endsWith("."))) {
            raw = raw.substring(0, raw.length() - 1);
        }

        return raw;
    }

    public static class Entry {
        public final String type;
        public final String title;
        public final String subtitle;
        public final String amountText;
        public final long timestamp;

        public Entry(
                @NonNull String type,
                @NonNull String title,
                @NonNull String subtitle,
                @NonNull String amountText,
                long timestamp
        ) {
            this.type = type;
            this.title = title;
            this.subtitle = subtitle;
            this.amountText = amountText;
            this.timestamp = timestamp;
        }

        @Nullable
        public static Entry fromJson(@Nullable JSONObject object) {
            if (object == null) {
                return null;
            }

            return new Entry(
                    object.optString("type", "info"),
                    object.optString("title", "Activity"),
                    object.optString("subtitle", ""),
                    object.optString("amountText", ""),
                    object.optLong("timestamp", System.currentTimeMillis())
            );
        }

        @NonNull
        public JSONObject toJson() throws Exception {
            JSONObject object = new JSONObject();
            object.put("type", type);
            object.put("title", title);
            object.put("subtitle", subtitle);
            object.put("amountText", amountText);
            object.put("timestamp", timestamp);
            return object;
        }

        public String getRelativeTime() {
            long diff = Math.max(0L, System.currentTimeMillis() - timestamp);

            long minute = 60_000L;
            long hour = 60L * minute;
            long day = 24L * hour;

            if (diff < minute) {
                return "just now";
            }

            if (diff < hour) {
                return (diff / minute) + "m ago";
            }

            if (diff < day) {
                return (diff / hour) + "h ago";
            }

            return (diff / day) + "d ago";
        }
    }
}