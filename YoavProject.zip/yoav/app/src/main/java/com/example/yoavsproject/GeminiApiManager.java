package com.example.yoavsproject;

import android.os.Handler;
import android.os.Looper;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class GeminiApiManager {

    public interface Callback {
        void onSuccess(String text);
        void onError(Exception e);
    }

    public interface GeminiCallback {
        void onSuccess(String response);
        void onError(String errorMessage);
    }

    private static final int CONNECT_TIMEOUT_MS = 20000;
    private static final int READ_TIMEOUT_MS = 30000;
    private static final long DEBOUNCE_DELAY_MS = 450L;

    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    private static GeminiApiManager instance;

    private final Handler debounceHandler = new Handler(Looper.getMainLooper());
    private Runnable pendingRequest;

    private GeminiApiManager() {
    }

    public static synchronized GeminiApiManager getInstance() {
        if (instance == null) {
            instance = new GeminiApiManager();
        }

        return instance;
    }

    public void requestDebounced(@NonNull String prompt, @NonNull Callback callback) {
        if (pendingRequest != null) {
            debounceHandler.removeCallbacks(pendingRequest);
        }

        pendingRequest = () -> request(prompt, callback);
        debounceHandler.postDelayed(pendingRequest, DEBOUNCE_DELAY_MS);
    }

    public void request(@NonNull String prompt, @NonNull Callback callback) {
        generateText(
                prompt,
                null,
                new GeminiCallback() {
                    @Override
                    public void onSuccess(String response) {
                        callback.onSuccess(response);
                    }

                    @Override
                    public void onError(String errorMessage) {
                        callback.onError(new Exception(errorMessage));
                    }
                }
        );
    }

    public static void askGemini(@NonNull String prompt, @NonNull GeminiCallback callback) {
        generateText(prompt, callback);
    }

    public static void generateText(@NonNull String prompt, @NonNull GeminiCallback callback) {
        generateText(prompt, null, callback);
    }

    public static void generateText(
            @NonNull String prompt,
            @Nullable String systemInstruction,
            @NonNull GeminiCallback callback
    ) {
        new Thread(() -> {
            String[] keys = AppConfig.getGeminiKeys();
            String[] models = AppConfig.getGeminiModels();

            if (keys.length == 0) {
                postError(callback, "Missing Gemini API keys. Add gemini.key.1 in local.properties.");
                return;
            }

            String lastError = "Gemini request failed";

            for (String model : models) {
                for (String key : keys) {
                    try {
                        String result = callGemini(model, key, prompt, systemInstruction);

                        if (result != null && !result.trim().isEmpty()) {
                            postSuccess(callback, result.trim());
                            return;
                        }

                        lastError = "Empty Gemini response";
                    } catch (Exception e) {
                        lastError = e.getMessage() == null
                                ? "Gemini request failed"
                                : e.getMessage();
                    }
                }
            }

            postError(callback, lastError);
        }).start();
    }

    @NonNull
    private static String callGemini(
            @NonNull String model,
            @NonNull String apiKey,
            @NonNull String prompt,
            @Nullable String systemInstruction
    ) throws Exception {
        String endpoint = AppConfig.GEMINI_BASE_URL
                + model
                + ":generateContent?key="
                + apiKey;

        HttpURLConnection connection = null;

        try {
            URL url = new URL(endpoint);
            connection = (HttpURLConnection) url.openConnection();

            connection.setRequestMethod("POST");
            connection.setConnectTimeout(CONNECT_TIMEOUT_MS);
            connection.setReadTimeout(READ_TIMEOUT_MS);
            connection.setDoOutput(true);
            connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");

            JSONObject body = buildRequestBody(prompt, systemInstruction);
            byte[] bytes = body.toString().getBytes(StandardCharsets.UTF_8);

            OutputStream outputStream = connection.getOutputStream();
            outputStream.write(bytes);
            outputStream.flush();
            outputStream.close();

            int code = connection.getResponseCode();

            String responseText;

            if (code >= 200 && code < 300) {
                responseText = readStream(connection.getInputStream());
            } else {
                responseText = readStream(connection.getErrorStream());
                throw new Exception("Gemini " + model + " failed with HTTP " + code + ": " + responseText);
            }

            return parseTextFromResponse(responseText);
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
    }

    @NonNull
    private static JSONObject buildRequestBody(
            @NonNull String prompt,
            @Nullable String systemInstruction
    ) throws Exception {
        JSONObject root = new JSONObject();

        if (systemInstruction != null && !systemInstruction.trim().isEmpty()) {
            JSONObject system = new JSONObject();
            JSONArray systemParts = new JSONArray();

            JSONObject systemText = new JSONObject();
            systemText.put("text", systemInstruction.trim());

            systemParts.put(systemText);
            system.put("parts", systemParts);

            root.put("systemInstruction", system);
        }

        JSONArray contents = new JSONArray();

        JSONObject userContent = new JSONObject();
        userContent.put("role", "user");

        JSONArray parts = new JSONArray();

        JSONObject textPart = new JSONObject();
        textPart.put("text", prompt);

        parts.put(textPart);
        userContent.put("parts", parts);

        contents.put(userContent);
        root.put("contents", contents);

        JSONObject generationConfig = new JSONObject();
        generationConfig.put("temperature", 0.7);
        generationConfig.put("topP", 0.95);
        generationConfig.put("topK", 40);
        generationConfig.put("maxOutputTokens", 2048);

        root.put("generationConfig", generationConfig);

        JSONArray safetySettings = new JSONArray();

        safetySettings.put(safetySetting("HARM_CATEGORY_HARASSMENT", "BLOCK_MEDIUM_AND_ABOVE"));
        safetySettings.put(safetySetting("HARM_CATEGORY_HATE_SPEECH", "BLOCK_MEDIUM_AND_ABOVE"));
        safetySettings.put(safetySetting("HARM_CATEGORY_SEXUALLY_EXPLICIT", "BLOCK_MEDIUM_AND_ABOVE"));
        safetySettings.put(safetySetting("HARM_CATEGORY_DANGEROUS_CONTENT", "BLOCK_MEDIUM_AND_ABOVE"));

        root.put("safetySettings", safetySettings);

        return root;
    }

    @NonNull
    private static JSONObject safetySetting(
            @NonNull String category,
            @NonNull String threshold
    ) throws Exception {
        JSONObject object = new JSONObject();
        object.put("category", category);
        object.put("threshold", threshold);
        return object;
    }

    @NonNull
    private static String parseTextFromResponse(@Nullable String responseText) throws Exception {
        if (responseText == null || responseText.trim().isEmpty()) {
            return "";
        }

        JSONObject root = new JSONObject(responseText);
        JSONArray candidates = root.optJSONArray("candidates");

        if (candidates == null || candidates.length() == 0) {
            String promptFeedback = root.optString("promptFeedback", "");
            throw new Exception(promptFeedback.isEmpty() ? "No Gemini candidates returned" : promptFeedback);
        }

        StringBuilder builder = new StringBuilder();

        for (int i = 0; i < candidates.length(); i++) {
            JSONObject candidate = candidates.optJSONObject(i);

            if (candidate == null) {
                continue;
            }

            JSONObject content = candidate.optJSONObject("content");

            if (content == null) {
                continue;
            }

            JSONArray parts = content.optJSONArray("parts");

            if (parts == null) {
                continue;
            }

            for (int j = 0; j < parts.length(); j++) {
                JSONObject part = parts.optJSONObject(j);

                if (part == null) {
                    continue;
                }

                String text = part.optString("text", "");

                if (!text.trim().isEmpty()) {
                    if (builder.length() > 0) {
                        builder.append("\n");
                    }

                    builder.append(text.trim());
                }
            }
        }

        return builder.toString().trim();
    }

    @NonNull
    private static String readStream(@Nullable InputStream inputStream) throws Exception {
        if (inputStream == null) {
            return "";
        }

        BufferedReader reader = new BufferedReader(
                new InputStreamReader(inputStream, StandardCharsets.UTF_8)
        );

        StringBuilder builder = new StringBuilder();
        String line;

        while ((line = reader.readLine()) != null) {
            builder.append(line).append('\n');
        }

        reader.close();

        return builder.toString().trim();
    }

    private static void postSuccess(
            @NonNull GeminiCallback callback,
            @NonNull String response
    ) {
        MAIN.post(() -> callback.onSuccess(response));
    }

    private static void postError(
            @NonNull GeminiCallback callback,
            @NonNull String error
    ) {
        MAIN.post(() -> callback.onError(error));
    }
}