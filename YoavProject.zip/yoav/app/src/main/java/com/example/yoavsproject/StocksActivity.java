package com.example.yoavsproject;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.card.MaterialCardView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class StocksActivity extends AppCompatActivity {

    private LinearLayout stockList;
    private String selectedCategory = "All";
    private String searchQuery = "";

    private final StockItem[] stocks = new StockItem[]{
            new StockItem("AAPL", "Apple Inc.", 270.71, "+1.16%", "Big Tech"),
            new StockItem("MSFT", "Microsoft", 428.66, "+0.58%", "Big Tech"),
            new StockItem("META", "Meta Platforms", 588.72, "+0.91%", "Social"),
            new StockItem("NFLX", "Netflix", 973.41, "-0.72%", "Streaming"),
            new StockItem("ABNB", "Airbnb", 139.04, "-1.43%", "Travel"),
            new StockItem("AMD", "Advanced Micro Devices", 323.21, "-3.41%", "AI"),
            new StockItem("AMZN", "Amazon", 259.70, "-0.54%", "Big Tech"),
            new StockItem("GOOGL", "Alphabet", 178.32, "+0.42%", "AI"),
            new StockItem("NVDA", "NVIDIA", 921.58, "+2.18%", "AI"),
            new StockItem("TSLA", "Tesla", 184.25, "-0.88%", "Electric Vehicles")
    };

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        AppSettingsManager.applySavedUi(this);

        super.onCreate(savedInstanceState);

        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        buildScreen();
    }

    @Override
    protected void onResume() {
        super.onResume();
        AppSettingsManager.syncSettingsForCurrentUser(this);
        refreshLivePrices();

        if (stockList != null) {
            renderStocks();
        }
    }

    private void buildScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(9, 17, 31));

        ScrollView scrollView = new ScrollView(this);
        scrollView.setFillViewport(true);
        scrollView.setOverScrollMode(ScrollView.OVER_SCROLL_NEVER);
        scrollView.setVerticalScrollBarEnabled(false);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(24), dp(54), dp(24), dp(26));

        TextView title = new TextView(this);
        title.setText("Discover stocks");
        title.setTextColor(Color.WHITE);
        title.setTextSize(30);
        title.setTypeface(null, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        title.setIncludeFontPadding(false);

        TextView subtitle = new TextView(this);
        subtitle.setText("Find stocks by category and explore the market");
        subtitle.setTextColor(Color.rgb(142, 160, 188));
        subtitle.setTextSize(14);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setIncludeFontPadding(false);
        subtitle.setPadding(0, dp(10), 0, dp(20));

        EditText search = new EditText(this);
        search.setHint("Search");
        search.setHintTextColor(Color.rgb(142, 160, 188));
        search.setTextColor(Color.WHITE);
        search.setSingleLine(true);
        search.setTextSize(15);
        search.setGravity(Gravity.CENTER_VERTICAL);
        search.setPadding(dp(18), 0, dp(18), 0);
        search.setBackground(makeRoundedDrawable(
                Color.rgb(15, 26, 45),
                dp(20),
                Color.rgb(38, 52, 77)
        ));
        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                searchQuery = s == null ? "" : s.toString().trim().toLowerCase(Locale.US);
                renderStocks();
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        LinearLayout.LayoutParams searchParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(56)
        );

        HorizontalScrollView categoryScroll = new HorizontalScrollView(this);
        categoryScroll.setHorizontalScrollBarEnabled(false);
        categoryScroll.setOverScrollMode(HorizontalScrollView.OVER_SCROLL_NEVER);
        categoryScroll.setPadding(0, dp(18), 0, dp(14));

        LinearLayout categoryRow = new LinearLayout(this);
        categoryRow.setOrientation(LinearLayout.HORIZONTAL);

        addCategoryButton(categoryRow, "All");
        addCategoryButton(categoryRow, "Big Tech");
        addCategoryButton(categoryRow, "AI");
        addCategoryButton(categoryRow, "Streaming");
        addCategoryButton(categoryRow, "Social");
        addCategoryButton(categoryRow, "Travel");

        categoryScroll.addView(categoryRow);

        stockList = new LinearLayout(this);
        stockList.setOrientation(LinearLayout.VERTICAL);

        content.addView(title, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        ));
        content.addView(subtitle, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        ));
        content.addView(search, searchParams);
        content.addView(categoryScroll);
        content.addView(stockList);

        scrollView.addView(content);

        root.addView(scrollView, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1f
        ));

        root.addView(createBottomNav());

        setContentView(root);

        renderStocks();
        refreshLivePrices();
    }

    private void addCategoryButton(LinearLayout parent, String category) {
        TextView button = new TextView(this);
        button.setText(category);
        button.setTextSize(13);
        button.setGravity(Gravity.CENTER);
        button.setTypeface(null, Typeface.BOLD);
        button.setIncludeFontPadding(false);
        button.setPadding(dp(18), 0, dp(18), 0);

        boolean selected = category.equals(selectedCategory);

        button.setTextColor(selected ? Color.WHITE : Color.rgb(185, 198, 220));
        button.setBackground(makeRoundedDrawable(
                selected ? Color.rgb(49, 93, 255) : Color.rgb(15, 26, 45),
                dp(18),
                selected ? Color.rgb(49, 93, 255) : Color.rgb(38, 52, 77)
        ));

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                dp(38)
        );
        params.rightMargin = dp(10);

        button.setLayoutParams(params);

        button.setOnClickListener(v -> {
            selectedCategory = category;
            buildScreen();
        });

        parent.addView(button);
    }

    private void renderStocks() {
        if (stockList == null) {
            return;
        }

        stockList.removeAllViews();

        List<StockItem> filtered = new ArrayList<>();

        for (StockItem stock : stocks) {
            boolean categoryMatch = "All".equals(selectedCategory)
                    || stock.category.equals(selectedCategory);

            boolean searchMatch = searchQuery.isEmpty()
                    || stock.symbol.toLowerCase(Locale.US).contains(searchQuery)
                    || stock.name.toLowerCase(Locale.US).contains(searchQuery);

            if (categoryMatch && searchMatch) {
                filtered.add(stock);
            }
        }

        if (filtered.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("No stocks found");
            empty.setTextColor(Color.rgb(142, 160, 188));
            empty.setTextSize(15);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(0, dp(40), 0, dp(40));
            stockList.addView(empty);
            return;
        }

        for (StockItem stock : filtered) {
            stockList.addView(createStockCard(stock));
        }
    }

    private LinearLayout createStockCard(StockItem stock) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(16), dp(16), dp(16));
        card.setBackground(makeRoundedDrawable(
                Color.rgb(16, 26, 45),
                dp(24),
                Color.rgb(38, 52, 77)
        ));

        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        cardParams.bottomMargin = dp(14);
        card.setLayoutParams(cardParams);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);

        MaterialCardView logoHolder = createMarketsStyleLogo(stock.symbol);

        LinearLayout names = new LinearLayout(this);
        names.setOrientation(LinearLayout.VERTICAL);

        TextView symbol = new TextView(this);
        symbol.setText(stock.symbol);
        symbol.setTextColor(Color.WHITE);
        symbol.setTextSize(20);
        symbol.setTypeface(null, Typeface.BOLD);
        symbol.setIncludeFontPadding(false);

        TextView name = new TextView(this);
        name.setText(stock.name);
        name.setTextColor(Color.rgb(150, 166, 195));
        name.setTextSize(14);
        name.setPadding(0, dp(6), 0, 0);
        name.setIncludeFontPadding(false);

        names.addView(symbol);
        names.addView(name);

        LinearLayout priceWrap = new LinearLayout(this);
        priceWrap.setOrientation(LinearLayout.VERTICAL);
        priceWrap.setGravity(Gravity.END);

        TextView price = new TextView(this);
        price.setGravity(Gravity.END);
        price.setTextColor(stock.change.startsWith("-")
                ? Color.rgb(255, 77, 77)
                : Color.rgb(34, 197, 94));
        price.setTextSize(14);
        price.setTypeface(null, Typeface.BOLD);
        price.setIncludeFontPadding(false);
        price.setTag(stock.symbol);

        AppSettingsManager.formatUsdAmountAsync(
                this,
                stock.price,
                formatted -> {
                    Object tag = price.getTag();

                    if (tag != null && tag.toString().equals(stock.symbol)) {
                        price.setText(formatted);
                    }
                }
        );

        TextView change = new TextView(this);
        change.setText(stock.change);
        change.setTextColor(stock.change.startsWith("-")
                ? Color.rgb(255, 77, 77)
                : Color.rgb(34, 197, 94));
        change.setTextSize(13);
        change.setTypeface(null, Typeface.BOLD);
        change.setGravity(Gravity.END);
        change.setIncludeFontPadding(false);
        change.setPadding(0, dp(5), 0, 0);

        priceWrap.addView(price);
        priceWrap.addView(change);

        top.addView(logoHolder);

        LinearLayout.LayoutParams nameParams = new LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.WRAP_CONTENT,
                1f
        );
        nameParams.leftMargin = dp(16);
        top.addView(names, nameParams);

        top.addView(priceWrap);

        TextView info = createInfoButton("Info");
        info.setOnClickListener(v -> openStockDetails(stock));
        card.setOnClickListener(v -> openStockDetails(stock));

        LinearLayout.LayoutParams infoParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(50)
        );
        infoParams.topMargin = dp(16);

        card.addView(top);
        card.addView(info, infoParams);

        return card;
    }

    private MaterialCardView createMarketsStyleLogo(String symbol) {
        MaterialCardView outer = new MaterialCardView(this);
        outer.setCardBackgroundColor(Color.rgb(14, 21, 32));
        outer.setRadius(dp(32));
        outer.setCardElevation(0f);
        outer.setStrokeColor(Color.rgb(45, 57, 74));
        outer.setStrokeWidth(dp(1));
        outer.setPreventCornerOverlap(false);
        outer.setUseCompatPadding(false);

        LinearLayout.LayoutParams outerParams = new LinearLayout.LayoutParams(dp(64), dp(64));
        outer.setLayoutParams(outerParams);

        MaterialCardView inner = new MaterialCardView(this);
        inner.setCardBackgroundColor(Color.WHITE);
        inner.setRadius(dp(27));
        inner.setCardElevation(0f);
        inner.setStrokeColor(Color.rgb(238, 242, 248));
        inner.setStrokeWidth(dp(1));
        inner.setPreventCornerOverlap(false);
        inner.setUseCompatPadding(false);

        MaterialCardView.LayoutParams innerParams = new MaterialCardView.LayoutParams(dp(54), dp(54));
        innerParams.gravity = Gravity.CENTER;

        ImageView logo = new ImageView(this);
        logo.setAdjustViewBounds(false);
        logo.setContentDescription("Stock logo");
        logo.setPadding(dp(6), dp(6), dp(6), dp(6));
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        StockLogoMapper.bind(logo, symbol);

        inner.addView(logo, new MaterialCardView.LayoutParams(
                MaterialCardView.LayoutParams.MATCH_PARENT,
                MaterialCardView.LayoutParams.MATCH_PARENT
        ));

        outer.addView(inner, innerParams);

        return outer;
    }

    private TextView createInfoButton(String text) {
        TextView button = new TextView(this);
        button.setText(text);
        button.setGravity(Gravity.CENTER);
        button.setTextColor(Color.WHITE);
        button.setTextSize(14);
        button.setTypeface(null, Typeface.BOLD);
        button.setIncludeFontPadding(false);
        button.setBackground(makeRoundedDrawable(
                Color.rgb(49, 93, 255),
                dp(18),
                Color.rgb(94, 128, 255)
        ));
        return button;
    }

    private BottomNavigationView createBottomNav() {
        BottomNavigationView bottomNav = new BottomNavigationView(this);
        bottomNav.setId(View.generateViewId());
        bottomNav.inflateMenu(R.menu.bottom_nav);

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(70)
        );
        params.setMarginStart(dp(20));
        params.setMarginEnd(dp(20));
        params.bottomMargin = dp(18);

        bottomNav.setLayoutParams(params);
        bottomNav.setBackgroundResource(R.drawable.bg_bottom_nav);

        NavBarUtil.setup(this, bottomNav, 0);

        return bottomNav;
    }

    private void refreshLivePrices() {
        for (StockItem stock : stocks) {
            if (stock == null || stock.symbol == null || stock.symbol.trim().isEmpty()) {
                continue;
            }

            final StockItem target = stock;

            AlphaVantageClient.lastPriceAsync(target.symbol, new AlphaVantageClient.PriceCallback() {
                @Override
                public void onSuccess(double price) {
                    runOnUiThread(() -> {
                        if (price > 0.0) {
                            target.price = price;
                            renderStocks();
                        }
                    });
                }

                @Override
                public void onError(Exception e) {
                }
            });
        }
    }

    private void openStockDetails(StockItem stock) {
        try {
            Intent intent = new Intent(this, StockDetailsActivity.class);
            intent.putExtra("symbol", stock.symbol);
            intent.putExtra("stockSymbol", stock.symbol);
            intent.putExtra("stockName", stock.name);
            intent.putExtra("price", stock.price);
            startActivity(intent);
        } catch (Exception ignored) {
        }
    }

    private GradientDrawable makeRoundedDrawable(
            int color,
            int radius,
            int strokeColor
    ) {
        GradientDrawable drawable = new GradientDrawable();

        drawable.setShape(GradientDrawable.RECTANGLE);
        drawable.setColor(color);
        drawable.setCornerRadius(radius);
        drawable.setStroke(dp(1), strokeColor);

        return drawable;
    }

    private int dp(int value) {
        return Math.round(getResources().getDisplayMetrics().density * value);
    }

    private static final class StockItem {
        final String symbol;
        final String name;
        double price;
        final String change;
        final String category;

        StockItem(String symbol, String name, double price, String change, String category) {
            this.symbol = symbol;
            this.name = name;
            this.price = price;
            this.change = change;
            this.category = category;
        }
    }
}
