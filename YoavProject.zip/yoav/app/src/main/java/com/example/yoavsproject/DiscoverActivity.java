package com.example.yoavsproject;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

public class DiscoverActivity extends AppCompatActivity {

    private static final String CACHE_PREFS = "yoav_discover_news_cache";
    private static final String KEY_CACHE_JSON = "cached_articles_json";
    private static final String KEY_CACHE_TIME = "cached_articles_time";
    private static final long CACHE_VALID_MS = 1000L * 60L * 15L;

    private TextView btnTimeAnytime;
    private TextView btnTime1h;
    private TextView btnTime1d;
    private TextView btnTime7d;
    private TextView btnTime1m;
    private TextView btnTime1y;

    private ProgressBar progressNews;
    private TextView tvError;
    private SwipeRefreshLayout swipeRefresh;
    private RecyclerView recyclerNews;
    private BottomNavigationView bottomNav;

    private NewsAdapter adapter;

    private String selectedTime = "1d";
    private boolean loading = false;

    private final String defaultNewsQuery =
            "stock market finance investing earnings economy business";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        AppSettingsManager.applySavedUi(this);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_discover);

        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        bindViews();
        setupRecycler();
        setupClicks();
        setupBottomNav();

        selectedTime = "1d";
        selectTimeButton(btnTime1d);

        showCachedOrCuratedFeed(false);
        loadNews(false);
    }

    @Override
    protected void onResume() {
        super.onResume();

        try {
            AppSettingsManager.syncSettingsForCurrentUser(this);
        } catch (Exception ignored) {
        }
    }

    private void bindViews() {
        btnTimeAnytime = findViewById(R.id.btnTimeAnytime);
        btnTime1h = findViewById(R.id.btnTime1h);
        btnTime1d = findViewById(R.id.btnTime1d);
        btnTime7d = findViewById(R.id.btnTime7d);
        btnTime1m = findViewById(R.id.btnTime1m);
        btnTime1y = findViewById(R.id.btnTime1y);

        progressNews = findViewById(R.id.progressNews);
        tvError = findViewById(R.id.tvError);
        swipeRefresh = findViewById(R.id.swipeRefresh);
        recyclerNews = findViewById(R.id.recyclerNews);
        bottomNav = findViewById(R.id.bottomNav);
    }

    private void setupRecycler() {
        adapter = new NewsAdapter();

        if (recyclerNews != null) {
            recyclerNews.setLayoutManager(new LinearLayoutManager(this));
            recyclerNews.setAdapter(adapter);
            recyclerNews.setItemAnimator(null);
            recyclerNews.setHasFixedSize(false);
            recyclerNews.setClipToPadding(false);
            recyclerNews.setOverScrollMode(View.OVER_SCROLL_NEVER);
            recyclerNews.setNestedScrollingEnabled(false);
        }
    }

    private void setupClicks() {
        if (btnTimeAnytime != null) {
            btnTimeAnytime.setOnClickListener(v -> {
                selectedTime = "anytime";
                selectTimeButton(btnTimeAnytime);
                showCachedOrCuratedFeed(true);
                loadNews(false);
            });
        }

        if (btnTime1h != null) {
            btnTime1h.setOnClickListener(v -> {
                selectedTime = "1h";
                selectTimeButton(btnTime1h);
                showCachedOrCuratedFeed(true);
                loadNews(false);
            });
        }

        if (btnTime1d != null) {
            btnTime1d.setOnClickListener(v -> {
                selectedTime = "1d";
                selectTimeButton(btnTime1d);
                showCachedOrCuratedFeed(true);
                loadNews(false);
            });
        }

        if (btnTime7d != null) {
            btnTime7d.setOnClickListener(v -> {
                selectedTime = "7d";
                selectTimeButton(btnTime7d);
                showCachedOrCuratedFeed(true);
                loadNews(false);
            });
        }

        if (btnTime1m != null) {
            btnTime1m.setOnClickListener(v -> {
                selectedTime = "1m";
                selectTimeButton(btnTime1m);
                showCachedOrCuratedFeed(true);
                loadNews(false);
            });
        }

        if (btnTime1y != null) {
            btnTime1y.setOnClickListener(v -> {
                selectedTime = "1y";
                selectTimeButton(btnTime1y);
                showCachedOrCuratedFeed(true);
                loadNews(false);
            });
        }

        if (swipeRefresh != null) {
            swipeRefresh.setOnRefreshListener(() -> loadNews(true));
        }

        if (tvError != null) {
            tvError.setOnClickListener(v -> loadNews(false));
        }
    }

    private void setupBottomNav() {
        if (bottomNav == null) {
            return;
        }

        int selectedId = getResources().getIdentifier("nav_discover", "id", getPackageName());

        if (selectedId == 0) {
            selectedId = getResources().getIdentifier("nav_news", "id", getPackageName());
        }

        if (selectedId == 0) {
            selectedId = getResources().getIdentifier("nav_home", "id", getPackageName());
        }

        if (selectedId != 0) {
            try {
                NavBarUtil.setup(this, bottomNav, selectedId);
            } catch (Exception ignored) {
                try {
                    bottomNav.setSelectedItemId(selectedId);
                } catch (Exception ignored2) {
                }
            }
        }
    }

    private void loadNews(boolean fromRefresh) {
        if (loading) {
            if (swipeRefresh != null) {
                swipeRefresh.setRefreshing(false);
            }
            return;
        }

        loading = true;
        showLoading(fromRefresh);

        NewsApiClient.fetchNewsAsync(
                defaultNewsQuery,
                selectedTime,
                new NewsApiClient.NewsCallback() {
                    @Override
                    public void onSuccess(List<NewsArticle> articles) {
                        runOnUiThread(() -> {
                            loading = false;
                            hideLoading();

                            List<NewsArticle> safeArticles = articles == null
                                    ? new ArrayList<>()
                                    : cleanArticles(articles);

                            if (safeArticles.isEmpty()) {
                                List<NewsArticle> cached = readCachedArticles();

                                if (!cached.isEmpty()) {
                                    hideError();
                                    applyArticlesToAdapter(cached);
                                    return;
                                }

                                List<NewsArticle> curated = buildCuratedFallbackArticles();
                                hideError();
                                applyArticlesToAdapter(curated);
                                return;
                            }

                            hideError();
                            saveArticlesToCache(safeArticles);
                            applyArticlesToAdapter(safeArticles);
                        });
                    }

                    @Override
                    public void onError(Exception e) {
                        runOnUiThread(() -> {
                            loading = false;
                            hideLoading();

                            List<NewsArticle> cached = readCachedArticles();

                            if (!cached.isEmpty()) {
                                hideError();
                                applyArticlesToAdapter(cached);
                                return;
                            }

                            List<NewsArticle> curated = buildCuratedFallbackArticles();

                            if (!curated.isEmpty()) {
                                hideError();
                                applyArticlesToAdapter(curated);
                                return;
                            }

                            showError("Could not load news. Pull down to refresh.");
                        });
                    }
                }
        );
    }

    private void showCachedOrCuratedFeed(boolean forceReplace) {
        List<NewsArticle> cached = readCachedArticles();

        if (!cached.isEmpty()) {
            applyArticlesToAdapter(cached);
            hideError();
            return;
        }

        if (forceReplace) {
            List<NewsArticle> curated = buildCuratedFallbackArticles();
            applyArticlesToAdapter(curated);
            hideError();
        }
    }

    @NonNull
    private List<NewsArticle> cleanArticles(@Nullable List<NewsArticle> raw) {
        List<NewsArticle> cleaned = new ArrayList<>();

        if (raw == null) {
            return cleaned;
        }

        for (NewsArticle article : raw) {
            if (article == null) {
                continue;
            }

            String title = readStringField(article, "title");

            if (title == null || title.trim().isEmpty()) {
                continue;
            }

            cleaned.add(article);
        }

        return cleaned;
    }

    private void applyArticlesToAdapter(List<NewsArticle> articles) {
        if (adapter == null) {
            return;
        }

        List<NewsArticle> safeArticles = articles == null
                ? new ArrayList<>()
                : articles;

        








        String[] methodNames = new String[]{
                "setArticles",
                "submitList",
                "updateArticles",
                "setNews",
                "replaceArticles",
                "setItems"
        };

        for (String methodName : methodNames) {
            try {
                Method method = adapter.getClass().getMethod(methodName, List.class);
                method.invoke(adapter, safeArticles);
                adapter.notifyDataSetChanged();
                return;
            } catch (Exception ignored) {
            }
        }

        



        String[] fieldNames = new String[]{
                "articles",
                "items",
                "news",
                "data",
                "articleList",
                "newsArticles"
        };

        for (String fieldName : fieldNames) {
            try {
                Field field = adapter.getClass().getDeclaredField(fieldName);
                field.setAccessible(true);

                Object value = field.get(adapter);

                if (value instanceof List) {
                    List list = (List) value;
                    list.clear();
                    list.addAll(safeArticles);
                    adapter.notifyDataSetChanged();
                    return;
                }

                field.set(adapter, safeArticles);
                adapter.notifyDataSetChanged();
                return;
            } catch (Exception ignored) {
            }
        }

        adapter.notifyDataSetChanged();

        Toast.makeText(
                this,
                "News loaded, but NewsAdapter needs a setArticles method.",
                Toast.LENGTH_LONG
        ).show();
    }

    private void selectTimeButton(TextView selectedButton) {
        styleTimeButton(btnTimeAnytime, selectedButton == btnTimeAnytime);
        styleTimeButton(btnTime1h, selectedButton == btnTime1h);
        styleTimeButton(btnTime1d, selectedButton == btnTime1d);
        styleTimeButton(btnTime7d, selectedButton == btnTime7d);
        styleTimeButton(btnTime1m, selectedButton == btnTime1m);
        styleTimeButton(btnTime1y, selectedButton == btnTime1y);
    }

    private void styleTimeButton(TextView button, boolean selected) {
        if (button == null) {
            return;
        }

        button.setBackgroundResource(selected
                ? R.drawable.bg_news_chip_selected
                : R.drawable.bg_news_chip);

        button.setTextColor(selected
                ? Color.rgb(234, 241, 255)
                : Color.rgb(185, 199, 231));

        button.setAlpha(selected ? 1.0f : 0.92f);
    }

    private void showLoading(boolean fromRefresh) {
        if (fromRefresh) {
            if (swipeRefresh != null) {
                swipeRefresh.setRefreshing(true);
            }

            if (progressNews != null) {
                progressNews.setVisibility(View.GONE);
            }

            return;
        }

        if (progressNews != null) {
            progressNews.setVisibility(View.VISIBLE);
        }

        if (tvError != null) {
            tvError.setVisibility(View.GONE);
        }
    }

    private void hideLoading() {
        if (swipeRefresh != null) {
            swipeRefresh.setRefreshing(false);
        }

        if (progressNews != null) {
            progressNews.setVisibility(View.GONE);
        }
    }

    private void showError(String message) {
        if (tvError != null) {
            tvError.setText(message);
            tvError.setVisibility(View.VISIBLE);
        }
    }

    private void hideError() {
        if (tvError != null) {
            tvError.setVisibility(View.GONE);
        }
    }

    private void saveArticlesToCache(@NonNull List<NewsArticle> articles) {
        try {
            JSONArray array = new JSONArray();

            for (NewsArticle article : articles) {
                JSONObject object = newsArticleToJson(article);

                if (object != null) {
                    array.put(object);
                }
            }

            getSharedPreferences(CACHE_PREFS, MODE_PRIVATE)
                    .edit()
                    .putString(KEY_CACHE_JSON, array.toString())
                    .putLong(KEY_CACHE_TIME, System.currentTimeMillis())
                    .apply();
        } catch (Exception ignored) {
        }
    }

    @NonNull
    private List<NewsArticle> readCachedArticles() {
        List<NewsArticle> articles = new ArrayList<>();

        try {
            long cacheTime = getSharedPreferences(CACHE_PREFS, MODE_PRIVATE)
                    .getLong(KEY_CACHE_TIME, 0L);

            boolean cacheFresh = System.currentTimeMillis() - cacheTime < CACHE_VALID_MS;

            if (!cacheFresh) {
                return articles;
            }

            String raw = getSharedPreferences(CACHE_PREFS, MODE_PRIVATE)
                    .getString(KEY_CACHE_JSON, "");

            if (raw == null || raw.trim().isEmpty()) {
                return articles;
            }

            JSONArray array = new JSONArray(raw);

            for (int i = 0; i < array.length(); i++) {
                JSONObject object = array.optJSONObject(i);

                if (object == null) {
                    continue;
                }

                NewsArticle article = jsonToNewsArticle(object);

                if (article != null) {
                    articles.add(article);
                }
            }
        } catch (Exception ignored) {
        }

        return articles;
    }

    @Nullable
    private JSONObject newsArticleToJson(@Nullable NewsArticle article) {
        if (article == null) {
            return null;
        }

        try {
            JSONObject object = new JSONObject();

            object.put("id", safeString(readStringField(article, "id")));
            object.put("title", safeString(readStringField(article, "title")));
            object.put("link", safeString(readStringField(article, "link")));
            object.put("snippet", firstNonEmpty(
                    readStringField(article, "snippet"),
                    readStringField(article, "description"),
                    readStringField(article, "summary")
            ));
            object.put("sourceName", firstNonEmpty(
                    readStringField(article, "sourceName"),
                    readStringField(article, "source"),
                    readStringField(article, "publisher")
            ));
            object.put("published", firstNonEmpty(
                    readStringField(article, "published"),
                    readStringField(article, "publishedAt"),
                    readStringField(article, "date")
            ));
            object.put("image", firstNonEmpty(
                    readStringField(article, "image"),
                    readStringField(article, "imageUrl"),
                    readStringField(article, "photoUrl")
            ));

            return object;
        } catch (Exception e) {
            return null;
        }
    }

    @Nullable
    private NewsArticle jsonToNewsArticle(@Nullable JSONObject object) {
        if (object == null) {
            return null;
        }

        try {
            return new NewsArticle(
                    object.optString("id", ""),
                    object.optString("title", ""),
                    object.optString("link", ""),
                    object.optString("snippet", ""),
                    object.optString("sourceName", ""),
                    object.optString("published", ""),
                    object.optString("image", "")
            );
        } catch (Exception e) {
            return null;
        }
    }

    @NonNull
    private List<NewsArticle> buildCuratedFallbackArticles() {
        List<NewsArticle> articles = new ArrayList<>();

        articles.add(new NewsArticle(
                "fallback_1",
                "Markets watch inflation, earnings and AI spending",
                "https://www.reuters.com/markets/",
                "Investors are tracking inflation data, corporate earnings and technology spending as markets look for direction.",
                "Market News",
                "Live",
                ""
        ));

        articles.add(new NewsArticle(
                "fallback_2",
                "Tech stocks remain in focus as traders watch guidance",
                "https://www.cnbc.com/markets/",
                "Large technology companies continue to drive market attention as traders compare earnings, valuation and future growth.",
                "Market News",
                "Today",
                ""
        ));

        articles.add(new NewsArticle(
                "fallback_3",
                "Wall Street looks for signals from rates and the economy",
                "https://www.marketwatch.com/",
                "Market participants are watching central bank expectations, economic data and company updates.",
                "Market News",
                "Today",
                ""
        ));

        return articles;
    }

    @Nullable
    private String readStringField(@Nullable Object object, @NonNull String fieldName) {
        if (object == null) {
            return null;
        }

        try {
            Field field = object.getClass().getDeclaredField(fieldName);
            field.setAccessible(true);
            Object value = field.get(object);

            if (value == null) {
                return null;
            }

            return String.valueOf(value);
        } catch (Exception ignored) {
        }

        try {
            String methodName = "get"
                    + fieldName.substring(0, 1).toUpperCase()
                    + fieldName.substring(1);

            Method method = object.getClass().getMethod(methodName);
            Object value = method.invoke(object);

            if (value == null) {
                return null;
            }

            return String.valueOf(value);
        } catch (Exception ignored) {
        }

        return null;
    }

    @NonNull
    private String firstNonEmpty(@Nullable String... values) {
        if (values == null) {
            return "";
        }

        for (String value : values) {
            if (value != null && !value.trim().isEmpty()) {
                return value.trim();
            }
        }

        return "";
    }

    @NonNull
    private String safeString(@Nullable String value) {
        return value == null ? "" : value.trim();
    }

    private void openArticle(@Nullable NewsArticle article) {
        if (article == null) {
            return;
        }

        String link = readStringField(article, "link");

        if (link == null || link.trim().isEmpty()) {
            Toast.makeText(this, "Article link is not available", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(link));
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "Could not open article", Toast.LENGTH_SHORT).show();
        }
    }
}