package com.example.yoavsproject;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;

import java.util.HashMap;
import java.util.Map;
import android.graphics.Typeface;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.StyleSpan;
import android.content.SharedPreferences;

public class EmailVerificationActivity extends AppCompatActivity {

    public static final String EXTRA_AFTER_VERIFY_TO_WELCOME = "extra_after_verify_to_welcome";
    private static final double STARTER_BALANCE = 10000.0;

    private ImageView ivStatus;
    private TextView tvTitle;
    private TextView tvMessage;
    private TextView tvChangeEmail;
    private Button btnContinue;
    private Button btnResend;

    private FirebaseAuth auth;
    private FirebaseFirestore db;

    private boolean afterVerifyToWelcome = false;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        AppSettingsManager.applySavedUi(this);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_email_verification);

        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        auth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        afterVerifyToWelcome = getIntent() != null
                && getIntent().getBooleanExtra(EXTRA_AFTER_VERIFY_TO_WELCOME, false);

        bindViews();
        setupClicks();
        updateUi();
        sendInitialVerificationIfNeeded();
    }

    @Override
    protected void onResume() {
        super.onResume();
        reloadUserAndUpdate();
    }

    private void bindViews() {
        ivStatus = findViewById(R.id.ivStatus);
        tvTitle = findViewById(R.id.tvTitle);
        tvMessage = findViewById(R.id.tvMessage);
        tvChangeEmail = findViewById(R.id.tvChangeEmail);
        btnContinue = findViewById(R.id.btnContinue);
        btnResend = findViewById(R.id.btnResend);
    }

    private void setupClicks() {
        if (btnContinue != null) {
            btnContinue.setOnClickListener(v -> reloadUserAndContinue());
        }

        if (btnResend != null) {
            btnResend.setOnClickListener(v -> resendVerificationEmail());
        }

        if (tvChangeEmail != null) {
            tvChangeEmail.setOnClickListener(v -> openRegisterWithSavedDetails());
        }
    }


    private CharSequence buildVerificationMessage(String email) {
        String before = "We sent a verification link to:\n";
        String after = "\n\nOpen your email, tap the verification link, then return here and press Continue.";

        SpannableStringBuilder builder = new SpannableStringBuilder();
        builder.append(before);

        int start = builder.length();
        builder.append(email);
        int end = builder.length();

        builder.setSpan(
                new StyleSpan(Typeface.BOLD),
                start,
                end,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        );

        builder.append(after);

        return builder;
    }

    private void openRegisterWithSavedDetails() {
        FirebaseUser user = auth.getCurrentUser();

        String savedName = "";
        String savedBirthDate = "";

        if (user != null) {
            savedName = firstNonEmpty(user.getDisplayName(), "");
        }

        try {
            savedName = firstNonEmpty(savedName, AppSettingsManager.getLocalDisplayName(this), "");
            SharedPreferences prefs = getSharedPreferences("yoav_profile_prefs", MODE_PRIVATE);
            savedBirthDate = prefs.getString("profile_birth_date", "");
        } catch (Exception ignored) {
        }

        auth.signOut();

        Intent intent = new Intent(this, RegisterActivity.class);
        intent.putExtra(RegisterActivity.EXTRA_PREFILL_USERNAME, savedName);
        intent.putExtra(RegisterActivity.EXTRA_PREFILL_BIRTH_DATE, savedBirthDate);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    private String firstNonEmpty(String... values) {
        if (values == null) {
            return "";
        }

        for (String value : values) {
            if (value != null && !value.trim().isEmpty()) {
                return value.trim();
            }
        }

        return "";
    }

    private void sendInitialVerificationIfNeeded() {
        FirebaseUser user = auth.getCurrentUser();

        if (user == null || user.isEmailVerified()) {
            return;
        }

        user.sendEmailVerification();
    }

    private void updateUi() {
        FirebaseUser user = auth.getCurrentUser();

        if (user == null) {
            openRegister();
            return;
        }

        boolean verified = user.isEmailVerified();

        if (ivStatus != null) {
            ivStatus.setImageResource(verified
                    ? R.drawable.verified
                    : R.drawable.ic_register_email);
        }

        if (tvTitle != null) {
            tvTitle.setText(verified ? "Email verified" : "Verify your email");
        }

        if (tvMessage != null) {
            if (verified) {
                tvMessage.setText("Your email is verified. Press Continue to enter YoavTrade.");
            } else {
                tvMessage.setText(buildVerificationMessage(safe(user.getEmail())));
            }
        }

        if (btnContinue != null) {
            btnContinue.setText(verified ? "Continue" : "I verified my email");
        }
    }

    private void reloadUserAndUpdate() {
        FirebaseUser user = auth.getCurrentUser();

        if (user == null) {
            openRegister();
            return;
        }

        user.reload().addOnCompleteListener(task -> updateUi());
    }

    private void reloadUserAndContinue() {
        FirebaseUser user = auth.getCurrentUser();

        if (user == null) {
            openRegister();
            return;
        }

        setContinueLoading(true);

        user.reload().addOnCompleteListener(task -> {
            FirebaseUser reloadedUser = auth.getCurrentUser();

            if (reloadedUser == null) {
                setContinueLoading(false);
                openRegister();
                return;
            }

            if (!reloadedUser.isEmailVerified()) {
                setContinueLoading(false);
                updateUi();
                Toast.makeText(this, "Email is not verified yet", Toast.LENGTH_SHORT).show();
                return;
            }

            markEmailVerifiedAndRoute(reloadedUser);
        });
    }

    private void markEmailVerifiedAndRoute(FirebaseUser user) {
        Map<String, Object> patch = new HashMap<>();
        patch.put("emailVerified", true);
        patch.put("emailVerifiedAt", System.currentTimeMillis());

        db.collection("users")
                .document(user.getUid())
                .set(patch, SetOptions.merge())
                .addOnCompleteListener(task -> routeAfterVerification(user));
    }

    private void routeAfterVerification(FirebaseUser user) {
        if (afterVerifyToWelcome) {
            setContinueLoading(false);
            openWelcomeGift();
            return;
        }

        db.collection("users")
                .document(user.getUid())
                .get()
                .addOnSuccessListener(snapshot -> {
                    setContinueLoading(false);

                    Boolean welcomeGiftClaimed = snapshot.getBoolean("welcomeGiftClaimed");

                    if (welcomeGiftClaimed != null && welcomeGiftClaimed) {
                        openDashboard();
                    } else {
                        openWelcomeGift();
                    }
                })
                .addOnFailureListener(e -> {
                    setContinueLoading(false);
                    openDashboard();
                });
    }

    private void resendVerificationEmail() {
        FirebaseUser user = auth.getCurrentUser();

        if (user == null) {
            openRegister();
            return;
        }

        if (user.isEmailVerified()) {
            Toast.makeText(this, "Email is already verified", Toast.LENGTH_SHORT).show();
            updateUi();
            return;
        }

        if (btnResend != null) {
            btnResend.setEnabled(false);
            btnResend.setText("Sending...");
        }

        user.sendEmailVerification().addOnCompleteListener(task -> {
            if (btnResend != null) {
                btnResend.setEnabled(true);
                btnResend.setText("Resend email");
            }

            if (task.isSuccessful()) {
                Toast.makeText(this, "Verification email sent", Toast.LENGTH_LONG).show();
            } else {
                String message = task.getException() != null
                        ? task.getException().getMessage()
                        : "Could not send verification email";

                Toast.makeText(this, message, Toast.LENGTH_LONG).show();
            }
        });
    }

    private void setContinueLoading(boolean loading) {
        if (btnContinue == null) {
            return;
        }

        btnContinue.setEnabled(!loading);
        btnContinue.setAlpha(loading ? 0.65f : 1.0f);
        btnContinue.setText(loading ? "Checking..." : "I verified my email");
    }

    private void openWelcomeGift() {
        Intent intent = new Intent(this, WelcomeGiftActivity.class);
        intent.putExtra("extra_balance", STARTER_BALANCE);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    private void openDashboard() {
        Intent intent = new Intent(this, TradingDashboardActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    private void openRegister() {
        Intent intent = new Intent(this, RegisterActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    private String safe(String value) {
        return value == null ? "" : value;
    }
}
