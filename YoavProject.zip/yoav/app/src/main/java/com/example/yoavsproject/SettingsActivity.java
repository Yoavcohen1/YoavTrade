package com.example.yoavsproject;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Shader;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.NumberPicker;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.DrawableRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.SetOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.FirebaseDatabase;
import com.yalantis.ucrop.UCrop;

import java.io.File;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class SettingsActivity extends AppCompatActivity {

    private static final String PROFILE_PREFS = "yoav_profile_prefs";
    private static final String KEY_BIRTH_DATE = "profile_birth_date";
    private static final String CHAT_PATH = "GlobalChat";



    private final String[] monthNames = new String[]{
            "January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"
    };



    private ImageView btnBackSettings;
    private ImageView ivProfileAvatar;

    private TextView tvSettingsName;
    private TextView tvSettingsEmail;
    private TextView tvSettingsBirthDate;
    private TextView tvCurrencyValue;
    private TextView tvBalanceValue;
    private TextView btnUpdateProfile;

    private View rowManageBalance;
    private View rowChangePassword;
    private View rowCurrency;
    private View rowPriceAlerts;
    private View rowPrivacy;
    private View rowAbout;
    private View rowLogout;

    private CompoundButton switchPriceAlerts;

    private CompoundButton switchPrivacy;



    private String currentName = "";
    private String currentEmail = "";
    private String currentBirthDate = "";
    private String currentCurrency = "USD";
    private String currentPhotoBase64 = "";
    private boolean localProfilePhotoChangedInSession = false;

    private double currentBalance = 0.0;

    private Uri pendingProfileImageUri;
    private ImageView activeProfileDialogPreview;

    private ActivityResultLauncher<String> imagePermissionLauncher;
    private ActivityResultLauncher<Intent> imagePickerLauncher;
    private ActivityResultLauncher<Intent> cropLauncher;

    private FirebaseAuth auth;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        AppSettingsManager.applySavedUi(this);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        auth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        setupLaunchers();
        bindViews();
        fixUpdateProfileButtonDesign();
        setupClicks();
        removeNewsAlertsFromSettings();
        loadLocalProfile();
        loadRemoteProfile();
        refreshUi();
    }


    private void removeNewsAlertsFromSettings() {
        AppSettingsManager.saveNewsAlertsEnabled(this, false);

        FirebaseUser user = auth.getCurrentUser();
        if (user == null) {
            return;
        }

        Map<String, Object> patch = new HashMap<>();
        patch.put("newsAlertsEnabled", false);
        patch.put("newsAlertSources", null);

        db.collection("users")
                .document(user.getUid())
                .set(patch, SetOptions.merge());
    }


    private void setupLaunchers() {
        imagePermissionLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestPermission(),
                granted -> {
                    if (granted) {
                        openImagePicker();
                    } else {
                        Toast.makeText(this, "Image permission denied", Toast.LENGTH_SHORT).show();
                    }
                }
        );

        imagePickerLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                        Uri sourceUri = result.getData().getData();
                        if (sourceUri != null) {
                            startProfileImageCrop(sourceUri);
                        }
                    }
                }
        );

        cropLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    Intent data = result.getData();

                    if (result.getResultCode() == RESULT_OK && data != null) {
                        Uri croppedUri = UCrop.getOutput(data);

                        if (croppedUri != null) {
                            pendingProfileImageUri = croppedUri;
                            saveProfilePhoto();
                        }

                        return;
                    }

                    if (result.getResultCode() == UCrop.RESULT_ERROR && data != null) {
                        Throwable error = UCrop.getError(data);

                        Toast.makeText(
                                this,
                                error == null ? "Image crop failed" : error.getMessage(),
                                Toast.LENGTH_SHORT
                        ).show();
                    }
                }
        );
    }





    private void bindViews() {
        btnBackSettings = findViewById(getExistingId("btnBackSettings", "btnBack"));
        ivProfileAvatar = findViewById(getExistingId("ivProfileAvatar", "imgProfileAvatar"));

        tvSettingsName = findViewById(getExistingId("tvSettingsName", "tvProfileTitle"));
        tvSettingsEmail = findViewById(getExistingId("tvSettingsEmail", "tvProfileSubtitle"));
        tvSettingsBirthDate = findViewById(getExistingId("tvSettingsBirthDate"));
        tvCurrencyValue = findViewById(getExistingId("tvCurrencyValue"));
        tvBalanceValue = findViewById(getExistingId("tvBalanceValue"));
        btnUpdateProfile = findViewById(getExistingId("btnUpdateProfile"));

        rowManageBalance = findViewById(getExistingId("rowManageBalance", "rowAddFunds"));
        rowChangePassword = findViewById(getExistingId("rowChangePassword", "rowSecurity"));
        rowCurrency = findViewById(getExistingId("rowCurrency"));
        rowPriceAlerts = findViewById(getExistingId("rowPriceAlerts"));
        rowPrivacy = findViewById(getExistingId("rowPrivacy"));
        rowAbout = findViewById(getExistingId("rowAbout"));
        rowLogout = findViewById(getExistingId("rowLogout"));

        switchPriceAlerts = findViewById(getExistingId("switchPriceAlerts"));
        switchPrivacy = findViewById(getExistingId("switchPrivacy"));

        com.google.android.material.bottomnavigation.BottomNavigationView bottomNav =
                findViewById(getExistingId("bottomNav"));

        if (bottomNav != null) {
            NavBarUtil.setup(this, bottomNav, R.id.nav_settings);
        }
    }




    private void fixUpdateProfileButtonDesign() {
        if (btnUpdateProfile == null) {
            return;
        }

        btnUpdateProfile.setText("Update profile");
        btnUpdateProfile.setGravity(Gravity.CENTER);
        btnUpdateProfile.setSingleLine(true);
        btnUpdateProfile.setIncludeFontPadding(false);
        btnUpdateProfile.setCompoundDrawablesWithIntrinsicBounds(null, null, null, null);
        btnUpdateProfile.setCompoundDrawablePadding(0);
        btnUpdateProfile.setMinHeight(dp(34));
        btnUpdateProfile.setPadding(dp(14), dp(8), dp(14), dp(8));
    }

    private void setupClicks() {
        if (btnBackSettings != null) {
            btnBackSettings.setOnClickListener(v -> safeGoBack());
        }

        if (ivProfileAvatar != null) {
            ivProfileAvatar.setOnClickListener(v -> requestImagePermissionAndPick());
        }

        if (btnUpdateProfile != null) {
            btnUpdateProfile.setOnClickListener(v -> openEditProfileDialog());
        }

        if (rowManageBalance != null) {
            rowManageBalance.setOnClickListener(v -> showBalanceDialog());
        }

        if (rowChangePassword != null) {
            rowChangePassword.setOnClickListener(v -> openChangePasswordDialog());
        }

        if (rowCurrency != null) {
            rowCurrency.setOnClickListener(v -> openCurrencyDialog());
        }

        if (rowPriceAlerts != null) {
            rowPriceAlerts.setOnClickListener(v -> {
                Intent intent = new Intent(SettingsActivity.this, PriceAlertsActivity.class);
                startActivity(intent);
            });
        }

        if (switchPriceAlerts != null) {
            switchPriceAlerts.setChecked(AppSettingsManager.arePriceAlertsEnabled(this));
            switchPriceAlerts.setOnCheckedChangeListener((buttonView, isChecked) -> {
                AppSettingsManager.savePriceAlertsEnabled(this, isChecked);

                if (isChecked) {
                    PriceAlertMonitor.start(this);
                }

                Toast.makeText(
                        this,
                        isChecked ? "Price alerts enabled" : "Price alerts disabled",
                        Toast.LENGTH_SHORT
                ).show();
            });
        }






        if (switchPrivacy != null) {
            switchPrivacy.setOnCheckedChangeListener(null);
            switchPrivacy.setChecked(ProfilePrefs.isProfilePrivate(this));
            switchPrivacy.setOnCheckedChangeListener((buttonView, isChecked) ->
                    applyProfilePrivacy(isChecked, true)
            );
        }

        if (rowPrivacy != null) {
            rowPrivacy.setOnClickListener(v -> openPrivacyDialog());
        }

        if (rowAbout != null) {
            rowAbout.setOnClickListener(v -> showAboutDialog());
        }

        if (rowLogout != null) {
            rowLogout.setOnClickListener(v -> showLogoutDialog());
        }
    }

    private void safeGoBack() {
        try {
            if (!isTaskRoot()) {
                finish();
                return;
            }

            Intent intent = new Intent(this, TradingDashboardActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
            finish();
        } catch (Exception e) {
            finish();
        }
    }


    private int getExistingId(String... names) {
        if (names == null) {
            return 0;
        }

        for (String name : names) {
            int id = getResources().getIdentifier(name, "id", getPackageName());

            if (id != 0) {
                return id;
            }
        }

        return 0;
    }



    private void loadLocalProfile() {
        currentName = firstNonEmpty(
                AppSettingsManager.getLocalDisplayName(this),
                ProfilePrefs.getDisplayName(this),
                "Trader"
        );

        currentEmail = firstNonEmpty(
                AppSettingsManager.getLocalEmail(this),
                ProfilePrefs.getEmail(this),
                ""
        );

        currentCurrency = AppSettingsManager.getLocalPreferredCurrency(this);

        currentPhotoBase64 = firstNonEmpty(
                AppSettingsManager.getLocalProfilePhotoBase64(this),
                ProfilePrefs.getPhotoBase64(this),
                ""
        );

        currentBirthDate = getProfilePrefs().getString(KEY_BIRTH_DATE, "");
    }

    private void loadRemoteProfile() {
        FirebaseUser user = auth.getCurrentUser();

        if (user == null) {
            return;
        }

        db.collection("users")
                .document(user.getUid())
                .get()
                .addOnSuccessListener(snapshot -> {
                    currentName = firstNonEmpty(
                            snapshot.getString("displayName"),
                            snapshot.getString("fullName"),
                            user.getDisplayName(),
                            currentName,
                            "Trader"
                    );

                    currentEmail = firstNonEmpty(
                            user.getEmail(),
                            snapshot.getString("email"),
                            currentEmail,
                            ""
                    );

                    currentCurrency = AppSettingsManager.normalizeCurrency(firstNonEmpty(
                            snapshot.getString("preferredCurrency"),
                            currentCurrency,
                            "USD"
                    ));

                    String remotePhotoBase64 = firstNonEmpty(
                            snapshot.getString("profilePhotoBase64"),
                            snapshot.getString("photoBase64"),
                            snapshot.getString("profileImageBase64"),
                            ""
                    );

                    String localPhotoBase64 = firstNonEmpty(
                            AppSettingsManager.getLocalProfilePhotoBase64(this),
                            ProfilePrefs.getPhotoBase64(this),
                            currentPhotoBase64,
                            ""
                    );

                    if (localProfilePhotoChangedInSession && !localPhotoBase64.isEmpty()) {
                        currentPhotoBase64 = localPhotoBase64;
                        syncCurrentProfilePhotoToFirebase();
                    } else if (!localPhotoBase64.isEmpty() && !localPhotoBase64.equals(remotePhotoBase64)) {
                        currentPhotoBase64 = localPhotoBase64;
                        syncCurrentProfilePhotoToFirebase();
                    } else {
                        currentPhotoBase64 = firstNonEmpty(remotePhotoBase64, localPhotoBase64, currentPhotoBase64, "");
                    }

                    currentBirthDate = firstNonEmpty(
                            snapshot.getString("dateOfBirth"),
                            snapshot.getString("birthDate"),
                            currentBirthDate,
                            ""
                    );

                    currentBalance = readDouble(
                            snapshot.get("cashBalance"),
                            readDouble(
                                    snapshot.get("availableCash"),
                                    readDouble(snapshot.get("balance"), currentBalance)
                            )
                    );

                    boolean privateProfile = readProfilePrivateFromSnapshot(
                            snapshot,
                            ProfilePrefs.isProfilePrivate(this)
                    );
                    applyProfilePrivacy(privateProfile, false);

                    Boolean priceAlerts = snapshot.getBoolean("priceAlertsEnabled");
                    if (priceAlerts != null) {
                        AppSettingsManager.savePriceAlertsEnabled(this, priceAlerts);
                    }


                    AppSettingsManager.saveProfileLocal(this, currentName, currentEmail, currentPhotoBase64);
                    saveBirthDateLocal(currentBirthDate);
                    AppSettingsManager.savePreferredCurrencyQuick(this, currentCurrency);

                    refreshUi();
                });
    }

    private void refreshUi() {
        if (tvSettingsName != null) {
            tvSettingsName.setText(firstNonEmpty(currentName, "Trader"));
        }

        if (tvSettingsEmail != null) {
            tvSettingsEmail.setText(firstNonEmpty(currentEmail, "No email"));
        }

        if (tvSettingsBirthDate != null) {
            tvSettingsBirthDate.setText(
                    currentBirthDate == null || currentBirthDate.trim().isEmpty()
                            ? "Date of birth: --"
                            : "Date of birth: " + currentBirthDate
            );
        }

        if (tvCurrencyValue != null) {
            tvCurrencyValue.setText("Open");
        }

        if (tvBalanceValue != null) {
            tvBalanceValue.setText(AppSettingsManager.formatUsdAmount(this, currentBalance) + " available");
        }

        if (switchPriceAlerts != null) {
            switchPriceAlerts.setChecked(AppSettingsManager.arePriceAlertsEnabled(this));
        }

        refreshAvatar();
    }

    private void refreshAvatar() {
        if (ivProfileAvatar == null) {
            return;
        }

        Bitmap bitmap = AppSettingsManager.decodeBase64ToBitmap(currentPhotoBase64);

        if (bitmap != null) {
            ivProfileAvatar.setPadding(0, 0, 0, 0);
            ivProfileAvatar.setScaleType(ImageView.ScaleType.CENTER_CROP);

            Glide.with(this)
                    .load(bitmap)
                    .circleCrop()
                    .into(ivProfileAvatar);
        } else {
            ivProfileAvatar.setPadding(0, 0, 0, 0);
            ivProfileAvatar.setScaleType(ImageView.ScaleType.CENTER_CROP);
            ivProfileAvatar.setImageBitmap(createDefaultAvatarBitmap(firstNonEmpty(currentName, "Trader"), dp(76)));
        }
    }

    private Bitmap createDefaultAvatarBitmap(String displayName, int sizePx) {
        int safeSize = Math.max(sizePx, dp(64));
        Bitmap bitmap = Bitmap.createBitmap(safeSize, safeSize, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);

        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setShader(new LinearGradient(
                0,
                0,
                safeSize,
                safeSize,
                new int[]{
                        Color.rgb(49, 93, 255),
                        Color.rgb(116, 87, 255),
                        Color.rgb(38, 221, 156)
                },
                null,
                Shader.TileMode.CLAMP
        ));

        float radius = safeSize / 2f;
        canvas.drawCircle(radius, radius, radius, paint);

        Paint inner = new Paint(Paint.ANTI_ALIAS_FLAG);
        inner.setStyle(Paint.Style.STROKE);
        inner.setStrokeWidth(dp(2));
        inner.setColor(Color.argb(90, 255, 255, 255));
        canvas.drawCircle(radius, radius, radius - dp(3), inner);

        String initial = firstNonEmpty(displayName, "T").substring(0, 1).toUpperCase(Locale.US);

        Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        textPaint.setColor(Color.WHITE);
        textPaint.setTypeface(Typeface.DEFAULT_BOLD);
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setTextSize(safeSize * 0.43f);

        Paint.FontMetrics metrics = textPaint.getFontMetrics();
        float y = radius - (metrics.ascent + metrics.descent) / 2f;
        canvas.drawText(initial, radius, y, textPaint);

        return bitmap;
    }




    private void showBalanceDialog() {
        LinearLayout root = createDialogRoot();
        root.setPadding(dp(22), dp(22), dp(22), dp(20));

        TextView title = createDialogTitle("Account money");
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        LinearLayout balanceCard = new LinearLayout(this);
        balanceCard.setOrientation(LinearLayout.VERTICAL);
        balanceCard.setGravity(Gravity.CENTER);
        balanceCard.setPadding(dp(16), dp(18), dp(16), dp(18));
        balanceCard.setBackgroundResource(R.drawable.bg_settings_profile_card);

        TextView balanceLabel = new TextView(this);
        balanceLabel.setText("Available balance");
        balanceLabel.setTextColor(0xFF8EA0BC);
        balanceLabel.setTextSize(13);
        balanceLabel.setTypeface(null, Typeface.BOLD);
        balanceLabel.setGravity(Gravity.CENTER);
        balanceLabel.setIncludeFontPadding(false);

        TextView balanceAmount = new TextView(this);
        balanceAmount.setText(AppSettingsManager.formatUsdAmount(this, currentBalance));
        balanceAmount.setTextColor(Color.WHITE);
        balanceAmount.setTextSize(30);
        balanceAmount.setTypeface(null, Typeface.BOLD);
        balanceAmount.setGravity(Gravity.CENTER);
        balanceAmount.setPadding(0, dp(7), 0, 0);
        balanceAmount.setIncludeFontPadding(false);

        balanceCard.addView(balanceLabel);
        balanceCard.addView(balanceAmount);

        LinearLayout.LayoutParams balanceCardParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        balanceCardParams.bottomMargin = dp(18);
        root.addView(balanceCard, balanceCardParams);

        final int[] selectedMode = {-1};

        LinearLayout actionStage = new LinearLayout(this);
        actionStage.setOrientation(LinearLayout.VERTICAL);

        TextView actionLabel = new TextView(this);
        actionLabel.setText("Choose action");
        actionLabel.setTextColor(Color.WHITE);
        actionLabel.setTextSize(16);
        actionLabel.setTypeface(null, Typeface.BOLD);
        actionLabel.setGravity(Gravity.CENTER);
        actionLabel.setIncludeFontPadding(false);
        actionStage.addView(actionLabel, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        ));

        LinearLayout modesWrap = new LinearLayout(this);
        modesWrap.setOrientation(LinearLayout.VERTICAL);

        LinearLayout.LayoutParams modesWrapParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        modesWrapParams.topMargin = dp(14);
        modesWrap.setLayoutParams(modesWrapParams);

        LinearLayout addCard = createMoneyModeCard(
                R.drawable.ic_money_add,
                "Add money",
                "Increase available cash",
                Color.rgb(69, 229, 154)
        );

        LinearLayout removeCard = createMoneyModeCard(
                R.drawable.ic_money_remove,
                "Remove money",
                "Withdraw from balance",
                Color.rgb(255, 104, 126)
        );

        LinearLayout setCard = createMoneyModeCard(
                R.drawable.ic_money_set,
                "Set balance",
                "Replace balance amount",
                Color.rgb(105, 135, 255)
        );

        LinearLayout.LayoutParams mode1 = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(74)
        );
        mode1.bottomMargin = dp(10);

        LinearLayout.LayoutParams mode2 = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(74)
        );
        mode2.bottomMargin = dp(10);

        modesWrap.addView(addCard, mode1);
        modesWrap.addView(removeCard, mode2);
        modesWrap.addView(setCard, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(74)
        ));

        actionStage.addView(modesWrap);
        root.addView(actionStage);

        LinearLayout amountStage = new LinearLayout(this);
        amountStage.setOrientation(LinearLayout.VERTICAL);
        amountStage.setVisibility(View.GONE);

        TextView amountLabel = new TextView(this);
        amountLabel.setText("Choose amount");
        amountLabel.setTextColor(Color.WHITE);
        amountLabel.setTextSize(16);
        amountLabel.setTypeface(null, Typeface.BOLD);
        amountLabel.setGravity(Gravity.CENTER);
        amountLabel.setIncludeFontPadding(false);

        amountStage.addView(amountLabel, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        ));

        TextView amountSubtitle = new TextView(this);
        amountSubtitle.setText("");
        amountSubtitle.setTextColor(Color.rgb(142, 160, 188));
        amountSubtitle.setTextSize(12);
        amountSubtitle.setGravity(Gravity.CENTER);
        amountSubtitle.setPadding(0, dp(6), 0, dp(4));
        amountSubtitle.setIncludeFontPadding(false);

        amountStage.addView(amountSubtitle, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        ));

        LinearLayout quickRow = new LinearLayout(this);
        quickRow.setOrientation(LinearLayout.HORIZONTAL);
        quickRow.setPadding(0, dp(14), 0, dp(10));

        String currencySymbol = AppSettingsManager.getCurrencySymbol(currentCurrency);
        TextView quick100 = createSmallMoneyChip(currencySymbol + "100");
        TextView quick500 = createSmallMoneyChip(currencySymbol + "500");
        TextView quick1000 = createSmallMoneyChip(currencySymbol + "1,000");

        LinearLayout.LayoutParams chip1 = new LinearLayout.LayoutParams(0, dp(42), 1f);
        chip1.rightMargin = dp(6);

        LinearLayout.LayoutParams chip2 = new LinearLayout.LayoutParams(0, dp(42), 1f);
        chip2.leftMargin = dp(6);
        chip2.rightMargin = dp(6);

        LinearLayout.LayoutParams chip3 = new LinearLayout.LayoutParams(0, dp(42), 1f);
        chip3.leftMargin = dp(6);

        quickRow.addView(quick100, chip1);
        quickRow.addView(quick500, chip2);
        quickRow.addView(quick1000, chip3);
        amountStage.addView(quickRow);

        EditText input = createDialogInput("Enter amount", "");
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        input.setGravity(Gravity.CENTER);
        amountStage.addView(input);

        LinearLayout stageButtons = new LinearLayout(this);
        stageButtons.setOrientation(LinearLayout.HORIZONTAL);
        stageButtons.setPadding(0, dp(14), 0, 0);

        TextView back = createDialogCancelButton("Back");
        TextView apply = createDialogSaveButton("Apply");

        LinearLayout.LayoutParams backParams = new LinearLayout.LayoutParams(0, dp(46), 1f);
        backParams.rightMargin = dp(10);
        stageButtons.addView(back, backParams);

        stageButtons.addView(apply, new LinearLayout.LayoutParams(0, dp(46), 1f));
        amountStage.addView(stageButtons);

        root.addView(amountStage);

        TextView cancel = createDialogCancelButton("Cancel");
        LinearLayout cancelWrap = new LinearLayout(this);
        cancelWrap.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams cancelParams = new LinearLayout.LayoutParams(dp(120), dp(44));
        cancelWrap.addView(cancel, cancelParams);

        LinearLayout.LayoutParams cancelWrapParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        cancelWrapParams.topMargin = dp(16);
        root.addView(cancelWrap, cancelWrapParams);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(root)
                .create();

        makeDialogTransparent(dialog);

        View.OnClickListener showAmountStage = v -> {
            input.setText("");
            actionStage.animate()
                    .alpha(0f)
                    .translationX(-dp(20))
                    .setDuration(140)
                    .withEndAction(() -> {
                        actionStage.setVisibility(View.GONE);
                        actionStage.setAlpha(1f);
                        actionStage.setTranslationX(0f);

                        amountStage.setAlpha(0f);
                        amountStage.setTranslationX(dp(20));
                        amountStage.setVisibility(View.VISIBLE);
                        amountStage.animate()
                                .alpha(1f)
                                .translationX(0f)
                                .setDuration(170)
                                .start();
                    })
                    .start();
        };

        addCard.setOnClickListener(v -> {
            selectedMode[0] = 0;
            amountSubtitle.setText("How much would you like to add?");
            input.setHint("Amount to add");
            showAmountStage.onClick(v);
        });

        removeCard.setOnClickListener(v -> {
            selectedMode[0] = 1;
            amountSubtitle.setText("How much would you like to remove?");
            input.setHint("Amount to remove");
            showAmountStage.onClick(v);
        });

        setCard.setOnClickListener(v -> {
            selectedMode[0] = 2;
            amountSubtitle.setText("What should the new balance be?");
            input.setHint("New balance");
            showAmountStage.onClick(v);
        });

        quick100.setOnClickListener(v -> input.setText("100"));
        quick500.setOnClickListener(v -> input.setText("500"));
        quick1000.setOnClickListener(v -> input.setText("1000"));

        back.setOnClickListener(v -> {
            amountStage.animate()
                    .alpha(0f)
                    .translationX(dp(20))
                    .setDuration(140)
                    .withEndAction(() -> {
                        amountStage.setVisibility(View.GONE);
                        amountStage.setAlpha(1f);
                        amountStage.setTranslationX(0f);

                        actionStage.setAlpha(0f);
                        actionStage.setTranslationX(-dp(20));
                        actionStage.setVisibility(View.VISIBLE);
                        actionStage.animate()
                                .alpha(1f)
                                .translationX(0f)
                                .setDuration(170)
                                .start();
                    })
                    .start();
        });

        cancel.setOnClickListener(v -> dialog.dismiss());

        apply.setOnClickListener(v -> {
            Double amount = readAmount(input);
            if (amount == null) {
                return;
            }

            if (selectedMode[0] == 0) {
                updateBalance(currentBalance + selectedCurrencyAmountToUsd(amount));
                dialog.dismiss();
                return;
            }

            if (selectedMode[0] == 1) {
                double newBalance = currentBalance - selectedCurrencyAmountToUsd(amount);

                if (newBalance < 0) {
                    Toast.makeText(this, "You cannot remove more than your balance", Toast.LENGTH_SHORT).show();
                    return;
                }

                updateBalance(newBalance);
                dialog.dismiss();
                return;
            }

            if (selectedMode[0] == 2) {
                updateBalance(selectedCurrencyAmountToUsd(amount));
                dialog.dismiss();
            }
        });

        dialog.show();
    }


    

    private TextView createSmallMoneyChip(String text) {
        TextView chip = new TextView(this);
        chip.setText(text);
        chip.setTextColor(Color.WHITE);
        chip.setTextSize(13);
        chip.setTypeface(null, Typeface.BOLD);
        chip.setGravity(Gravity.CENTER);
        chip.setIncludeFontPadding(false);
        chip.setBackground(createMoneyModeBackground(
                Color.rgb(18, 32, 58),
                Color.rgb(72, 102, 160)
        ));
        return chip;
    }


    private View createMoneyActionRow(
            String iconText,
            String titleText,
            String subtitleText,
            int iconColor,
            boolean danger
    ) {
        return null;
    }

    private LinearLayout createMoneyModeCard(
            @DrawableRes int iconRes,
            String titleText,
            String subtitleText,
            int accentColor
    ) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(14), 0, dp(14), 0);
        row.setClickable(true);
        row.setFocusable(true);

        ImageView icon = new ImageView(this);
        icon.setImageResource(iconRes);
        icon.setTag("moneyIcon");
        icon.setColorFilter(accentColor);
        icon.setBackground(createMoneyIconBackground(adjustAlpha(accentColor, 0.16f), accentColor));
        icon.setPadding(dp(10), dp(10), dp(10), dp(10));

        LinearLayout.LayoutParams iconParams = new LinearLayout.LayoutParams(dp(42), dp(42));
        iconParams.rightMargin = dp(12);
        row.addView(icon, iconParams);

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setGravity(Gravity.CENTER_VERTICAL);

        TextView title = new TextView(this);
        title.setTag("moneyTitle");
        title.setText(titleText);
        title.setTextColor(Color.WHITE);
        title.setTextSize(15);
        title.setTypeface(null, Typeface.BOLD);
        title.setIncludeFontPadding(false);

        TextView subtitle = new TextView(this);
        subtitle.setTag("moneySubtitle");
        subtitle.setText(subtitleText);
        subtitle.setTextColor(0xFF8EA0BC);
        subtitle.setTextSize(12);
        subtitle.setPadding(0, dp(5), 0, 0);
        subtitle.setIncludeFontPadding(false);

        texts.addView(title);
        texts.addView(subtitle);

        row.addView(texts, new LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.WRAP_CONTENT,
                1f
        ));

        TextView check = new TextView(this);
        check.setTag("moneyCheck");
        check.setText("✓");
        check.setTextSize(18);
        check.setTypeface(null, Typeface.BOLD);
        check.setGravity(Gravity.CENTER);
        row.addView(check, new LinearLayout.LayoutParams(dp(24), LinearLayout.LayoutParams.WRAP_CONTENT));

        updateMoneyModeSelection(row, false, accentColor);
        return row;
    }

    private void updateMoneyModeSelection(View card, boolean selected, int accentColor) {
        if (!(card instanceof LinearLayout)) {
            return;
        }

        LinearLayout row = (LinearLayout) card;
        ImageView icon = row.findViewWithTag("moneyIcon");
        TextView title = row.findViewWithTag("moneyTitle");
        TextView subtitle = row.findViewWithTag("moneySubtitle");
        TextView check = row.findViewWithTag("moneyCheck");

        row.setBackground(createMoneyModeBackground(
                selected ? adjustAlpha(accentColor, 0.16f) : Color.rgb(10, 20, 38),
                selected ? accentColor : Color.rgb(37, 57, 89)
        ));

        if (icon != null) {
            icon.setColorFilter(accentColor);
            icon.setBackground(createMoneyIconBackground(
                    selected ? adjustAlpha(accentColor, 0.24f) : Color.rgb(22, 36, 63),
                    selected ? accentColor : Color.rgb(85, 110, 160)
            ));
        }

        if (title != null) {
            title.setTextColor(selected ? Color.WHITE : Color.rgb(236, 242, 255));
        }

        if (subtitle != null) {
            subtitle.setTextColor(selected ? adjustAlpha(Color.WHITE, 0.78f) : 0xFF8EA0BC);
        }

        if (check != null) {
            check.setTextColor(selected ? accentColor : Color.rgb(75, 96, 131));
            check.setAlpha(selected ? 1f : 0.35f);
        }
    }

    private GradientDrawable createMoneyModeBackground(int fillColor, int strokeColor) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(fillColor);
        drawable.setCornerRadius(dp(18));
        drawable.setStroke(dp(1), strokeColor);
        return drawable;
    }

    private GradientDrawable createMoneyIconBackground(int fillColor, int strokeColor) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(fillColor);
        drawable.setCornerRadius(dp(16));
        drawable.setStroke(dp(1), strokeColor);
        return drawable;
    }

    private int adjustAlpha(int color, float factor) {
        int alpha = Math.round(Color.alpha(color) * factor);
        return Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color));
    }


    private Double readAmount(EditText input) {
        String text = input.getText() == null ? "" : input.getText().toString().trim();

        if (text.isEmpty()) {
            Toast.makeText(this, "Enter amount", Toast.LENGTH_SHORT).show();
            return null;
        }

        try {
            double amount = Double.parseDouble(text);

            if (amount < 0) {
                Toast.makeText(this, "Amount must be positive", Toast.LENGTH_SHORT).show();
                return null;
            }

            return amount;
        } catch (Exception e) {
            Toast.makeText(this, "Invalid amount", Toast.LENGTH_SHORT).show();
            return null;
        }
    }

    private double selectedCurrencyAmountToUsd(double selectedAmount) {
        double rate = AppSettingsManager.getUsdToSelectedCurrencyRate(this);
        if (rate <= 0.0) {
            return selectedAmount;
        }
        return selectedAmount / rate;
    }

    private void updateBalance(double newBalance) {
        currentBalance = Math.max(0, newBalance);

        FirebaseUser user = auth.getCurrentUser();
        if (user == null) {
            refreshUi();
            return;
        }

        Map<String, Object> patch = new HashMap<>();
        patch.put("cashBalance", currentBalance);
        patch.put("availableCash", currentBalance);
        patch.put("availableBalance", currentBalance);
        patch.put("buyingPower", currentBalance);
        patch.put("balance", currentBalance);
        patch.put("balanceUpdatedAt", System.currentTimeMillis());

        db.collection("users")
                .document(user.getUid())
                .set(patch, SetOptions.merge())
                .addOnSuccessListener(unused -> {
                    refreshUi();
                    Toast.makeText(this, "Balance updated", Toast.LENGTH_SHORT).show();
                })
                .addOnFailureListener(e ->
                        Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show()
                );
    }

    private void requestImagePermissionAndPick() {
        if (Build.VERSION.SDK_INT >= 33) {
            if (checkSelfPermission(Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED) {
                openImagePicker();
            } else {
                imagePermissionLauncher.launch(Manifest.permission.READ_MEDIA_IMAGES);
            }
            return;
        }

        if (Build.VERSION.SDK_INT >= 23) {
            if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                openImagePicker();
            } else {
                imagePermissionLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE);
            }
            return;
        }

        openImagePicker();
    }

    private void openImagePicker() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("image/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        imagePickerLauncher.launch(Intent.createChooser(intent, "Choose profile image"));
    }

    private void startProfileImageCrop(@NonNull Uri sourceUri) {
        String fileName = "profile_crop_" + System.currentTimeMillis() + ".jpg";
        Uri destinationUri = Uri.fromFile(new File(getCacheDir(), fileName));

        UCrop.Options options = new UCrop.Options();
        options.setCompressionQuality(92);
        options.setHideBottomControls(false);
        options.setFreeStyleCropEnabled(true);
        options.setCircleDimmedLayer(true);
        options.setShowCropFrame(true);
        options.setShowCropGrid(true);
        options.setToolbarTitle("Crop profile photo");
        options.setToolbarColor(0xFF101A2D);
        options.setStatusBarColor(0xFF09111F);
        options.setActiveControlsWidgetColor(0xFF4A6CFF);
        options.setToolbarWidgetColor(Color.WHITE);

        Intent cropIntent = UCrop.of(sourceUri, destinationUri)
                .withAspectRatio(1, 1)
                .withMaxResultSize(1024, 1024)
                .withOptions(options)
                .getIntent(this);

        cropLauncher.launch(cropIntent);
    }

    private void saveProfilePhoto() {
        if (pendingProfileImageUri == null) {
            return;
        }

        try {
            String encodedPhoto = ProfilePrefs.encodeImageUriToCircularBase64(this, pendingProfileImageUri, 512);

            if (encodedPhoto == null || encodedPhoto.trim().isEmpty()) {
                encodedPhoto = AppSettingsManager.encodeImageUriToBase64(this, pendingProfileImageUri);
            }

            if (encodedPhoto == null || encodedPhoto.trim().isEmpty()) {
                Toast.makeText(this, "Could not save image", Toast.LENGTH_SHORT).show();
                return;
            }

            currentPhotoBase64 = encodedPhoto.trim();
            localProfilePhotoChangedInSession = true;

            AppSettingsManager.saveProfileLocal(this, currentName, currentEmail, currentPhotoBase64);
            ProfilePrefs.saveProfile(this, currentName, currentEmail, currentPhotoBase64);

            refreshUi();
            refreshActiveProfileDialogPreview();
            syncCurrentProfilePhotoToFirebase();

            Toast.makeText(this, "Profile photo updated", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Could not save image", Toast.LENGTH_SHORT).show();
        }
    }


    private void openEditProfileDialog() {
        LinearLayout root = createDialogRoot();

        TextView title = createDialogTitle("Update profile");
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        ImageView preview = new ImageView(this);
        preview.setScaleType(ImageView.ScaleType.CENTER_CROP);
        activeProfileDialogPreview = preview;
        refreshActiveProfileDialogPreview();

        FrameLayout previewWrap = createEditablePhotoPreview(preview);
        LinearLayout.LayoutParams previewWrapParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        previewWrapParams.gravity = Gravity.CENTER_HORIZONTAL;
        previewWrapParams.bottomMargin = dp(12);
        root.addView(previewWrap, previewWrapParams);

        TextView removePhoto = createTinyDangerText("Remove profile picture");
        LinearLayout.LayoutParams removeParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        removeParams.gravity = Gravity.CENTER_HORIZONTAL;
        removeParams.bottomMargin = dp(6);
        root.addView(removePhoto, removeParams);

        EditText usernameInput = createDialogInput("Username", currentName);

        EditText birthDateInput = createDialogInput("Date of birth", currentBirthDate);
        birthDateInput.setInputType(InputType.TYPE_NULL);
        birthDateInput.setFocusable(false);
        birthDateInput.setClickable(true);
        birthDateInput.setCursorVisible(false);

        birthDateInput.setOnClickListener(v ->
                showBirthDatePicker(
                        birthDateInput.getText() == null ? "" : birthDateInput.getText().toString().trim(),
                        value -> birthDateInput.setText(value)
                )
        );

        root.addView(usernameInput);
        root.addView(birthDateInput);

        LinearLayout actions = createDialogActions();
        TextView cancel = createDialogCancelButton("Cancel");
        TextView save = createDialogSaveButton("Save");

        actions.addView(cancel);
        actions.addView(save);
        styleCurrencyDialogActions(actions, cancel, save);
        root.addView(actions);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(root)
                .create();

        dialog.setOnDismissListener(d -> activeProfileDialogPreview = null);
        makeDialogTransparent(dialog);

        cancel.setOnClickListener(v -> dialog.dismiss());

        previewWrap.setOnClickListener(v -> requestImagePermissionAndPick());
        preview.setOnClickListener(v -> requestImagePermissionAndPick());

        removePhoto.setOnClickListener(v -> {
            removeProfilePhoto();
            refreshActiveProfileDialogPreview();
        });

        save.setOnClickListener(v -> {
            String newName = usernameInput.getText() == null ? "" : usernameInput.getText().toString().trim();
            String newBirthDate = birthDateInput.getText() == null ? "" : birthDateInput.getText().toString().trim();

            if (newName.isEmpty()) {
                Toast.makeText(this, "Enter username", Toast.LENGTH_SHORT).show();
                return;
            }

            if (newBirthDate.isEmpty()) {
                Toast.makeText(this, "Choose date of birth", Toast.LENGTH_SHORT).show();
                return;
            }

            validateUsernameAndSaveProfile(newName, newBirthDate, dialog);
        });

        dialog.show();
    }



    private TextView createDangerOutlineButton(String text) {
        return createTinyDangerText(text);
    }

    private TextView createTinyDangerText(String text) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextColor(Color.rgb(255, 112, 136));
        view.setTextSize(12);
        view.setTypeface(null, Typeface.BOLD);
        view.setIncludeFontPadding(false);
        view.setPadding(dp(4), dp(2), dp(4), dp(2));
        return view;
    }

    private FrameLayout createEditablePhotoPreview(ImageView preview) {
        FrameLayout wrap = new FrameLayout(this);

        FrameLayout.LayoutParams previewParams = new FrameLayout.LayoutParams(dp(88), dp(88));
        previewParams.gravity = Gravity.CENTER;
        wrap.addView(preview, previewParams);

        LinearLayout badge = new LinearLayout(this);
        badge.setOrientation(LinearLayout.HORIZONTAL);
        badge.setGravity(Gravity.CENTER_VERTICAL);
        badge.setPadding(dp(8), dp(5), dp(8), dp(5));
        badge.setBackground(createMoneyModeBackground(Color.rgb(47, 79, 210), Color.rgb(123, 153, 255)));

        ImageView badgeIcon = new ImageView(this);
        badgeIcon.setImageResource(R.drawable.ic_edit_photo);
        badgeIcon.setColorFilter(Color.WHITE);
        LinearLayout.LayoutParams badgeIconParams = new LinearLayout.LayoutParams(dp(14), dp(14));
        badgeIconParams.rightMargin = dp(5);
        badge.addView(badgeIcon, badgeIconParams);

        TextView badgeText = new TextView(this);
        badgeText.setText("Edit");
        badgeText.setTextColor(Color.WHITE);
        badgeText.setTextSize(11);
        badgeText.setTypeface(null, Typeface.BOLD);
        badgeText.setIncludeFontPadding(false);
        badge.addView(badgeText);

        FrameLayout.LayoutParams badgeParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT
        );
        badgeParams.gravity = Gravity.END | Gravity.BOTTOM;
        badgeParams.rightMargin = -dp(4);
        badgeParams.bottomMargin = -dp(2);
        wrap.addView(badge, badgeParams);
        return wrap;
    }

    private void refreshActiveProfileDialogPreview() {
        if (activeProfileDialogPreview == null) {
            return;
        }

        Bitmap currentBitmap = AppSettingsManager.decodeBase64ToBitmap(currentPhotoBase64);
        if (currentBitmap != null) {
            Glide.with(this).load(currentBitmap).circleCrop().into(activeProfileDialogPreview);
        } else {
            activeProfileDialogPreview.setImageBitmap(
                    createDefaultAvatarBitmap(firstNonEmpty(currentName, "Trader"), dp(88))
            );
        }
    }


    private void removeProfilePhoto() {
        currentPhotoBase64 = "";
        pendingProfileImageUri = null;
        localProfilePhotoChangedInSession = true;

        AppSettingsManager.saveProfileLocal(this, currentName, currentEmail, "");
        ProfilePrefs.saveProfile(this, currentName, currentEmail, "");

        FirebaseUser user = auth.getCurrentUser();
        if (user != null) {
            Map<String, Object> patch = new HashMap<>();
            patch.put("profilePhotoBase64", "");
            patch.put("photoBase64", "");
            patch.put("profileImageBase64", "");
            patch.put("profilePhotoUpdatedAt", System.currentTimeMillis());

            db.collection("users")
                    .document(user.getUid())
                    .set(patch, SetOptions.merge())
                    .addOnSuccessListener(unused -> {
                        updateGlobalChatMessagesWithCurrentPhoto(user.getUid(), "");
                        refreshUi();
                        refreshActiveProfileDialogPreview();
                        Toast.makeText(this, "Profile photo removed", Toast.LENGTH_SHORT).show();
                    })
                    .addOnFailureListener(e ->
                            Toast.makeText(this, "Could not remove photo: " + e.getMessage(), Toast.LENGTH_LONG).show()
                    );
        } else {
            refreshUi();
            refreshActiveProfileDialogPreview();
            Toast.makeText(this, "Profile photo removed", Toast.LENGTH_SHORT).show();
        }
    }

    private void validateUsernameAndSaveProfile(String newName, String newBirthDate, AlertDialog dialog) {
        FirebaseUser user = auth.getCurrentUser();

        if (user == null) {
            Toast.makeText(this, "User not found", Toast.LENGTH_SHORT).show();
            return;
        }

        String cleanName = newName.trim();
        String normalized = normalizeUsername(cleanName);
        String currentNormalized = normalizeUsername(currentName);

        if (normalized.equals(currentNormalized)) {
            saveProfileAfterUsernameCheck(cleanName, newBirthDate, dialog);
            return;
        }

        db.collection("users")
                .whereEqualTo("usernameLower", normalized)
                .get()
                .addOnSuccessListener(querySnapshot -> {
                    boolean usernameTaken = false;

                    for (QueryDocumentSnapshot document : querySnapshot) {
                        if (!document.getId().equals(user.getUid())) {
                            usernameTaken = true;
                            break;
                        }
                    }

                    if (usernameTaken) {
                        Toast.makeText(this, "This username already exists", Toast.LENGTH_LONG).show();
                        return;
                    }

                    checkDisplayNameExactFallback(cleanName, normalized, newBirthDate, dialog, user.getUid());
                })
                .addOnFailureListener(e ->
                        Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show()
                );
    }

    private void checkDisplayNameExactFallback(
            String cleanName,
            String normalized,
            String newBirthDate,
            AlertDialog dialog,
            String currentUid
    ) {
        db.collection("users")
                .whereEqualTo("displayName", cleanName)
                .get()
                .addOnSuccessListener(querySnapshot -> {
                    boolean usernameTaken = false;

                    for (QueryDocumentSnapshot document : querySnapshot) {
                        if (!document.getId().equals(currentUid)) {
                            usernameTaken = true;
                            break;
                        }
                    }

                    if (usernameTaken) {
                        Toast.makeText(this, "This username already exists", Toast.LENGTH_LONG).show();
                        return;
                    }

                    saveProfileAfterUsernameCheck(cleanName, newBirthDate, dialog);
                })
                .addOnFailureListener(e ->
                        Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show()
                );
    }

    private void saveProfileAfterUsernameCheck(String newName, String newBirthDate, AlertDialog dialog) {
        currentName = newName;
        currentBirthDate = newBirthDate;

        AppSettingsManager.saveProfileLocal(this, currentName, currentEmail, currentPhotoBase64);
        ProfilePrefs.saveProfile(this, currentName, currentEmail, currentPhotoBase64);
        saveBirthDateLocal(currentBirthDate);
        saveProfileToFirebase();
        refreshUi();

        Toast.makeText(this, "Profile updated", Toast.LENGTH_SHORT).show();
        dialog.dismiss();
    }

    private String normalizeUsername(String username) {
        if (username == null) {
            return "";
        }

        return username.trim().toLowerCase(Locale.US);
    }

    private void showBirthDatePicker(@Nullable String currentValue, @NonNull DateSelectionCallback callback) {
        AlertDialog dialog = createBirthDatePickerDialog(currentValue, callback);
        dialog.show();
    }

    private AlertDialog createBirthDatePickerDialog(@Nullable String currentValue, @NonNull DateSelectionCallback callback) {
        Calendar calendar = parseBirthDateOrDefault(currentValue);

        LinearLayout root = createDialogRoot();

        TextView title = createDialogTitle("Select date of birth");
        TextView subtitle = createDialogSubtitle("Choose your day, month and year.");

        LinearLayout pickerRow = new LinearLayout(this);
        pickerRow.setOrientation(LinearLayout.HORIZONTAL);
        pickerRow.setGravity(Gravity.CENTER);
        pickerRow.setPadding(0, 0, 0, dp(18));

        NumberPicker dayPicker = new NumberPicker(this);
        NumberPicker monthPicker = new NumberPicker(this);
        NumberPicker yearPicker = new NumberPicker(this);

        styleNumberPicker(dayPicker);
        styleNumberPicker(monthPicker);
        styleNumberPicker(yearPicker);

        int currentYear = Calendar.getInstance().get(Calendar.YEAR);

        dayPicker.setMinValue(1);
        dayPicker.setMaxValue(31);
        dayPicker.setValue(calendar.get(Calendar.DAY_OF_MONTH));
        dayPicker.setWrapSelectorWheel(true);

        monthPicker.setMinValue(0);
        monthPicker.setMaxValue(11);
        monthPicker.setDisplayedValues(monthNames);
        monthPicker.setValue(calendar.get(Calendar.MONTH));
        monthPicker.setWrapSelectorWheel(true);

        yearPicker.setMinValue(1940);
        yearPicker.setMaxValue(currentYear);
        yearPicker.setValue(calendar.get(Calendar.YEAR));
        yearPicker.setWrapSelectorWheel(false);

        updateDayPickerMax(dayPicker, monthPicker.getValue(), yearPicker.getValue());

        monthPicker.setOnValueChangedListener((picker, oldVal, newVal) ->
                updateDayPickerMax(dayPicker, newVal, yearPicker.getValue()));

        yearPicker.setOnValueChangedListener((picker, oldVal, newVal) ->
                updateDayPickerMax(dayPicker, monthPicker.getValue(), newVal));

        LinearLayout.LayoutParams pickerParams = new LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.WRAP_CONTENT,
                1f
        );
        pickerParams.leftMargin = dp(4);
        pickerParams.rightMargin = dp(4);

        pickerRow.addView(dayPicker, pickerParams);
        pickerRow.addView(monthPicker, pickerParams);
        pickerRow.addView(yearPicker, pickerParams);

        LinearLayout actions = createDialogActions();
        TextView cancel = createDialogCancelButton("Cancel");
        TextView save = createDialogSaveButton("Save");

        actions.addView(cancel);
        actions.addView(save);
        styleCurrencyDialogActions(actions, cancel, save);

        root.addView(title);
        root.addView(subtitle);
        root.addView(pickerRow);
        root.addView(actions);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(root)
                .create();

        makeDialogTransparent(dialog);

        cancel.setOnClickListener(v -> dialog.dismiss());

        save.setOnClickListener(v -> {
            int day = dayPicker.getValue();
            int month = monthPicker.getValue() + 1;
            int year = yearPicker.getValue();

            String formatted = String.format(Locale.getDefault(), "%02d/%02d/%04d", day, month, year);
            callback.onDateSelected(formatted);
            dialog.dismiss();
        });

        return dialog;
    }

    private void styleNumberPicker(NumberPicker picker) {
        picker.setDescendantFocusability(NumberPicker.FOCUS_BLOCK_DESCENDANTS);
    }

    private void updateDayPickerMax(NumberPicker dayPicker, int month, int year) {
        int maxDay = getDaysInMonth(month, year);
        int currentDay = dayPicker.getValue();

        dayPicker.setMaxValue(maxDay);

        if (currentDay > maxDay) {
            dayPicker.setValue(maxDay);
        }
    }

    private int getDaysInMonth(int month, int year) {
        switch (month) {
            case 0:
                return 31;
            case 1:
                return isLeapYear(year) ? 29 : 28;
            case 2:
                return 31;
            case 3:
                return 30;
            case 4:
                return 31;
            case 5:
                return 30;
            case 6:
                return 31;
            case 7:
                return 31;
            case 8:
                return 30;
            case 9:
                return 31;
            case 10:
                return 30;
            case 11:
                return 31;
            default:
                return 31;
        }
    }

    private boolean isLeapYear(int year) {
        return (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
    }

    private Calendar parseBirthDateOrDefault(@Nullable String value) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.YEAR, 2000);
        calendar.set(Calendar.MONTH, Calendar.JANUARY);
        calendar.set(Calendar.DAY_OF_MONTH, 1);

        if (value == null || value.trim().isEmpty()) {
            return calendar;
        }

        try {
            String[] parts = value.split("/");
            if (parts.length == 3) {
                int day = Integer.parseInt(parts[0]);
                int month = Integer.parseInt(parts[1]) - 1;
                int year = Integer.parseInt(parts[2]);

                calendar.set(Calendar.DAY_OF_MONTH, day);
                calendar.set(Calendar.MONTH, month);
                calendar.set(Calendar.YEAR, year);
            }
        } catch (Exception ignored) {
        }

        return calendar;
    }

    private void openChangePasswordDialog() {
        LinearLayout root = createDialogRoot();

        TextView title = createDialogTitle("Change password");
        title.setGravity(Gravity.CENTER);

        TextView subtitle = createDialogSubtitle(
                "Enter your current password, then choose a new password and confirm it.\n\n" +
                        "The new password must contain at least 8 characters, one uppercase letter, one lowercase letter and one number."
        );
        subtitle.setGravity(Gravity.CENTER);

        root.addView(title);
        root.addView(subtitle);

        EditText currentPasswordInput = createDialogInput("Current password", "");
        currentPasswordInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        currentPasswordInput.setGravity(Gravity.CENTER);
        setupPasswordToggle(currentPasswordInput);

        EditText newPasswordInput = createDialogInput("New password", "");
        newPasswordInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        newPasswordInput.setGravity(Gravity.CENTER);
        setupPasswordToggle(newPasswordInput);

        EditText confirmPasswordInput = createDialogInput("Confirm new password", "");
        confirmPasswordInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        confirmPasswordInput.setGravity(Gravity.CENTER);
        setupPasswordToggle(confirmPasswordInput);

        root.addView(currentPasswordInput);
        root.addView(newPasswordInput);
        root.addView(confirmPasswordInput);

        LinearLayout actions = createDialogActions();
        TextView cancel = createDialogCancelButton("Cancel");
        TextView save = createDialogSaveButton("Save");

        actions.addView(cancel);
        actions.addView(save);
        styleCurrencyDialogActions(actions, cancel, save);
        root.addView(actions);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(root)
                .create();

        makeDialogTransparent(dialog);

        cancel.setOnClickListener(v -> dialog.dismiss());

        save.setOnClickListener(v -> {
            String currentPassword = currentPasswordInput.getText() == null
                    ? ""
                    : currentPasswordInput.getText().toString().trim();

            String newPassword = newPasswordInput.getText() == null
                    ? ""
                    : newPasswordInput.getText().toString().trim();

            String confirmPassword = confirmPasswordInput.getText() == null
                    ? ""
                    : confirmPasswordInput.getText().toString().trim();

            if (currentPassword.isEmpty()) {
                Toast.makeText(this, "Enter current password", Toast.LENGTH_SHORT).show();
                return;
            }

            if (!isStrongPassword(newPassword)) {
                Toast.makeText(
                        this,
                        "Password must be at least 8 chars with uppercase, lowercase and number",
                        Toast.LENGTH_LONG
                ).show();
                return;
            }

            if (!newPassword.equals(confirmPassword)) {
                Toast.makeText(this, "Password confirmation does not match", Toast.LENGTH_SHORT).show();
                return;
            }

            FirebaseUser user = auth.getCurrentUser();
            String email = user != null ? user.getEmail() : null;

            if (user == null || email == null || email.trim().isEmpty()) {
                Toast.makeText(this, "No active email/password user", Toast.LENGTH_SHORT).show();
                return;
            }

            AuthCredential credential = EmailAuthProvider.getCredential(email, currentPassword);

            user.reauthenticate(credential).addOnCompleteListener(reauthTask -> {
                if (!reauthTask.isSuccessful()) {
                    String msg = reauthTask.getException() != null
                            ? reauthTask.getException().getMessage()
                            : "Current password is incorrect";

                    Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
                    return;
                }

                user.updatePassword(newPassword).addOnCompleteListener(updateTask -> {
                    if (updateTask.isSuccessful()) {
                        Toast.makeText(this, "Password updated successfully", Toast.LENGTH_SHORT).show();
                        dialog.dismiss();
                    } else {
                        String msg = updateTask.getException() != null
                                ? updateTask.getException().getMessage()
                                : "Could not update password";

                        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
                    }
                });
            });
        });

        dialog.show();
    }


    private void setupPasswordToggle(EditText editText) {
        if (editText == null) {
            return;
        }

        final boolean[] passwordVisible = new boolean[]{false};

        applyPasswordState(editText, false);

        editText.post(() -> {
            passwordVisible[0] = false;
            applyPasswordState(editText, false);
        });

        editText.setOnTouchListener((view, event) -> {
            if (event.getAction() != MotionEvent.ACTION_UP) {
                return false;
            }

            if (!didTapPasswordEye(editText, event)) {
                return false;
            }

            passwordVisible[0] = !passwordVisible[0];
            applyPasswordState(editText, passwordVisible[0]);

            return true;
        });
    }

    private void applyPasswordState(EditText editText, boolean visible) {
        if (editText == null) {
            return;
        }

        int selection = safeSelection(editText);

        editText.setSingleLine(true);
        editText.setInputType(InputType.TYPE_CLASS_TEXT
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
                | (visible
                ? InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                : InputType.TYPE_TEXT_VARIATION_PASSWORD));

        editText.setTransformationMethod(visible
                ? null
                : BulletPasswordTransformationMethod.getInstance());

        int icon = visible ? R.drawable.ic_eye_show : R.drawable.ic_eye_hide;

        editText.setCompoundDrawablePadding(dp(10));
        editText.setCompoundDrawablesRelativeWithIntrinsicBounds(
                0,
                0,
                icon,
                0
        );

        restoreSelection(editText, selection);
    }

    private boolean didTapPasswordEye(EditText editText, MotionEvent event) {
        if (editText == null) {
            return false;
        }

        Drawable eye = editText.getCompoundDrawablesRelative()[2];

        if (eye == null) {
            eye = editText.getCompoundDrawables()[2];
        }

        if (eye == null) {
            return false;
        }

        int drawableWidth = Math.max(eye.getIntrinsicWidth(), dp(24));
        int touchArea = dp(34);

        if (editText.getLayoutDirection() == View.LAYOUT_DIRECTION_RTL) {
            return event.getX() <= editText.getPaddingLeft() + drawableWidth + touchArea;
        }

        return event.getX() >= editText.getWidth()
                - editText.getPaddingRight()
                - drawableWidth
                - touchArea;
    }

    private int safeSelection(EditText editText) {
        int selection = editText.getSelectionStart();

        if (selection < 0) {
            return editText.getText() == null ? 0 : editText.getText().length();
        }

        return selection;
    }

    private void restoreSelection(EditText editText, int selection) {
        int length = editText.getText() == null ? 0 : editText.getText().length();

        if (selection < 0 || selection > length) {
            selection = length;
        }

        editText.setSelection(selection);
    }

    private static final class BulletPasswordTransformationMethod extends PasswordTransformationMethod {
        private static final BulletPasswordTransformationMethod INSTANCE =
                new BulletPasswordTransformationMethod();

        public static BulletPasswordTransformationMethod getInstance() {
            return INSTANCE;
        }

        @Override
        public CharSequence getTransformation(CharSequence source, View view) {
            return new BulletPasswordCharSequence(source);
        }

        private static final class BulletPasswordCharSequence implements CharSequence {
            private final CharSequence source;

            BulletPasswordCharSequence(CharSequence source) {
                this.source = source == null ? "" : source;
            }

            @Override
            public int length() {
                return source.length();
            }

            @Override
            public char charAt(int index) {
                return '•';
            }

            @Override
            public CharSequence subSequence(int start, int end) {
                StringBuilder builder = new StringBuilder();

                for (int i = start; i < end; i++) {
                    builder.append('•');
                }

                return builder.toString();
            }

            @Override
            public String toString() {
                StringBuilder builder = new StringBuilder();

                for (int i = 0; i < source.length(); i++) {
                    builder.append('•');
                }

                return builder.toString();
            }
        }
    }

    private boolean isStrongPassword(@NonNull String password) {
        if (password.length() < 8) {
            return false;
        }

        boolean hasUpper = false;
        boolean hasLower = false;
        boolean hasDigit = false;

        for (int i = 0; i < password.length(); i++) {
            char c = password.charAt(i);

            if (Character.isUpperCase(c)) {
                hasUpper = true;
            } else if (Character.isLowerCase(c)) {
                hasLower = true;
            } else if (Character.isDigit(c)) {
                hasDigit = true;
            }
        }

        return hasUpper && hasLower && hasDigit;
    }

    private void openCurrencyDialog() {
        final String[] codes = new String[]{"USD", "EUR", "ILS"};
        final String[] symbols = new String[]{"$", "€", "₪"};
        final String[] names = new String[]{"US Dollar", "Euro", "Israeli Shekel"};

        final int[] selected = new int[]{0};

        if ("EUR".equalsIgnoreCase(currentCurrency)) {
            selected[0] = 1;
        } else if ("ILS".equalsIgnoreCase(currentCurrency)) {
            selected[0] = 2;
        }

        LinearLayout root = createDialogRoot();

        root.addView(createDialogTitle("Choose currency"));
        root.addView(createDialogSubtitle("Prices, portfolio, trading and balances will use this currency."));

        for (int i = 0; i < codes.length; i++) {
            final int index = i;

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(14), dp(12), dp(14), dp(12));
            row.setBackgroundResource(i == selected[0]
                    ? R.drawable.bg_currency_option_selected
                    : R.drawable.bg_currency_option_unselected);

            LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
            );
            rowLp.bottomMargin = dp(12);
            row.setLayoutParams(rowLp);

            TextView symbol = new TextView(this);
            symbol.setText(symbols[i]);
            symbol.setGravity(Gravity.CENTER);
            symbol.setTextSize(20);
            symbol.setTypeface(null, Typeface.BOLD);
            symbol.setTextColor(i == selected[0] ? Color.WHITE : 0xFFBFD0F7);
            symbol.setBackgroundResource(i == selected[0]
                    ? R.drawable.bg_currency_symbol_selected
                    : R.drawable.bg_currency_symbol_unselected);
            symbol.setLayoutParams(new LinearLayout.LayoutParams(dp(42), dp(42)));

            LinearLayout texts = new LinearLayout(this);
            texts.setOrientation(LinearLayout.VERTICAL);
            texts.setPadding(dp(14), 0, 0, 0);
            texts.setLayoutParams(new LinearLayout.LayoutParams(
                    0,
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    1f
            ));

            TextView code = new TextView(this);
            code.setText(codes[i]);
            code.setTextColor(Color.WHITE);
            code.setTextSize(16);
            code.setTypeface(null, Typeface.BOLD);

            TextView name = new TextView(this);
            name.setText(names[i]);
            name.setTextColor(0xFF97A9C9);
            name.setTextSize(13);

            texts.addView(code);
            texts.addView(name);

            TextView check = new TextView(this);
            check.setText("✓");
            check.setTextColor(0xFF9DBBFF);
            check.setTextSize(22);
            check.setTypeface(null, Typeface.BOLD);
            check.setVisibility(i == selected[0] ? View.VISIBLE : View.INVISIBLE);

            row.addView(symbol);
            row.addView(texts);
            row.addView(check);

            row.setOnClickListener(v -> {
                selected[0] = index;
                updateCurrencyDialogRows(root, selected[0]);
            });

            root.addView(row);
        }

        LinearLayout actions = createDialogActions();
        TextView cancel = createDialogCancelButton("Cancel");
        TextView save = createDialogSaveButton("Save");
        styleCurrencyDialogActions(actions, cancel, save);

        actions.addView(cancel);
        actions.addView(save);
        root.addView(actions);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(root)
                .create();

        makeDialogTransparent(dialog);

        cancel.setOnClickListener(v -> dialog.dismiss());

        save.setOnClickListener(v -> {
            currentCurrency = codes[selected[0]];

            AppSettingsManager.savePreferredCurrencyQuick(this, currentCurrency);
            ProfilePrefs.savePreferredCurrencyLocalOnly(this, currentCurrency);

            refreshUi();

            Toast.makeText(
                    this,
                    "Currency updated to " + AppSettingsManager.getCurrencyDisplay(currentCurrency),
                    Toast.LENGTH_SHORT
            ).show();

            dialog.dismiss();
        });

        dialog.show();
    }

    private void updateCurrencyDialogRows(@NonNull LinearLayout root, int selectedIndex) {
        int optionStartIndex = 2;

        for (int i = 0; i < 3; i++) {
            View child = root.getChildAt(optionStartIndex + i);

            if (!(child instanceof LinearLayout)) {
                continue;
            }

            LinearLayout row = (LinearLayout) child;
            boolean selected = i == selectedIndex;

            row.setBackgroundResource(selected
                    ? R.drawable.bg_currency_option_selected
                    : R.drawable.bg_currency_option_unselected);

            TextView symbol = (TextView) row.getChildAt(0);
            LinearLayout texts = (LinearLayout) row.getChildAt(1);
            TextView code = (TextView) texts.getChildAt(0);
            TextView name = (TextView) texts.getChildAt(1);
            TextView check = (TextView) row.getChildAt(2);

            symbol.setBackgroundResource(selected
                    ? R.drawable.bg_currency_symbol_selected
                    : R.drawable.bg_currency_symbol_unselected);
            symbol.setTextColor(selected ? Color.WHITE : 0xFFBFD0F7);

            code.setTextColor(Color.WHITE);
            name.setTextColor(0xFF97A9C9);
            check.setVisibility(selected ? View.VISIBLE : View.INVISIBLE);
        }
    }

    private void showAboutDialog() {
        String message =
                "YoavTrade is a modern finance and stock-tracking application built to help users monitor the market in a clean and practical way.\n\n" +
                        "The app combines stock discovery, watchlists, charts, trading screens, portfolio tracking, alerts, news and currency support in one place.\n\n" +
                        "Developed by Yoav.";

        showInfoDialog("YoavTrade", message);
    }

    private void showInfoDialog(String titleText, String messageText) {
        LinearLayout root = createDialogRoot();

        root.addView(createDialogTitle(titleText));
        root.addView(createDialogSubtitle(messageText));

        LinearLayout actions = createDialogActions();
        TextView close = createDialogSaveButton("Close");

        actions.addView(close);
        root.addView(actions);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(root)
                .create();

        makeDialogTransparent(dialog);

        close.setOnClickListener(v -> dialog.dismiss());
        dialog.show();
    }

    private void showLogoutDialog() {
        LinearLayout root = createDialogRoot();

        TextView title = createDialogTitle("Log out?");
        title.setGravity(Gravity.CENTER);

        TextView subtitle = createDialogSubtitle("Are you sure you want to log out?");
        subtitle.setGravity(Gravity.CENTER);

        root.addView(title);
        root.addView(subtitle);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.CENTER);
        actions.setPadding(0, dp(18), 0, 0);

        TextView cancel = createDialogCancelButton("Cancel");
        TextView logout = createLogoutButton("Log out");

        LinearLayout.LayoutParams cancelLp = new LinearLayout.LayoutParams(0, dp(48), 1f);
        cancelLp.rightMargin = dp(8);
        cancel.setLayoutParams(cancelLp);

        LinearLayout.LayoutParams logoutLp = new LinearLayout.LayoutParams(0, dp(48), 1f);
        logoutLp.leftMargin = dp(8);
        logout.setLayoutParams(logoutLp);

        actions.addView(cancel);
        actions.addView(logout);
        root.addView(actions);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(root)
                .create();

        makeDialogTransparent(dialog);

        cancel.setOnClickListener(v -> dialog.dismiss());

        logout.setOnClickListener(v -> {
            dialog.dismiss();
            FirebaseAuth.getInstance().signOut();

            Intent intent = new Intent(this, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });

        dialog.show();
    }

    private LinearLayout createDialogRoot() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(20), dp(22), dp(18));
        root.setBackgroundResource(R.drawable.bg_settings_dialog);
        return root;
    }

    private TextView createDialogTitle(String text) {
        TextView title = new TextView(this);
        title.setText(text);
        title.setTextColor(Color.WHITE);
        title.setTextSize(22);
        title.setTypeface(null, Typeface.BOLD);
        return title;
    }

    private TextView createDialogSubtitle(String text) {
        TextView subtitle = new TextView(this);
        subtitle.setText(text);
        subtitle.setTextColor(0xFF97A9C9);
        subtitle.setTextSize(14);
        subtitle.setLineSpacing(2f, 1.08f);
        subtitle.setPadding(0, dp(8), 0, dp(14));
        return subtitle;
    }

    private EditText createDialogInput(String hint, String value) {
        EditText input = new EditText(this);
        input.setHint(hint);
        input.setText(value);
        input.setTextColor(Color.WHITE);
        input.setHintTextColor(0xFF8EA0BC);
        input.setSingleLine(true);
        input.setBackgroundResource(R.drawable.bg_settings_input);
        input.setPadding(dp(14), 0, dp(14), 0);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(54)
        );
        lp.topMargin = dp(12);
        input.setLayoutParams(lp);

        return input;
    }

    private LinearLayout createDialogActions() {
        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.CENTER);
        actions.setPadding(0, dp(18), 0, 0);
        actions.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        ));
        return actions;
    }

    private TextView createDialogCancelButton(String text) {
        TextView button = new TextView(this);
        button.setText(text);
        button.setTextColor(0xFF97A9C9);
        button.setGravity(Gravity.CENTER);
        button.setTextSize(14);
        button.setTypeface(null, Typeface.BOLD);
        button.setPadding(dp(16), dp(10), dp(16), dp(10));
        button.setBackgroundResource(R.drawable.bg_settings_cancel_button);
        return button;
    }

    private TextView createDialogSaveButton(String text) {
        TextView button = new TextView(this);
        button.setText(text);
        button.setTextColor(Color.WHITE);
        button.setGravity(Gravity.CENTER);
        button.setTextSize(14);
        button.setTypeface(null, Typeface.BOLD);
        button.setPadding(dp(22), dp(10), dp(22), dp(10));
        button.setBackgroundResource(R.drawable.bg_pill_primary);
        return button;
    }

    private void styleCurrencyDialogActions(@NonNull LinearLayout actions,
                                            @NonNull TextView cancel,
                                            @NonNull TextView save) {
        actions.setGravity(Gravity.CENTER);
        actions.setPadding(0, dp(18), 0, 0);
        actions.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        ));

        LinearLayout.LayoutParams cancelParams = new LinearLayout.LayoutParams(
                0,
                dp(48),
                1f
        );
        cancelParams.rightMargin = dp(8);
        cancel.setLayoutParams(cancelParams);
        cancel.setMinWidth(0);
        cancel.setGravity(Gravity.CENTER);

        LinearLayout.LayoutParams saveParams = new LinearLayout.LayoutParams(
                0,
                dp(48),
                1f
        );
        saveParams.leftMargin = dp(8);
        save.setLayoutParams(saveParams);
        save.setMinWidth(0);
        save.setGravity(Gravity.CENTER);
    }

    private TextView createLogoutButton(String text) {
        TextView button = new TextView(this);
        button.setText(text);
        button.setTextColor(Color.WHITE);
        button.setGravity(Gravity.CENTER);
        button.setTextSize(14);
        button.setTypeface(null, Typeface.BOLD);
        button.setPadding(dp(16), dp(10), dp(16), dp(10));
        button.setBackgroundResource(R.drawable.bg_settings_logout_row);
        return button;
    }

    private void makeDialogTransparent(AlertDialog dialog) {
        dialog.setOnShowListener(d -> {
            Window window = dialog.getWindow();
            if (window != null) {
                window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            }
        });
    }

    private void syncCurrentProfilePhotoToFirebase() {
        FirebaseUser user = auth.getCurrentUser();

        if (user == null) {
            return;
        }

        String safePhoto = firstNonEmpty(currentPhotoBase64, "");

        Map<String, Object> patch = new HashMap<>();
        patch.put("profilePhotoBase64", safePhoto);
        patch.put("photoBase64", safePhoto);
        patch.put("profileImageBase64", safePhoto);
        patch.put("profilePhotoUpdatedAt", System.currentTimeMillis());

        db.collection("users")
                .document(user.getUid())
                .set(patch, SetOptions.merge())
                .addOnSuccessListener(unused -> {
                    AppSettingsManager.saveProfileLocal(this, currentName, currentEmail, safePhoto);
                    ProfilePrefs.saveProfile(this, currentName, currentEmail, safePhoto);
                    localProfilePhotoChangedInSession = false;
                    updateGlobalChatMessagesWithCurrentPhoto(user.getUid(), safePhoto);
                });
    }


    private void updateGlobalChatMessagesWithCurrentPhoto(@NonNull String uid, @NonNull String photoBase64) {
        updateGlobalChatMessagesProfile(uid, photoBase64, ProfilePrefs.isProfilePrivate(this));
    }

    private void updateGlobalChatMessagesProfile(@NonNull String uid, @NonNull String photoBase64, boolean isPrivate) {
        String cleanUid = uid.trim();
        String safePhoto = isPrivate ? "" : photoBase64.trim();

        if (cleanUid.isEmpty()) {
            return;
        }

        Map<String, Object> messagePatch = new HashMap<>();
        messagePatch.put("profilePhotoBase64", safePhoto);
        messagePatch.put("photoBase64", safePhoto);
        messagePatch.put("profileImageBase64", safePhoto);
        messagePatch.put("profilePrivate", isPrivate);
        messagePatch.put("privateProfile", isPrivate);
        messagePatch.put("isPrivate", isPrivate);
        messagePatch.put("privacy", isPrivate ? "private" : "public");
        messagePatch.put("profilePrivacy", isPrivate ? "private" : "public");
        messagePatch.put("privacyMode", isPrivate ? "private" : "public");
        messagePatch.put("profilePhotoUpdatedAt", System.currentTimeMillis());

        try {
            FirebaseDatabase.getInstance()
                    .getReference(CHAT_PATH)
                    .orderByChild("userId")
                    .equalTo(cleanUid)
                    .get()
                    .addOnSuccessListener(snapshot -> {
                        if (snapshot == null || !snapshot.exists()) {
                            return;
                        }

                        for (DataSnapshot messageSnapshot : snapshot.getChildren()) {
                            if (messageSnapshot == null || messageSnapshot.getRef() == null) {
                                continue;
                            }

                            messageSnapshot.getRef().updateChildren(messagePatch);
                        }
                    });
        } catch (Exception ignored) {
        }
    }

    private void saveProfileToFirebase() {
        FirebaseUser user = auth.getCurrentUser();

        if (user == null) {
            return;
        }

        String usernameLower = normalizeUsername(currentName);

        Map<String, Object> patch = new HashMap<>();
        patch.put("displayName", currentName);
        patch.put("fullName", currentName);
        patch.put("username", currentName);
        patch.put("usernameLower", usernameLower);
        patch.put("displayNameLower", usernameLower);
        patch.put("email", currentEmail);
        patch.put("profilePhotoBase64", currentPhotoBase64);
        patch.put("photoBase64", currentPhotoBase64);
        patch.put("profileImageBase64", currentPhotoBase64);
        patch.put("profilePhotoUpdatedAt", System.currentTimeMillis());
        boolean currentPrivate = ProfilePrefs.isProfilePrivate(this);
        patch.put("profilePrivate", currentPrivate);
        patch.put("privateProfile", currentPrivate);
        patch.put("isPrivate", currentPrivate);
        patch.put("privacy", currentPrivate ? "private" : "public");
        patch.put("profilePrivacy", currentPrivate ? "private" : "public");
        patch.put("privacyMode", currentPrivate ? "private" : "public");
        patch.put("dateOfBirth", currentBirthDate);
        patch.put("birthDate", currentBirthDate);

        db.collection("users")
                .document(user.getUid())
                .set(patch, SetOptions.merge());
    }

    private void saveProfilePrivateToFirebase(boolean isPrivate) {
        FirebaseUser user = auth.getCurrentUser();

        if (user == null) {
            Toast.makeText(this, "Please sign in again", Toast.LENGTH_SHORT).show();
            return;
        }

        Map<String, Object> patch = new HashMap<>();
        patch.put("profilePrivate", isPrivate);
        patch.put("privateProfile", isPrivate);
        patch.put("isPrivate", isPrivate);
        patch.put("privacy", isPrivate ? "private" : "public");
        patch.put("profilePrivacy", isPrivate ? "private" : "public");
        patch.put("privacyMode", isPrivate ? "private" : "public");

        db.collection("users")
                .document(user.getUid())
                .set(patch, SetOptions.merge())
                .addOnSuccessListener(unused -> {
                    updateGlobalChatMessagesProfile(user.getUid(), currentPhotoBase64, isPrivate);
                    Toast.makeText(
                            this,
                            isPrivate ? "Profile is now private" : "Profile is now public",
                            Toast.LENGTH_SHORT
                    ).show();
                })
                .addOnFailureListener(e -> Toast.makeText(
                        this,
                        "Could not update privacy: " + e.getMessage(),
                        Toast.LENGTH_LONG
                ).show());
    }


    private void openPrivacyDialog() {
        boolean currentPrivate = ProfilePrefs.isProfilePrivate(this);
        final boolean[] selectedPrivate = {currentPrivate};

        LinearLayout root = createDialogRoot();

        TextView title = createDialogTitle("Profile privacy");
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        TextView subtitle = createDialogSubtitle("Choose whether your profile photo is visible to others.");
        subtitle.setGravity(Gravity.CENTER);
        root.addView(subtitle);

        LinearLayout publicCard = createPrivacyOptionCard(
                "Public profile",
                "Your profile photo can appear in community features"
        );

        LinearLayout privateCard = createPrivacyOptionCard(
                "Private profile",
                "Your profile photo stays hidden and the default avatar is used"
        );

        LinearLayout.LayoutParams publicParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        publicParams.bottomMargin = dp(10);
        root.addView(publicCard, publicParams);

        root.addView(privateCard, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        ));

        View.OnClickListener selectPublic = v -> {
            selectedPrivate[0] = false;
            updatePrivacyOptionCard(publicCard, true);
            updatePrivacyOptionCard(privateCard, false);
        };

        View.OnClickListener selectPrivate = v -> {
            selectedPrivate[0] = true;
            updatePrivacyOptionCard(publicCard, false);
            updatePrivacyOptionCard(privateCard, true);
        };

        publicCard.setOnClickListener(selectPublic);
        privateCard.setOnClickListener(selectPrivate);

        if (currentPrivate) {
            selectPrivate.onClick(privateCard);
        } else {
            selectPublic.onClick(publicCard);
        }

        LinearLayout actions = createDialogActions();
        TextView cancel = createDialogCancelButton("Cancel");
        TextView save = createDialogSaveButton("Save");
        actions.addView(cancel);
        actions.addView(save);
        styleCurrencyDialogActions(actions, cancel, save);
        root.addView(actions);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(root)
                .create();

        makeDialogTransparent(dialog);

        cancel.setOnClickListener(v -> dialog.dismiss());
        save.setOnClickListener(v -> {
            applyProfilePrivacy(selectedPrivate[0], true);
            dialog.dismiss();
        });

        dialog.show();
    }



    private LinearLayout createPrivacyOptionCard(String titleText, String subtitleText) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(14), dp(14), dp(14), dp(14));

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);

        TextView title = new TextView(this);
        title.setTag("privacyTitle");
        title.setText(titleText);
        title.setTextColor(Color.WHITE);
        title.setTextSize(15);
        title.setTypeface(null, Typeface.BOLD);
        title.setIncludeFontPadding(false);

        TextView subtitle = new TextView(this);
        subtitle.setTag("privacySubtitle");
        subtitle.setText(subtitleText);
        subtitle.setTextColor(0xFF8EA0BC);
        subtitle.setTextSize(12);
        subtitle.setPadding(0, dp(5), 0, 0);
        subtitle.setIncludeFontPadding(false);

        texts.addView(title);
        texts.addView(subtitle);

        row.addView(texts, new LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.WRAP_CONTENT,
                1f
        ));

        TextView status = new TextView(this);
        status.setTag("privacyStatus");
        status.setTextSize(12);
        status.setTypeface(null, Typeface.BOLD);
        status.setPadding(dp(10), dp(6), dp(10), dp(6));
        status.setIncludeFontPadding(false);
        row.addView(status);

        updatePrivacyOptionCard(row, false);
        return row;
    }

    private void updatePrivacyOptionCard(LinearLayout row, boolean selected) {
        TextView title = row.findViewWithTag("privacyTitle");
        TextView subtitle = row.findViewWithTag("privacySubtitle");
        TextView status = row.findViewWithTag("privacyStatus");

        row.setBackground(createMoneyModeBackground(
                selected ? Color.rgb(17, 34, 66) : Color.rgb(10, 20, 38),
                selected ? Color.rgb(86, 120, 255) : Color.rgb(37, 57, 89)
        ));

        if (title != null) {
            title.setTextColor(Color.WHITE);
        }

        if (subtitle != null) {
            subtitle.setTextColor(selected ? Color.rgb(187, 203, 239) : Color.rgb(142, 160, 188));
        }

        if (status != null) {
            status.setText(selected ? "Selected" : "Choose");
            status.setTextColor(selected ? Color.WHITE : Color.rgb(146, 163, 198));
            status.setBackground(createMoneyModeBackground(
                    selected ? Color.rgb(58, 92, 255) : Color.rgb(18, 29, 49),
                    selected ? Color.rgb(123, 151, 255) : Color.rgb(49, 68, 101)
            ));
        }
    }

    private void applyProfilePrivacy(boolean isPrivate, boolean saveRemote) {
        ProfilePrefs.setProfilePrivate(this, isPrivate);

        if (switchPrivacy != null) {
            switchPrivacy.setOnCheckedChangeListener(null);
            switchPrivacy.setChecked(isPrivate);
            switchPrivacy.setOnCheckedChangeListener((buttonView, checked) ->
                    applyProfilePrivacy(checked, true)
            );
        }

        if (saveRemote) {
            saveProfilePrivateToFirebase(isPrivate);
        }
    }

    private boolean readProfilePrivateFromSnapshot(
            com.google.firebase.firestore.DocumentSnapshot snapshot,
            boolean fallback
    ) {
        if (snapshot == null || !snapshot.exists()) {
            return fallback;
        }

        Boolean profilePrivate = snapshot.getBoolean("profilePrivate");
        if (profilePrivate != null) {
            return profilePrivate;
        }

        Boolean privateProfile = snapshot.getBoolean("privateProfile");
        if (privateProfile != null) {
            return privateProfile;
        }

        Boolean isPrivate = snapshot.getBoolean("isPrivate");
        if (isPrivate != null) {
            return isPrivate;
        }

        String privacy = firstNonEmpty(
                snapshot.getString("privacy"),
                snapshot.getString("profilePrivacy"),
                snapshot.getString("privacyMode")
        );

        if (!privacy.isEmpty()) {
            String normalized = privacy.trim().toLowerCase(Locale.US);
            return normalized.equals("private") || normalized.equals("privacy_private");
        }

        return fallback;
    }

    private void saveBirthDateLocal(String birthDate) {
        getProfilePrefs()
                .edit()
                .putString(KEY_BIRTH_DATE, birthDate == null ? "" : birthDate)
                .apply();
    }

    private SharedPreferences getProfilePrefs() {
        return getSharedPreferences(PROFILE_PREFS, MODE_PRIVATE);
    }

    private double readDouble(Object value, double fallback) {
        if (value instanceof Number) {
            return ((Number) value).doubleValue();
        }

        if (value instanceof String) {
            try {
                return Double.parseDouble((String) value);
            } catch (Exception ignored) {
            }
        }

        return fallback;
    }

    private int dp(int value) {
        return Math.round(getResources().getDisplayMetrics().density * value);
    }

    private String firstNonEmpty(String... values) {
        if (values == null) {
            return "";
        }

        for (String value : values) {
            if (value != null && !value.trim().isEmpty()) {
                return value.trim();
            }
        }

        return "";
    }

    private interface DateSelectionCallback {
        void onDateSelected(String value);
    }
}