package com.example.yoavsproject;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity {

    private static final String PREFS_NAME = "yoav_app_start";
    private static final String KEY_ONBOARDING_SEEN = "onboarding_seen";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        AppSettingsManager.applySavedUi(this);

        super.onCreate(savedInstanceState);

        startPriceAlertsIfPossible();

        if (shouldShowOnboarding()) {
            openOnboarding();
            return;
        }

        openCorrectStartScreen();
    }

    private boolean shouldShowOnboarding() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        return !prefs.getBoolean(KEY_ONBOARDING_SEEN, false);
    }

    private void openOnboarding() {
        Intent intent = new Intent(MainActivity.this, OnboardingActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    private void openCorrectStartScreen() {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();

        if (user == null) {
            openAuthChoice();
            return;
        }

        user.reload().addOnCompleteListener(task -> {
            FirebaseUser reloadedUser = FirebaseAuth.getInstance().getCurrentUser();

            if (reloadedUser == null) {
                openAuthChoice();
                return;
            }

            if (reloadedUser.getEmail() != null && !reloadedUser.isEmailVerified()) {
                openEmailVerification();
                return;
            }

            openDashboard();
        });
    }

    private void openAuthChoice() {
        Intent intent = new Intent(MainActivity.this, AuthChoiceActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    private void openEmailVerification() {
        Intent intent = new Intent(MainActivity.this, EmailVerificationActivity.class);
        intent.putExtra(EmailVerificationActivity.EXTRA_AFTER_VERIFY_TO_WELCOME, false);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    private void openDashboard() {
        Intent intent = new Intent(MainActivity.this, TradingDashboardActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    private void startPriceAlertsIfPossible() {
        try {
            PriceAlertMonitor.start(this);
        } catch (Exception ignored) {
            
        }
    }
}
