
package com.example.yoavsproject;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;





public class AiAssistantActivity extends AppCompatActivity {

    private ImageView btnBackAi;
    private RecyclerView recyclerAiMessages;
    private EditText etAiInput;
    private ImageView btnSendAi;
    private TextView chipPortfolioNow;
    private TextView chipOpenArticles;
    private TextView chipRecommend;
    private TextView tvAiStatus;

    private final List<AiChatMessage> messages = new ArrayList<AiChatMessage>();
    private AiChatAdapter adapter;
    private int thinkingIndex = -1;
    private boolean waitingForAnswer = false;
    private String selectedArticleContext = "";

    @Override
    

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ai_assistant);

        btnBackAi = findViewById(R.id.btnBackAi);
        recyclerAiMessages = findViewById(R.id.recyclerAiMessages);
        etAiInput = findViewById(R.id.etAiInput);
        btnSendAi = findViewById(R.id.btnSendAi);
        chipPortfolioNow = findViewById(R.id.chipPortfolioNow);
        chipOpenArticles = findViewById(R.id.chipOpenArticles);
        chipRecommend = findViewById(R.id.chipRecommend);
        tvAiStatus = findViewById(R.id.tvAiStatus);

        adapter = new AiChatAdapter(messages, new AiChatAdapter.ArticleActionListener() {
            @Override
            public void onOpenArticle(AiChatMessage message) {
                openArticle(message.link);
            }
        });

        recyclerAiMessages.setLayoutManager(new LinearLayoutManager(this));
        recyclerAiMessages.setAdapter(adapter);

        if (btnBackAi != null) {
            btnBackAi.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    finish();
                }
            });
        }

        if (btnSendAi != null) {
            btnSendAi.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    submitPrompt();
                }
            });
        }


if (etAiInput != null) {
    etAiInput.setOnEditorActionListener((v, actionId, event) -> {
        boolean imeSend = actionId == EditorInfo.IME_ACTION_SEND || actionId == EditorInfo.IME_ACTION_DONE;
        boolean enterKey = event != null
                && event.getAction() == KeyEvent.ACTION_DOWN
                && event.getKeyCode() == KeyEvent.KEYCODE_ENTER;
        if (imeSend || enterKey) {
            submitPrompt();
            return true;
        }
        return false;
    });
}

        bindQuickChip(chipPortfolioNow, "How much money do I have and what should I notice in my portfolio?");
        bindOpenArticlesChip();
        bindQuickChip(chipRecommend, "Based on the latest articles and my portfolio, what should I watch?");

        addBotMessage("Ask me about your portfolio, a stock, or financial articles. You can ask for the latest article, an article about a specific company, or select an article with Open articles and then ask me about it.");
        setWaitingState(false);
    }

    @Override
    

    protected void onResume() {
        super.onResume();
    }
    

    private void bindQuickChip(TextView chip, final String prompt) {
        if (chip == null) return;

        chip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (waitingForAnswer) {
                    Toast.makeText(AiAssistantActivity.this, "Please wait for the current answer.", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (etAiInput != null) {
                    etAiInput.setText(prompt);
                    etAiInput.setSelection(etAiInput.getText().length());
                }
                submitPrompt();
            }
        });
    }
    private void bindOpenArticlesChip() {
        if (chipOpenArticles == null) return;

        chipOpenArticles.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showArticlesPicker();
            }
        });
    }

    private void showArticlesPicker() {
        if (waitingForAnswer) {
            Toast.makeText(this, "Please wait for the current answer.", Toast.LENGTH_SHORT).show();
            return;
        }

        List<NewsArticle> articles = App.getLatestDiscoverArticles();

        if (articles != null && !articles.isEmpty()) {
            showArticlesDialog(articles);
            return;
        }

        Toast.makeText(this, "Loading articles...", Toast.LENGTH_SHORT).show();

        NewsApiClient.fetchNewsAsync("stocks OR Apple OR market", "anytime", new NewsApiClient.NewsCallback() {
            @Override
            public void onSuccess(List<NewsArticle> articles) {
                if (articles != null && !articles.isEmpty()) {
                    App.setLatestDiscoverArticles(articles);
                    showArticlesDialog(App.getLatestDiscoverArticles());
                } else {
                    addBotMessage("I could not load articles right now. You can still ask me general questions about stocks, portfolio, or the market.");
                }
            }

            @Override
            public void onError(Exception e) {
                addBotMessage("I could not load articles right now. You can still ask me general questions about stocks, portfolio, or the market.");
            }
        });
    }

    private void showArticlesDialog(List<NewsArticle> articles) {
        if (articles == null || articles.isEmpty()) {
            addBotMessage("I could not find articles to show right now.");
            return;
        }

        ScrollView scrollView = new ScrollView(this);
        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        container.setPadding(dp(14), dp(10), dp(14), dp(10));
        scrollView.addView(container);

        int limit = Math.min(8, articles.size());

        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Open articles")
                .setView(scrollView)
                .setNegativeButton("Close", null)
                .create();

        for (int i = 0; i < limit; i++) {
            final NewsArticle article = articles.get(i);
            String title = safe(NewsArticleCompatUtil.getTitle(article)).trim();
            String source = safe(NewsArticleCompatUtil.getSource(article)).trim();

            if (title.isEmpty()) {
                continue;
            }

            TextView row = new TextView(this);
            row.setText(source.isEmpty() ? title : title + "\n" + source);
            row.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f);
            row.setTextColor(0xFF111827);
            row.setPadding(dp(10), dp(12), dp(10), dp(12));
            row.setBackgroundColor(0xFFFFFFFF);

            row.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                    attachArticleForNextQuestion(article);
                }
            });

            container.addView(row, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
            ));
        }

        dialog.show();
    }

    private void attachArticleForNextQuestion(NewsArticle article) {
        if (article == null) return;

        selectedArticleContext = buildSelectedArticleContext(article);
        showArticleCard(article);

        if (etAiInput != null) {
            etAiInput.setHint("Ask about the selected article...");
            etAiInput.requestFocus();
        }

        addBotMessage("Article attached. Write your question about it and I will answer using this article.");
    }

    private int dp(int value) {
        return (int) TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP,
                value,
                getResources().getDisplayMetrics()
        );
    }
    

    private void setWaitingState(boolean waiting) {
        waitingForAnswer = waiting;

        if (etAiInput != null) {
            etAiInput.setEnabled(!waiting);
            etAiInput.setHint(waiting ? "Please wait..." : "Ask the AI assistant...");
        }

        if (btnSendAi != null) {
            btnSendAi.setEnabled(!waiting);
            btnSendAi.setAlpha(waiting ? 0.45f : 1f);
        }

        if (tvAiStatus != null) {
            if (waiting) {
                tvAiStatus.setVisibility(View.VISIBLE);
                tvAiStatus.setText("Answering...");
            } else {
                tvAiStatus.setVisibility(View.GONE);
                tvAiStatus.setText("");
            }
        }
    }
private boolean isArticleRequest(String question) {
    if (question == null) return false;
    String q = question.toLowerCase(Locale.US);

    return q.contains("recent article")
            || q.contains("latest article")
            || q.contains("show me the article")
            || q.contains("open the article")
            || q.contains("summarize the article")
            || q.contains("article about")
            || q.contains("headline")
            || q.contains("news about")
            || q.contains("latest news")
            || q.contains("recent news")
            || q.contains("article")
            || q.contains("articles")
            || q.contains("news")
            || q.contains("כתבה")
            || q.contains("כתבות")
            || q.contains("חדשות")
            || q.contains("סכם")
            || q.contains("סיכום")
            || q.contains("אחרונה")
            || q.contains("אחרון");
}
    


    private void submitPrompt() {
        if (waitingForAnswer) {
            Toast.makeText(this, "Please wait for the current answer.", Toast.LENGTH_SHORT).show();
            return;
        }

        final String question = etAiInput == null || etAiInput.getText() == null
                ? ""
                : etAiInput.getText().toString().trim();

        if (TextUtils.isEmpty(question)) return;

        if (etAiInput != null) etAiInput.setText("");
        addUserMessage(question);

        if (isArticleRequest(question)) {
            submitArticlePrompt(question);
            return;
        }

        submitPromptWithExtraContext(question, selectedArticleContext);
        selectedArticleContext = "";
    }


    private void submitArticlePrompt(final String question) {
        String attachedContext = selectedArticleContext == null ? "" : selectedArticleContext.trim();
        selectedArticleContext = "";

        if (!attachedContext.isEmpty()) {
            submitPromptWithExtraContext(question, attachedContext);
            return;
        }

        List<NewsArticle> cachedArticles = App.getLatestDiscoverArticles();
        NewsArticle matched = findBestMatchingArticle(question, cachedArticles);

        if (matched != null) {
            showArticleCard(matched);
            submitPromptWithExtraContext(question, buildSelectedArticleContext(matched));
            return;
        }

        addThinkingMessage();
        setWaitingState(true);

        String query = buildNewsQuery(question);
        if (query.isEmpty()) query = "stocks market";

        NewsApiClient.fetchNewsAsync(query, "anytime", new NewsApiClient.NewsCallback() {
            @Override
            public void onSuccess(List<NewsArticle> articles) {
                removeThinkingMessage();
                setWaitingState(false);

                if (articles != null && !articles.isEmpty()) {
                    App.setLatestDiscoverArticles(articles);
                    NewsArticle best = findBestMatchingArticle(question, articles);
                    if (best == null) best = articles.get(0);
                    showArticleCard(best);
                    submitPromptWithExtraContext(question, buildSelectedArticleContext(best));
                } else {
                    submitPromptWithExtraContext(question, "No recent article was available from the news API for this exact request. Answer generally and explain that no specific article was found.");
                }
            }

            @Override
            public void onError(Exception e) {
                removeThinkingMessage();
                setWaitingState(false);
                submitPromptWithExtraContext(question, "The news API was not available for this request. Answer generally and do not claim that you opened a specific article.");
            }
        });
    }

    private void submitPromptWithExtraContext(final String question, final String extraContext) {
        addThinkingMessage();
        setWaitingState(true);

        StockAiContextBuilder.build(new StockAiContextBuilder.Callback() {
            @Override
            public void onReady(final String context) {
                final String mergedContext = mergeContext(context, extraContext);

                GeminiStockAssistantClient.ask(question, mergedContext, new GeminiStockAssistantClient.Callback() {
                    @Override
                    public void onSuccess(String text) {
                        String finalText = text == null ? "" : text.trim();
                        if (finalText.isEmpty()) finalText = LocalAiFallback.answer(question, mergedContext);
                        removeThinkingAndAddAnswer(finalText);
                        setWaitingState(false);
                    }

                    @Override
                    public void onError(Exception e) {
                        removeThinkingAndAddAnswer(LocalAiFallback.answer(question, mergedContext));
                        setWaitingState(false);
                    }
                });
            }

            @Override
            public void onError(Exception e) {
                String mergedContext = mergeContext(null, extraContext);
                removeThinkingAndAddAnswer(LocalAiFallback.answer(question, mergedContext));
                setWaitingState(false);
            }
        });
    }

    private String mergeContext(String context, String extraContext) {
        String base = context == null ? "" : context.trim();
        String extra = extraContext == null ? "" : extraContext.trim();

        if (extra.isEmpty()) {
            return base;
        }

        if (base.isEmpty()) {
            return extra;
        }

        return base + "\n\n" + extra;
    }

    private void askAboutArticle(NewsArticle article) {
        if (waitingForAnswer) {
            Toast.makeText(this, "Please wait for the current answer.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (article == null) {
            addBotMessage("No article is available for discussion right now.");
            return;
        }

        String title = safe(NewsArticleCompatUtil.getTitle(article)).trim();
        if (title.isEmpty()) title = "this article";

        String prompt = "Analyze this article for me: " + title;
        selectedArticleContext = buildSelectedArticleContext(article);

        if (etAiInput != null) etAiInput.setText("");
        addUserMessage(prompt);
        submitPromptWithExtraContext(prompt, selectedArticleContext);
        selectedArticleContext = "";
    }

    private String buildSelectedArticleContext(NewsArticle article) {
        if (article == null) return "";

        String title = safe(NewsArticleCompatUtil.getTitle(article));
        String source = safe(NewsArticleCompatUtil.getSource(article));
        String body = safe(NewsArticleCompatUtil.getBody(article));
        String link = safe(NewsArticleCompatUtil.getLink(article));

        if (body.length() > 1200) body = body.substring(0, 1200) + "...";

        StringBuilder sb = new StringBuilder();
        sb.append("SELECTED ARTICLE FOR THIS QUESTION:\n");
        if (!title.isEmpty()) sb.append("Title: ").append(title).append("\n");
        if (!source.isEmpty()) sb.append("Source: ").append(source).append("\n");
        if (!body.isEmpty()) sb.append("Content/Snippet: ").append(body).append("\n");
        if (!link.isEmpty()) sb.append("Link available: yes\n");
        sb.append("Instruction: The user wants to discuss this article. Summarize it, explain why it matters, connect it to stocks or portfolio context when relevant, and avoid making unsupported investment promises.");
        return sb.toString();
    }

    

    private void handleArticleQuestion(String question) {
        List<NewsArticle> list = App.getLatestDiscoverArticles();
        if (list == null || list.isEmpty()) {
            addBotMessage("I could not load articles right now. You can still ask me general questions about stocks, portfolio, or the market.");
            return;
        }

        NewsArticle best = findBestMatchingArticle(question, list);
        if (best == null) best = list.get(0);
        showArticleCard(best);
    }

    private NewsArticle findBestMatchingArticle(String question, List<NewsArticle> articles) {
        if (articles == null || articles.isEmpty()) return null;

        String query = buildNewsQuery(question);
        if (query.isEmpty()) return articles.get(0);

        String[] tokens = query.split("\\s+");
        int bestScore = -1;
        NewsArticle best = null;

        for (int i = 0; i < articles.size(); i++) {
            NewsArticle article = articles.get(i);
            if (article == null) continue;

            String title = safe(NewsArticleCompatUtil.getTitle(article)).toLowerCase(Locale.US);
            String source = safe(NewsArticleCompatUtil.getSource(article)).toLowerCase(Locale.US);
            String body = safe(NewsArticleCompatUtil.getBody(article)).toLowerCase(Locale.US);
            String all = title + " " + source + " " + body;

            int score = 0;
            for (int j = 0; j < tokens.length; j++) {
                String token = tokens[j];
                if (token == null || token.trim().isEmpty()) continue;
                if (all.contains(token)) score += 2;
                if (title.contains(token)) score += 3;
            }

            if (score > bestScore) {
                bestScore = score;
                best = article;
            }
        }

        return bestScore > 0 ? best : articles.get(0);
    }

    private String buildNewsQuery(String question) {
        if (question == null) return "";

        String q = question.toLowerCase(Locale.US).trim();
        if (q.isEmpty()) return "";

        String[] stop = new String[] {
                "hey","hi","hello","can","could","would","please","give","show","send","find","me",
                "an","a","the","that","related","about","to","for","of","on","and","article","articles",
                "news","latest","recent","right","now","is","are","do","you","with","from","stock","stocks"
        };

        ArrayList<String> filtered = new ArrayList<String>();
        String[] parts = q.split("\\s+");

        for (int i = 0; i < parts.length; i++) {
            String clean = parts[i].replaceAll("[^a-z0-9]", "").trim();
            if (clean.isEmpty()) continue;

            boolean isStop = false;
            for (int j = 0; j < stop.length; j++) {
                if (stop[j].equals(clean)) {
                    isStop = true;
                    break;
                }
            }

            if (!isStop) filtered.add(clean);
        }

        if (filtered.isEmpty()) return "";

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < filtered.size(); i++) {
            if (i > 0) sb.append(' ');
            sb.append(filtered.get(i));
        }

        return sb.toString();
    }
    

    private void showArticleCard(NewsArticle article) {
        if (article == null) {
            addBotMessage("No article available.");
            return;
        }

        String title = NewsArticleCompatUtil.getTitle(article);
        String source = NewsArticleCompatUtil.getSource(article);
        String body = NewsArticleCompatUtil.getBody(article);
        String imageUrl = NewsArticleCompatUtil.getImageUrl(article);
        String link = NewsArticleCompatUtil.getLink(article);

        if (body == null || body.trim().isEmpty()) {
            body = "Open the article to read more.";
        }

        messages.add(AiChatMessage.article(
                title == null ? "Recent article" : title,
                source == null ? "" : source,
                body,
                imageUrl == null ? "" : imageUrl,
                link == null ? "" : link
        ));
        adapter.notifyItemInserted(messages.size() - 1);
        recyclerAiMessages.scrollToPosition(messages.size() - 1);
    }

    private void openArticle(String link) {
        if (link == null || link.trim().isEmpty()) {
            Toast.makeText(this, "No article link available.", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(link)));
        } catch (Exception e) {
            Toast.makeText(this, "Failed to open article.", Toast.LENGTH_SHORT).show();
        }
    }

    private void addUserMessage(String text) {
        messages.add(AiChatMessage.user(text));
        adapter.notifyItemInserted(messages.size() - 1);
        recyclerAiMessages.scrollToPosition(messages.size() - 1);
    }

    private void addBotMessage(String text) {
        messages.add(AiChatMessage.ai(text));
        adapter.notifyItemInserted(messages.size() - 1);
        recyclerAiMessages.scrollToPosition(messages.size() - 1);
    }

    private void addThinkingMessage() {
        thinkingIndex = messages.size();
        messages.add(AiChatMessage.thinking());
        adapter.notifyItemInserted(thinkingIndex);
        recyclerAiMessages.scrollToPosition(messages.size() - 1);
    }


    private void removeThinkingMessage() {
        if (thinkingIndex >= 0 && thinkingIndex < messages.size()) {
            messages.remove(thinkingIndex);
            adapter.notifyItemRemoved(thinkingIndex);
            thinkingIndex = -1;
        }
    }

    private void removeThinkingAndAddAnswer(String text) {
        if (thinkingIndex >= 0 && thinkingIndex < messages.size()) {
            messages.remove(thinkingIndex);
            adapter.notifyItemRemoved(thinkingIndex);
            thinkingIndex = -1;
        }
        addBotMessage(text);
    }

    private String safe(String s) {
        return s == null ? "" : s;
    }
}
