package com.example.yoavsproject;

import android.app.Activity;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;

import androidx.core.view.ViewCompat;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public final class NavBarUtil {

    private static final int COLOR_SELECTED = Color.WHITE;
    private static final int COLOR_UNSELECTED = 0xFF8EA0BC;

    private static final int NAV_HEIGHT_DP = 70;
    private static final int NAV_SIDE_MARGIN_DP = 20;
    private static final int NAV_BOTTOM_MARGIN_DP = 18;
    private static final int NAV_ICON_SIZE_DP = 25;

    private NavBarUtil() {
    }

    public static void setup(Activity activity) {
        if (activity == null) {
            return;
        }

        int bottomNavId = activity.getResources().getIdentifier(
                "bottomNav",
                "id",
                activity.getPackageName()
        );

        if (bottomNavId == 0) {
            return;
        }

        View view = activity.findViewById(bottomNavId);

        if (view instanceof BottomNavigationView) {
            setup(activity, (BottomNavigationView) view, getSelectedId(activity));
        }
    }

    public static void setup(Activity activity, int selectedItemId) {
        if (activity == null) {
            return;
        }

        int bottomNavId = activity.getResources().getIdentifier(
                "bottomNav",
                "id",
                activity.getPackageName()
        );

        if (bottomNavId == 0) {
            return;
        }

        View view = activity.findViewById(bottomNavId);

        if (view instanceof BottomNavigationView) {
            setup(activity, (BottomNavigationView) view, selectedItemId);
        }
    }

    public static void setup(Activity activity, BottomNavigationView bottomNav) {
        setup(activity, bottomNav, getSelectedId(activity));
    }

    public static void setup(Activity activity, BottomNavigationView bottomNav, int selectedItemId) {
        if (activity == null || bottomNav == null) {
            return;
        }

        stabilizeBottomNavLayout(activity, bottomNav);
        styleBottomNav(activity, bottomNav);

        bottomNav.setOnItemSelectedListener(null);

        if (selectedItemId != 0) {
            try {
                bottomNav.setSelectedItemId(selectedItemId);
            } catch (Exception ignored) {
            }
        } else {
            clearSelection(bottomNav);
        }

        bottomNav.setOnItemSelectedListener(item -> {
            Class<?> target = getTargetActivity(item.getItemId());

            if (target == null) {
                return false;
            }

            if (activity.getClass().equals(target)) {
                return true;
            }

            Intent intent = new Intent(activity, target);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
            intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);

            activity.startActivity(intent);
            activity.overridePendingTransition(0, 0);
            activity.finish();
            activity.overridePendingTransition(0, 0);

            return true;
        });
    }

    private static Class<?> getTargetActivity(int itemId) {
        if (itemId == R.id.nav_home) {
            return TradingDashboardActivity.class;
        }

        if (itemId == R.id.nav_market) {
            return MarketsActivity.class;
        }

        if (itemId == R.id.nav_portfolio) {
            return SimplePortfolioActivity.class;
        }

        if (itemId == R.id.nav_discover) {
            return DiscoverActivity.class;
        }

        if (itemId == R.id.nav_settings) {
            return SettingsActivity.class;
        }

        return null;
    }

    private static int getSelectedId(Activity activity) {
        if (activity instanceof TradingDashboardActivity) {
            return R.id.nav_home;
        }

        if (activity instanceof MarketsActivity) {
            return R.id.nav_market;
        }

        if (activity instanceof SimplePortfolioActivity) {
            return R.id.nav_portfolio;
        }

        if (activity instanceof DiscoverActivity) {
            return R.id.nav_discover;
        }

        if (activity instanceof SettingsActivity) {
            return R.id.nav_settings;
        }

        return 0;
    }

    private static void stabilizeBottomNavLayout(Activity activity, BottomNavigationView bottomNav) {
        int height = dp(activity, NAV_HEIGHT_DP);
        int side = dp(activity, NAV_SIDE_MARGIN_DP);
        int bottom = dp(activity, NAV_BOTTOM_MARGIN_DP);

        ViewGroup.LayoutParams params = bottomNav.getLayoutParams();

        if (params != null) {
            params.width = ViewGroup.LayoutParams.MATCH_PARENT;
            params.height = height;

            if (params instanceof ViewGroup.MarginLayoutParams) {
                ViewGroup.MarginLayoutParams marginParams = (ViewGroup.MarginLayoutParams) params;
                marginParams.setMarginStart(side);
                marginParams.setMarginEnd(side);
                marginParams.topMargin = 0;
                marginParams.bottomMargin = bottom;
                bottomNav.setLayoutParams(marginParams);
            } else {
                bottomNav.setLayoutParams(params);
            }
        }

        bottomNav.setMinimumHeight(height);
        bottomNav.setPadding(0, 0, 0, 0);
        bottomNav.setClipToOutline(true);
        bottomNav.setTranslationX(0f);
        bottomNav.setTranslationY(0f);
        bottomNav.setScaleX(1f);
        bottomNav.setScaleY(1f);
        bottomNav.clearAnimation();
    }

    private static void styleBottomNav(Activity activity, BottomNavigationView bottomNav) {
        ViewCompat.setBackgroundTintList(bottomNav, null);

        try {
            bottomNav.setBackgroundResource(R.drawable.bg_bottom_nav);
        } catch (Exception ignored) {
            bottomNav.setBackgroundColor(0xFF09111F);
        }

        bottomNav.setElevation(0f);

        bottomNav.setLabelVisibilityMode(BottomNavigationView.LABEL_VISIBILITY_UNLABELED);
        bottomNav.setItemHorizontalTranslationEnabled(false);
        bottomNav.setItemIconSize(dp(activity, NAV_ICON_SIZE_DP));
        bottomNav.setItemRippleColor(ColorStateList.valueOf(Color.TRANSPARENT));

        disableActiveIndicatorIfSupported(bottomNav);

        ColorStateList colors = new ColorStateList(
                new int[][]{
                        new int[]{android.R.attr.state_checked},
                        new int[]{-android.R.attr.state_checked}
                },
                new int[]{
                        COLOR_SELECTED,
                        COLOR_UNSELECTED
                }
        );

        bottomNav.setItemIconTintList(colors);
        bottomNav.setItemTextColor(colors);
    }

    private static void disableActiveIndicatorIfSupported(BottomNavigationView bottomNav) {
        try {
            bottomNav.getClass()
                    .getMethod("setItemActiveIndicatorEnabled", boolean.class)
                    .invoke(bottomNav, false);
        } catch (Exception ignored) {
        }
    }

    private static void clearSelection(BottomNavigationView bottomNav) {
        if (bottomNav.getMenu() == null) {
            return;
        }

        for (int i = 0; i < bottomNav.getMenu().size(); i++) {
            bottomNav.getMenu().getItem(i).setChecked(false);
        }
    }

    private static int dp(Activity activity, int value) {
        return Math.round(TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP,
                value,
                activity.getResources().getDisplayMetrics()
        ));
    }
}
