package com.example.yoavsproject;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;

public final class NotificationHelper {

    private static final String CHANNEL_ALERTS = "yoavtrade_alerts";

    private NotificationHelper() {
    }

    public static void showPriceAlert(
            @NonNull Context context,
            @NonNull String symbol,
            double currentPrice,
            double targetPrice,
            @NonNull String mode
    ) {
        createChannels(context);

        Intent intent = new Intent(context, StockGraphActivity.class);
        intent.putExtra("symbol", symbol);
        intent.putExtra("stockSymbol", symbol);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);

        PendingIntent pendingIntent = PendingIntent.getActivity(
                context,
                symbol.hashCode(),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        String title = symbol + " price alert";
        String direction = PriceAlert.MODE_ABOVE.equals(mode) ? "reached above" : "dropped below";

        String text = symbol + " " + direction +
                " your target. Current: $" +
                String.format(java.util.Locale.US, "%,.2f", currentPrice) +
                " Target: $" +
                String.format(java.util.Locale.US, "%,.2f", targetPrice);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ALERTS)
                .setSmallIcon(R.drawable.logo)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(text))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent);

        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        if (manager != null) {
            manager.notify(("PRICE_" + symbol + targetPrice + mode).hashCode(), builder.build());
        }
    }

    public static void showNewsAlert(
            @NonNull Context context,
            @NonNull String title,
            @NonNull String text
    ) {
        createChannels(context);

        Intent intent = new Intent(context, DiscoverActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);

        PendingIntent pendingIntent = PendingIntent.getActivity(
                context,
                title.hashCode(),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ALERTS)
                .setSmallIcon(R.drawable.logo)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(text))
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent);

        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        if (manager != null) {
            manager.notify(("NEWS_" + title).hashCode(), builder.build());
        }
    }

    private static void createChannels(@NonNull Context context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            return;
        }

        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        if (manager == null) {
            return;
        }

        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ALERTS,
                "YoavTrade Alerts",
                NotificationManager.IMPORTANCE_HIGH
        );

        channel.setDescription("Price alerts and market news alerts");

        manager.createNotificationChannel(channel);
    }
}