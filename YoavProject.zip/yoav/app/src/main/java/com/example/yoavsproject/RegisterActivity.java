package com.example.yoavsproject;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.NumberPicker;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class RegisterActivity extends AppCompatActivity {

    private static final String PROFILE_PREFS = "yoav_profile_prefs";
    private static final String KEY_BIRTH_DATE = "profile_birth_date";
    private static final double STARTER_BALANCE = 10000.00;

    public static final String EXTRA_PREFILL_USERNAME = "extra_prefill_username";
    public static final String EXTRA_PREFILL_BIRTH_DATE = "extra_prefill_birth_date";

    private EditText etRegisterName;
    private EditText etRegisterEmail;
    private EditText etRegisterPassword;
    private EditText etRegisterConfirmPassword;
    private EditText etRegisterDateOfBirth;

    private Button btnRegister;
    private TextView tvGoToLogin;

    private FirebaseAuth auth;
    private FirebaseFirestore db;

    private final String[] monthNames = new String[]{
            "January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"
    };

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        AppSettingsManager.applySavedUi(this);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        auth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        bindViews();
        applyPrefillFromIntent();
        setupClicks();
    }

    private void bindViews() {
        etRegisterName = findViewById(R.id.etRegisterName);
        etRegisterEmail = findViewById(R.id.etRegisterEmail);
        etRegisterPassword = findViewById(R.id.etRegisterPassword);
        etRegisterConfirmPassword = findViewById(R.id.etRegisterConfirmPassword);
        etRegisterDateOfBirth = findViewById(R.id.etRegisterDateOfBirth);

        btnRegister = findViewById(R.id.btnRegister);
        tvGoToLogin = findViewById(R.id.tvGoToLogin);
    }


    private void applyPrefillFromIntent() {
        Intent intent = getIntent();

        if (intent == null) {
            return;
        }

        String prefillUsername = intent.getStringExtra(EXTRA_PREFILL_USERNAME);
        String prefillBirthDate = intent.getStringExtra(EXTRA_PREFILL_BIRTH_DATE);

        if (etRegisterName != null
                && etRegisterName.getText() != null
                && etRegisterName.getText().toString().trim().isEmpty()
                && prefillUsername != null
                && !prefillUsername.trim().isEmpty()) {
            etRegisterName.setText(prefillUsername.trim());
            etRegisterName.setSelection(etRegisterName.getText().length());
        }

        if (etRegisterDateOfBirth != null
                && etRegisterDateOfBirth.getText() != null
                && etRegisterDateOfBirth.getText().toString().trim().isEmpty()
                && prefillBirthDate != null
                && !prefillBirthDate.trim().isEmpty()) {
            etRegisterDateOfBirth.setText(prefillBirthDate.trim());
        }

        if (etRegisterEmail != null) {
            etRegisterEmail.setText("");
        }

        if (etRegisterPassword != null) {
            etRegisterPassword.setText("");
        }

        if (etRegisterConfirmPassword != null) {
            etRegisterConfirmPassword.setText("");
        }
    }

    private void correctEmailField(EditText editText) {
        if (editText == null || editText.getText() == null) {
            return;
        }

        String original = editText.getText().toString();
        String corrected = EmailCorrectionUtil.correct(original);

        if (EmailCorrectionUtil.wasCorrected(original, corrected)) {
            editText.setText(corrected);
            editText.setSelection(editText.getText().length());
        }
    }

    private void setupClicks() {
        setupPasswordToggle(etRegisterPassword, R.drawable.ic_register_lock);
        setupPasswordToggle(etRegisterConfirmPassword, R.drawable.ic_register_confirm_password);

        if (etRegisterEmail != null) {
            etRegisterEmail.setOnFocusChangeListener((v, hasFocus) -> {
                if (!hasFocus) {
                    correctEmailField(etRegisterEmail);
                }
            });
        }

        if (etRegisterDateOfBirth != null) {
            etRegisterDateOfBirth.setFocusable(false);
            etRegisterDateOfBirth.setClickable(true);
            etRegisterDateOfBirth.setCursorVisible(false);
            etRegisterDateOfBirth.setOnClickListener(v -> showBirthDatePicker());
        }

        if (btnRegister != null) {
            btnRegister.setOnClickListener(v -> attemptRegister());
        }

        if (tvGoToLogin != null) {
            tvGoToLogin.setOnClickListener(v -> openLoginScreen());
        }
    }

    private void openLoginScreen() {
        Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
        finish();
    }

    private void attemptRegister() {
        String username = safeText(etRegisterName);
        String originalEmail = safeText(etRegisterEmail);
        String email = EmailCorrectionUtil.correct(originalEmail);

        if (etRegisterEmail != null && EmailCorrectionUtil.wasCorrected(originalEmail, email)) {
            etRegisterEmail.setText(email);
            etRegisterEmail.setSelection(etRegisterEmail.getText().length());
        }
        String password = safeText(etRegisterPassword);
        String confirmPassword = safeText(etRegisterConfirmPassword);
        String birthDate = safeText(etRegisterDateOfBirth);

        if (TextUtils.isEmpty(username)) {
            etRegisterName.setError("Enter username");
            etRegisterName.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(email) || !Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            etRegisterEmail.setError("Enter valid email");
            etRegisterEmail.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(password) || password.length() < 6) {
            etRegisterPassword.setError("Password must be at least 6 characters");
            etRegisterPassword.requestFocus();
            return;
        }

        if (!password.equals(confirmPassword)) {
            etRegisterConfirmPassword.setError("Passwords do not match");
            etRegisterConfirmPassword.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(birthDate)) {
            etRegisterDateOfBirth.setError("Choose date of birth");
            return;
        }

        btnRegister.setEnabled(false);

        checkUsernameAvailableBeforeCreate(username, email, password, birthDate);
    }

    private void checkUsernameAvailableBeforeCreate(
            String username,
            String email,
            String password,
            String birthDate
    ) {
        String normalizedUsername = normalizeUsername(username);

        if (!isValidUsernameKey(normalizedUsername)) {
            btnRegister.setEnabled(true);
            etRegisterName.setError("Use only letters, numbers, dot, underscore or dash");
            etRegisterName.requestFocus();
            return;
        }

        createFirebaseUser(username, normalizedUsername, email, password, birthDate);
    }

    private void createFirebaseUser(
            String username,
            String normalizedUsername,
            String email,
            String password,
            String birthDate
    ) {
        auth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(task -> {
                    if (!task.isSuccessful()) {
                        btnRegister.setEnabled(true);

                        String message = task.getException() != null
                                ? task.getException().getMessage()
                                : "Registration failed";

                        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
                        return;
                    }

                    FirebaseUser user = auth.getCurrentUser();

                    if (user == null) {
                        btnRegister.setEnabled(true);
                        Toast.makeText(this, "Registration failed", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    user.updateProfile(
                            new UserProfileChangeRequest.Builder()
                                    .setDisplayName(username)
                                    .build()
                    );

                    Map<String, Object> userMap = createUserMap(
                            user,
                            username,
                            normalizedUsername,
                            email,
                            birthDate
                    );

                    reserveUsernameAndCreateUserDoc(
                            user,
                            username,
                            normalizedUsername,
                            email,
                            birthDate,
                            userMap
                    );
                });
    }

    private Map<String, Object> createUserMap(
            FirebaseUser user,
            String username,
            String normalizedUsername,
            String email,
            String birthDate
    ) {
        Map<String, Object> userMap = new HashMap<>();

        userMap.put("uid", user.getUid());
        userMap.put("displayName", username);
        userMap.put("fullName", username);
        userMap.put("username", username);
        userMap.put("usernameLower", normalizedUsername);
        userMap.put("displayNameLower", normalizedUsername);
        userMap.put("email", email);
        userMap.put("dateOfBirth", birthDate);
        userMap.put("birthDate", birthDate);
        userMap.put("preferredCurrency", "USD");
        userMap.put("profilePhotoBase64", "");
        userMap.put("photoBase64", "");
        userMap.put("profileImageBase64", "");

        
        
        userMap.put("profilePrivate", false);
        userMap.put("privateProfile", false);
        userMap.put("isPrivate", false);
        userMap.put("privacy", "public");
        userMap.put("profilePrivacy", "public");
        userMap.put("privacyMode", "public");

        userMap.put("priceAlertsEnabled", true);
        userMap.put("newsAlertsEnabled", true);

        userMap.put("cashBalance", STARTER_BALANCE);
        userMap.put("availableCash", STARTER_BALANCE);
        userMap.put("availableBalance", STARTER_BALANCE);
        userMap.put("buyingPower", STARTER_BALANCE);
        userMap.put("balance", STARTER_BALANCE);
        userMap.put("starterBonusReceived", true);
        userMap.put("starterBonusAmount", STARTER_BALANCE);

        userMap.put("emailVerified", false);
        userMap.put("welcomeEmailQueued", true);
        userMap.put("createdAt", System.currentTimeMillis());

        return userMap;
    }

    private void reserveUsernameAndCreateUserDoc(
            FirebaseUser user,
            String username,
            String normalizedUsername,
            String email,
            String birthDate,
            Map<String, Object> userMap
    ) {
        DocumentReference usernameRef = db.collection("usernames").document(normalizedUsername);
        DocumentReference userRef = db.collection("users").document(user.getUid());

        Map<String, Object> usernameMap = new HashMap<>();
        usernameMap.put("uid", user.getUid());
        usernameMap.put("username", username);
        usernameMap.put("usernameLower", normalizedUsername);
        usernameMap.put("email", email);
        usernameMap.put("createdAt", System.currentTimeMillis());

        db.runTransaction(transaction -> {
                    DocumentSnapshot usernameSnapshot = transaction.get(usernameRef);

                    if (usernameSnapshot.exists()) {
                        String existingUid = usernameSnapshot.getString("uid");

                        if (existingUid == null || !existingUid.equals(user.getUid())) {
                            throw new FirebaseFirestoreException(
                                    "Username already exists",
                                    FirebaseFirestoreException.Code.ABORTED
                            );
                        }
                    }

                    transaction.set(usernameRef, usernameMap);
                    transaction.set(userRef, userMap);

                    return null;
                })
                .addOnSuccessListener(unused -> {
                    AppSettingsManager.saveProfileLocal(this, username, email, "");
                    ProfilePrefs.saveProfile(this, username, email, "");
                    ProfilePrefs.setProfilePrivate(this, false);
                    saveBirthDateLocal(birthDate);

                    user.sendEmailVerification().addOnCompleteListener(emailTask -> {
                        AppEmailSender.sendWelcomeEmail(email, username, STARTER_BALANCE);

                        Intent intent = new Intent(RegisterActivity.this, EmailVerificationActivity.class);
                        intent.putExtra(EmailVerificationActivity.EXTRA_AFTER_VERIFY_TO_WELCOME, true);
                        intent.putExtra("extra_balance", STARTER_BALANCE);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);
                        finish();

                        if (!emailTask.isSuccessful()) {
                            String message = emailTask.getException() != null
                                    ? emailTask.getException().getMessage()
                                    : "Could not send verification email. Press Resend email.";

                            Toast.makeText(this, message, Toast.LENGTH_LONG).show();
                        }
                    });
                })
                .addOnFailureListener(e -> {
                    cleanupFailedCreatedUser(user);

                    btnRegister.setEnabled(true);

                    String message = e.getMessage() == null ? "Registration failed" : e.getMessage();

                    if (message.toLowerCase(Locale.US).contains("username already exists")) {
                        etRegisterName.setError("Username already exists");
                        etRegisterName.requestFocus();
                        Toast.makeText(this, "This username already exists", Toast.LENGTH_LONG).show();
                        return;
                    }

                    if (message.toLowerCase(Locale.US).contains("permission")) {
                        Toast.makeText(
                                this,
                                "Firestore rules are blocking account creation. Update Firestore Rules with the file I sent.",
                                Toast.LENGTH_LONG
                        ).show();
                        return;
                    }

                    Toast.makeText(this, message, Toast.LENGTH_LONG).show();
                });
    }

    private void cleanupFailedCreatedUser(FirebaseUser user) {
        if (user == null) {
            auth.signOut();
            return;
        }

        user.delete().addOnCompleteListener(task -> auth.signOut());
    }


    private boolean isValidUsernameKey(String username) {
        if (username == null) {
            return false;
        }

        return username.matches("[a-z0-9._-]{3,30}");
    }

    private String normalizeUsername(String username) {
        if (username == null) {
            return "";
        }

        return username.trim().toLowerCase(Locale.US);
    }

    private void saveBirthDateLocal(String birthDate) {
        SharedPreferences prefs = getSharedPreferences(PROFILE_PREFS, MODE_PRIVATE);
        prefs.edit()
                .putString(KEY_BIRTH_DATE, birthDate == null ? "" : birthDate)
                .apply();
    }

    private void showBirthDatePicker() {
        AlertDialog dialog = createBirthDatePickerDialog(
                safeText(etRegisterDateOfBirth),
                selectedDate -> etRegisterDateOfBirth.setText(selectedDate)
        );
        dialog.show();
    }

    private AlertDialog createBirthDatePickerDialog(String currentValue, BirthDateSelectionCallback callback) {
        Calendar calendar = parseBirthDateOrDefault(currentValue);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(20), dp(22), dp(18));
        root.setBackgroundResource(R.drawable.bg_settings_dialog);

        TextView title = new TextView(this);
        title.setText("Select date of birth");
        title.setTextColor(Color.WHITE);
        title.setTextSize(22);
        title.setTypeface(null, android.graphics.Typeface.BOLD);

        TextView subtitle = new TextView(this);
        subtitle.setText("Choose your day, month and year.");
        subtitle.setTextColor(0xFF97A9C9);
        subtitle.setTextSize(14);
        subtitle.setPadding(0, dp(8), 0, dp(18));

        LinearLayout pickerRow = new LinearLayout(this);
        pickerRow.setOrientation(LinearLayout.HORIZONTAL);
        pickerRow.setGravity(Gravity.CENTER);
        pickerRow.setPadding(0, 0, 0, dp(18));

        NumberPicker dayPicker = new NumberPicker(this);
        NumberPicker monthPicker = new NumberPicker(this);
        NumberPicker yearPicker = new NumberPicker(this);

        styleNumberPicker(dayPicker);
        styleNumberPicker(monthPicker);
        styleNumberPicker(yearPicker);

        int currentYear = Calendar.getInstance().get(Calendar.YEAR);

        dayPicker.setMinValue(1);
        dayPicker.setMaxValue(31);
        dayPicker.setValue(calendar.get(Calendar.DAY_OF_MONTH));
        dayPicker.setWrapSelectorWheel(true);

        monthPicker.setMinValue(0);
        monthPicker.setMaxValue(11);
        monthPicker.setDisplayedValues(monthNames);
        monthPicker.setValue(calendar.get(Calendar.MONTH));
        monthPicker.setWrapSelectorWheel(true);

        yearPicker.setMinValue(1940);
        yearPicker.setMaxValue(currentYear);
        yearPicker.setValue(calendar.get(Calendar.YEAR));
        yearPicker.setWrapSelectorWheel(false);

        updateDayPickerMax(dayPicker, monthPicker.getValue(), yearPicker.getValue());

        monthPicker.setOnValueChangedListener((picker, oldVal, newVal) ->
                updateDayPickerMax(dayPicker, newVal, yearPicker.getValue()));

        yearPicker.setOnValueChangedListener((picker, oldVal, newVal) ->
                updateDayPickerMax(dayPicker, monthPicker.getValue(), newVal));

        LinearLayout.LayoutParams pickerParams = new LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.WRAP_CONTENT,
                1f
        );
        pickerParams.leftMargin = dp(4);
        pickerParams.rightMargin = dp(4);

        pickerRow.addView(dayPicker, pickerParams);
        pickerRow.addView(monthPicker, pickerParams);
        pickerRow.addView(yearPicker, pickerParams);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.CENTER);
        actions.setPadding(0, dp(8), 0, 0);
        actions.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        ));

        TextView cancel = createDialogButton("Cancel", false);
        TextView save = createDialogButton("Save", true);

        LinearLayout.LayoutParams cancelParams = new LinearLayout.LayoutParams(
                0,
                dp(48),
                1f
        );
        cancelParams.rightMargin = dp(8);

        LinearLayout.LayoutParams saveParams = new LinearLayout.LayoutParams(
                0,
                dp(48),
                1f
        );
        saveParams.leftMargin = dp(8);

        actions.addView(cancel, cancelParams);
        actions.addView(save, saveParams);

        root.addView(title);
        root.addView(subtitle);
        root.addView(pickerRow);
        root.addView(actions);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(root)
                .create();

        dialog.setOnShowListener(d -> {
            Window window = dialog.getWindow();

            if (window != null) {
                window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            }
        });

        cancel.setOnClickListener(v -> dialog.dismiss());

        save.setOnClickListener(v -> {
            int day = dayPicker.getValue();
            int month = monthPicker.getValue() + 1;
            int year = yearPicker.getValue();

            String formatted = String.format(Locale.getDefault(), "%02d/%02d/%04d", day, month, year);
            callback.onDateSelected(formatted);
            dialog.dismiss();
        });

        return dialog;
    }

    private TextView createDialogButton(String text, boolean primary) {
        TextView button = new TextView(this);
        button.setText(text);
        button.setGravity(Gravity.CENTER);
        button.setTextSize(14);
        button.setTypeface(null, android.graphics.Typeface.BOLD);
        button.setPadding(dp(20), dp(11), dp(20), dp(11));
        button.setTextColor(primary ? Color.WHITE : 0xFF97A9C9);
        button.setBackgroundResource(primary ? R.drawable.bg_pill_primary : R.drawable.bg_settings_cancel_button);
        return button;
    }

    private void styleNumberPicker(NumberPicker picker) {
        picker.setDescendantFocusability(NumberPicker.FOCUS_BLOCK_DESCENDANTS);
    }

    private void updateDayPickerMax(NumberPicker dayPicker, int month, int year) {
        int maxDay = getDaysInMonth(month, year);
        int currentDay = dayPicker.getValue();

        dayPicker.setMaxValue(maxDay);

        if (currentDay > maxDay) {
            dayPicker.setValue(maxDay);
        }
    }

    private int getDaysInMonth(int month, int year) {
        switch (month) {
            case 1:
                return isLeapYear(year) ? 29 : 28;
            case 3:
            case 5:
            case 8:
            case 10:
                return 30;
            default:
                return 31;
        }
    }

    private boolean isLeapYear(int year) {
        return (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
    }

    private Calendar parseBirthDateOrDefault(String value) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.YEAR, 2000);
        calendar.set(Calendar.MONTH, Calendar.JANUARY);
        calendar.set(Calendar.DAY_OF_MONTH, 1);

        if (value == null || value.trim().isEmpty()) {
            return calendar;
        }

        try {
            String[] parts = value.split("/");
            if (parts.length == 3) {
                int day = Integer.parseInt(parts[0]);
                int month = Integer.parseInt(parts[1]) - 1;
                int year = Integer.parseInt(parts[2]);

                calendar.set(Calendar.YEAR, year);
                calendar.set(Calendar.MONTH, month);
                calendar.set(Calendar.DAY_OF_MONTH, day);
            }
        } catch (Exception ignored) {
        }

        return calendar;
    }

    private void setupPasswordToggle(EditText editText, int startIcon) {
        if (editText == null) {
            return;
        }

        final boolean[] passwordVisible = new boolean[]{false};

        applyPasswordState(editText, false, startIcon);

        editText.post(() -> {
            passwordVisible[0] = false;
            applyPasswordState(editText, false, startIcon);
        });

        editText.setOnTouchListener((view, event) -> {
            if (event.getAction() != MotionEvent.ACTION_UP) {
                return false;
            }

            if (!didTapPasswordEye(editText, event)) {
                return false;
            }

            passwordVisible[0] = !passwordVisible[0];
            applyPasswordState(editText, passwordVisible[0], startIcon);

            return true;
        });
    }

    private void applyPasswordState(EditText editText, boolean visible, int startIcon) {
        if (editText == null) {
            return;
        }

        int selection = safeSelection(editText);

        editText.setSingleLine(true);
        editText.setInputType(InputType.TYPE_CLASS_TEXT
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
                | (visible
                ? InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                : InputType.TYPE_TEXT_VARIATION_PASSWORD));

        editText.setTransformationMethod(visible
                ? null
                : BulletPasswordTransformationMethod.getInstance());

        int icon = visible ? R.drawable.ic_eye_show : R.drawable.ic_eye_hide;

        editText.setCompoundDrawablePadding(dp(10));
        editText.setCompoundDrawablesRelativeWithIntrinsicBounds(
                startIcon,
                0,
                icon,
                0
        );

        restoreSelection(editText, selection);
    }

    private boolean didTapPasswordEye(EditText editText, MotionEvent event) {
        if (editText == null) {
            return false;
        }

        Drawable eye = editText.getCompoundDrawablesRelative()[2];

        if (eye == null) {
            eye = editText.getCompoundDrawables()[2];
        }

        if (eye == null) {
            return false;
        }

        int drawableWidth = Math.max(eye.getIntrinsicWidth(), dp(24));
        int touchArea = dp(34);

        if (editText.getLayoutDirection() == View.LAYOUT_DIRECTION_RTL) {
            return event.getX() <= editText.getPaddingLeft() + drawableWidth + touchArea;
        }

        return event.getX() >= editText.getWidth()
                - editText.getPaddingRight()
                - drawableWidth
                - touchArea;
    }

    private int safeSelection(EditText editText) {
        int selection = editText.getSelectionStart();

        if (selection < 0) {
            return editText.getText() == null ? 0 : editText.getText().length();
        }

        return selection;
    }

    private void restoreSelection(EditText editText, int selection) {
        int length = editText.getText() == null ? 0 : editText.getText().length();

        if (selection < 0 || selection > length) {
            selection = length;
        }

        editText.setSelection(selection);
    }

    private static final class BulletPasswordTransformationMethod extends PasswordTransformationMethod {
        private static final BulletPasswordTransformationMethod INSTANCE =
                new BulletPasswordTransformationMethod();

        public static BulletPasswordTransformationMethod getInstance() {
            return INSTANCE;
        }

        @Override
        public CharSequence getTransformation(CharSequence source, View view) {
            return new BulletPasswordCharSequence(source);
        }

        private static final class BulletPasswordCharSequence implements CharSequence {
            private final CharSequence source;

            BulletPasswordCharSequence(CharSequence source) {
                this.source = source == null ? "" : source;
            }

            @Override
            public int length() {
                return source.length();
            }

            @Override
            public char charAt(int index) {
                return '•';
            }

            @Override
            public CharSequence subSequence(int start, int end) {
                StringBuilder builder = new StringBuilder();

                for (int i = start; i < end; i++) {
                    builder.append('•');
                }

                return builder.toString();
            }

            @Override
            public String toString() {
                StringBuilder builder = new StringBuilder();

                for (int i = 0; i < source.length(); i++) {
                    builder.append('•');
                }

                return builder.toString();
            }
        }
    }

    private String safeText(EditText editText) {
        return editText == null || editText.getText() == null
                ? ""
                : editText.getText().toString().trim();
    }

    private int dp(int value) {
        return Math.round(getResources().getDisplayMetrics().density * value);
    }

    private interface BirthDateSelectionCallback {
        void onDateSelected(String selectedDate);
    }
}