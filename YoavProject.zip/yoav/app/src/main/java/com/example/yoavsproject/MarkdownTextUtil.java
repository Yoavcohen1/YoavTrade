package com.example.yoavsproject;

import android.os.Build;
import android.text.Html;
import android.text.Spanned;

public final class MarkdownTextUtil {

    private MarkdownTextUtil() {
        
    }

    public static Spanned toRichText(String raw) {
        String text = raw == null ? "" : raw;

        
        text = text.replace("&", "&amp;");
        text = text.replace("<", "&lt;");
        text = text.replace(">", "&gt;");

        
        text = text.replaceAll("(?m)^###\\s*(.+)$", "<b><big>$1</big></b>");
        text = text.replaceAll("(?m)^##\\s*(.+)$", "<b>$1</b>");
        text = text.replaceAll("(?m)^#\\s*(.+)$", "<b>$1</b>");

        
        text = text.replaceAll("\\*\\*(.+?)\\*\\*", "<b>$1</b>");
        text = text.replaceAll("__(.+?)__", "<b>$1</b>");

        
        text = text.replaceAll("(?m)^\\s*[-*]\\s+", "&#8226; ");

        
        text = text.replaceAll("(?m)^\\s*([-*])\\1\\1+\\s*$", "");

        
        text = text.replace("\n", "<br>");

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            return Html.fromHtml(text, Html.FROM_HTML_MODE_LEGACY);
        } else {
            return Html.fromHtml(text);
        }
    }
}