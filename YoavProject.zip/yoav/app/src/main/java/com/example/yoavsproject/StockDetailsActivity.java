package com.example.yoavsproject;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.card.MaterialCardView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import com.google.firebase.auth.FirebaseAuth;

import java.text.SimpleDateFormat;
import java.util.Locale;










public class StockDetailsActivity extends AppCompatActivity {

    private String symbol = "AAPL";
    private String companyName = "Apple";
    private String requestedMode = "";

    private double livePrice = 0.0;
    private double cashBalance = 0.0;
    private double ownedShares = 0.0;

    private boolean cashLoaded = false;
    private boolean holdingsLoaded = false;

    private ImageView imgLogo;
    private TextView tvCompanyName;
    private TextView tvSymbol;
    private TextView tvLivePrice;
    private TextView tvLiveStatus;
    private TextView tvCashBalance;
    private TextView tvOwnedShares;
    private TextView tvPositionValue;
    private TextView tvTradeHint;

    private TextView btnBuy;
    private TextView btnSell;
    private TextView btnChart;
    private TextView btnRefresh;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        AppSettingsManager.applySavedUi(this);

        super.onCreate(savedInstanceState);

        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        readIntent();
        buildScreen();
        loadEverything();

        if ("BUY".equalsIgnoreCase(requestedMode)) {
            btnBuy.postDelayed(() -> openTradeWhenReady(TradeBottomSheet.Mode.BUY), 700);
        } else if ("SELL".equalsIgnoreCase(requestedMode)) {
            btnSell.postDelayed(() -> openTradeWhenReady(TradeBottomSheet.Mode.SELL), 700);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshPortfolioOnly();
    }

    private void readIntent() {
        Intent intent = getIntent();

        if (intent == null) {
            return;
        }

        String s1 = intent.getStringExtra("symbol");
        String s2 = intent.getStringExtra("stockSymbol");

        if (s1 != null && !s1.trim().isEmpty()) {
            symbol = s1.trim().toUpperCase(Locale.US);
        } else if (s2 != null && !s2.trim().isEmpty()) {
            symbol = s2.trim().toUpperCase(Locale.US);
        }

        String n1 = intent.getStringExtra("stockName");
        String n2 = intent.getStringExtra("companyName");
        String n3 = intent.getStringExtra("name");

        if (n1 != null && !n1.trim().isEmpty()) {
            companyName = n1.trim();
        } else if (n2 != null && !n2.trim().isEmpty()) {
            companyName = n2.trim();
        } else if (n3 != null && !n3.trim().isEmpty()) {
            companyName = n3.trim();
        } else {
            companyName = getCompanyName(symbol);
        }

        double priceExtra = intent.getDoubleExtra("price", 0.0);
        if (priceExtra <= 0.0) {
            priceExtra = intent.getDoubleExtra("lastPrice", 0.0);
        }

        if (priceExtra > 0.0) {
            livePrice = priceExtra;
        }

        String mode = intent.getStringExtra("mode");
        requestedMode = mode == null ? "" : mode.trim().toUpperCase(Locale.US);
    }

    private void buildScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(6, 11, 20));

        ScrollView scrollView = new ScrollView(this);
        scrollView.setFillViewport(true);
        scrollView.setOverScrollMode(ScrollView.OVER_SCROLL_NEVER);
        scrollView.setVerticalScrollBarEnabled(false);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(20), dp(44), dp(20), dp(28));

        LinearLayout topRow = new LinearLayout(this);
        topRow.setOrientation(LinearLayout.HORIZONTAL);
        topRow.setGravity(Gravity.CENTER_VERTICAL);

        TextView btnBack = new TextView(this);
        btnBack.setText("‹");
        btnBack.setTextColor(Color.WHITE);
        btnBack.setTextSize(34);
        btnBack.setTypeface(null, Typeface.BOLD);
        btnBack.setGravity(Gravity.CENTER);
        btnBack.setBackground(makeRoundedDrawable(
                Color.rgb(16, 27, 46),
                dp(18),
                Color.rgb(36, 54, 83)
        ));
        btnBack.setOnClickListener(v -> finish());

        topRow.addView(btnBack, new LinearLayout.LayoutParams(dp(48), dp(48)));

        TextView headerTitle = new TextView(this);
        headerTitle.setText("Stock details");
        headerTitle.setTextColor(Color.WHITE);
        headerTitle.setTextSize(20);
        headerTitle.setTypeface(null, Typeface.BOLD);
        headerTitle.setGravity(Gravity.CENTER_VERTICAL);
        headerTitle.setPadding(dp(14), 0, 0, 0);

        topRow.addView(headerTitle, new LinearLayout.LayoutParams(0, dp(48), 1f));

        btnRefresh = new TextView(this);
        btnRefresh.setText("Refresh");
        btnRefresh.setTextColor(Color.rgb(191, 208, 255));
        btnRefresh.setTextSize(13);
        btnRefresh.setTypeface(null, Typeface.BOLD);
        btnRefresh.setGravity(Gravity.CENTER);
        btnRefresh.setBackground(makeRoundedDrawable(
                Color.rgb(16, 27, 46),
                dp(18),
                Color.rgb(36, 54, 83)
        ));
        btnRefresh.setOnClickListener(v -> loadEverything());

        topRow.addView(btnRefresh, new LinearLayout.LayoutParams(dp(94), dp(44)));

        LinearLayout heroCard = createCard();
        heroCard.setPadding(dp(18), dp(18), dp(18), dp(18));
        heroCard.setGravity(Gravity.CENTER_HORIZONTAL);

        MaterialCardView logoWrap = createStockLogoCard();

        tvCompanyName = new TextView(this);
        tvCompanyName.setText(companyName);
        tvCompanyName.setTextColor(Color.WHITE);
        tvCompanyName.setTextSize(30);
        tvCompanyName.setTypeface(null, Typeface.BOLD);
        tvCompanyName.setGravity(Gravity.CENTER);
        tvCompanyName.setPadding(0, dp(16), 0, 0);

        tvSymbol = new TextView(this);
        tvSymbol.setText(symbol);
        tvSymbol.setTextColor(Color.rgb(143, 163, 196));
        tvSymbol.setTextSize(15);
        tvSymbol.setTypeface(null, Typeface.BOLD);
        tvSymbol.setGravity(Gravity.CENTER);
        tvSymbol.setPadding(0, dp(4), 0, 0);

        tvLivePrice = new TextView(this);
        tvLivePrice.setText(livePrice > 0.0 ? formatMoney(livePrice) : "Loading...");
        tvLivePrice.setTextColor(Color.WHITE);
        tvLivePrice.setTextSize(38);
        tvLivePrice.setTypeface(null, Typeface.BOLD);
        tvLivePrice.setGravity(Gravity.CENTER);
        tvLivePrice.setPadding(0, dp(20), 0, 0);

        tvLiveStatus = new TextView(this);
        tvLiveStatus.setText("Checking live price...");
        tvLiveStatus.setTextColor(Color.rgb(143, 163, 196));
        tvLiveStatus.setTextSize(13);
        tvLiveStatus.setGravity(Gravity.CENTER);
        tvLiveStatus.setPadding(0, dp(8), 0, 0);

        heroCard.addView(logoWrap);
        heroCard.addView(tvCompanyName);
        heroCard.addView(tvSymbol);
        heroCard.addView(tvLivePrice);
        heroCard.addView(tvLiveStatus);

        LinearLayout.LayoutParams heroParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        heroParams.topMargin = dp(18);

        LinearLayout statsRow = new LinearLayout(this);
        statsRow.setOrientation(LinearLayout.HORIZONTAL);

        tvCashBalance = createStatCard(statsRow, "Cash available", "$0.00");
        tvOwnedShares = createStatCard(statsRow, "Owned shares", "0");

        LinearLayout.LayoutParams statsParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        statsParams.topMargin = dp(14);

        LinearLayout valueCard = createCard();
        valueCard.setPadding(dp(16), dp(15), dp(16), dp(15));

        TextView valueLabel = new TextView(this);
        valueLabel.setText("Current position value");
        valueLabel.setTextColor(Color.rgb(143, 163, 196));
        valueLabel.setTextSize(13);

        tvPositionValue = new TextView(this);
        tvPositionValue.setText("$0.00");
        tvPositionValue.setTextColor(Color.WHITE);
        tvPositionValue.setTextSize(24);
        tvPositionValue.setTypeface(null, Typeface.BOLD);
        tvPositionValue.setPadding(0, dp(7), 0, 0);

        tvTradeHint = new TextView(this);
        tvTradeHint.setText("Load a live price to start trading.");
        tvTradeHint.setTextColor(Color.rgb(143, 163, 196));
        tvTradeHint.setTextSize(13);
        tvTradeHint.setPadding(0, dp(7), 0, 0);

        valueCard.addView(valueLabel);
        valueCard.addView(tvPositionValue);
        valueCard.addView(tvTradeHint);

        LinearLayout.LayoutParams valueParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        valueParams.topMargin = dp(14);

        LinearLayout buttonsRow = new LinearLayout(this);
        buttonsRow.setOrientation(LinearLayout.HORIZONTAL);

        btnBuy = createActionButton("Buy", Color.rgb(34, 197, 94));
        btnSell = createActionButton("Sell", Color.rgb(239, 68, 68));

        btnBuy.setOnClickListener(v -> openTradeWhenReady(TradeBottomSheet.Mode.BUY));
        btnSell.setOnClickListener(v -> openTradeWhenReady(TradeBottomSheet.Mode.SELL));

        LinearLayout.LayoutParams buyParams = new LinearLayout.LayoutParams(0, dp(56), 1f);
        buyParams.rightMargin = dp(8);

        LinearLayout.LayoutParams sellParams = new LinearLayout.LayoutParams(0, dp(56), 1f);
        sellParams.leftMargin = dp(8);

        buttonsRow.addView(btnBuy, buyParams);
        buttonsRow.addView(btnSell, sellParams);

        LinearLayout.LayoutParams buttonsParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        buttonsParams.topMargin = dp(18);

        btnChart = createActionButton("Chart", Color.rgb(49, 93, 255));
        btnChart.setOnClickListener(v -> openChart());

        LinearLayout.LayoutParams chartParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(56)
        );
        chartParams.topMargin = dp(12);

        content.addView(topRow);
        content.addView(heroCard, heroParams);
        content.addView(statsRow, statsParams);
        content.addView(valueCard, valueParams);
        content.addView(buttonsRow, buttonsParams);
        content.addView(btnChart, chartParams);

        scrollView.addView(content);

        root.addView(scrollView, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT
        ));

        setContentView(root);

        bindLogo();
        updateViews();
    }


    private MaterialCardView createStockLogoCard() {
        MaterialCardView outer = new MaterialCardView(this);
        outer.setCardBackgroundColor(Color.rgb(14, 21, 32));
        outer.setRadius(dp(34));
        outer.setCardElevation(0f);
        outer.setStrokeColor(Color.rgb(45, 57, 74));
        outer.setStrokeWidth(dp(1));
        outer.setPreventCornerOverlap(false);
        outer.setUseCompatPadding(false);

        LinearLayout.LayoutParams outerParams = new LinearLayout.LayoutParams(dp(112), dp(112));
        outer.setLayoutParams(outerParams);

        MaterialCardView inner = new MaterialCardView(this);
        inner.setCardBackgroundColor(Color.WHITE);
        inner.setRadius(dp(24));
        inner.setCardElevation(0f);
        inner.setStrokeColor(Color.rgb(238, 242, 248));
        inner.setStrokeWidth(dp(1));
        inner.setPreventCornerOverlap(false);
        inner.setUseCompatPadding(false);

        MaterialCardView.LayoutParams innerParams = new MaterialCardView.LayoutParams(dp(94), dp(94));
        innerParams.gravity = Gravity.CENTER;

        imgLogo = new ImageView(this);
        imgLogo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        imgLogo.setAdjustViewBounds(false);
        imgLogo.setPadding(dp(6), dp(6), dp(6), dp(6));

        inner.addView(imgLogo, new MaterialCardView.LayoutParams(
                MaterialCardView.LayoutParams.MATCH_PARENT,
                MaterialCardView.LayoutParams.MATCH_PARENT
        ));

        outer.addView(inner, innerParams);

        return outer;
    }

    private void loadEverything() {
        setRefreshLoading(true);
        loadLivePrice();
        refreshPortfolioOnly();
    }

    private void refreshPortfolioOnly() {
        if (FirebaseAuth.getInstance().getCurrentUser() == null) {
            cashLoaded = false;
            holdingsLoaded = false;
            cashBalance = 0.0;
            ownedShares = 0.0;
            updateViews();
            return;
        }

        PortfolioManager.getInstance().fetchCashBalance((cash, errorMessage) -> {
            cashLoaded = errorMessage == null;
            cashBalance = cash;
            updateViews();
        });

        PortfolioManager.getInstance().fetchHoldingQuantity(symbol, (quantity, errorMessage) -> {
            holdingsLoaded = errorMessage == null;
            ownedShares = quantity;
            updateViews();
        });
    }

    private void loadLivePrice() {
        updateLiveStatus("Loading live price...", false);

        AlphaVantageClient.lastPriceAsync(symbol, new AlphaVantageClient.PriceCallback() {
            @Override
            public void onSuccess(double price) {
                runOnUiThread(() -> {
                    if (price > 0.0) {
                        livePrice = price;
                        updateLiveStatus("Live price updated " + currentClock(), false);
                    } else if (livePrice > 0.0) {
                        updateLiveStatus("Live price unavailable. Using last known price.", true);
                    } else {
                        updateLiveStatus("Live price unavailable right now.", true);
                    }

                    setRefreshLoading(false);
                    updateViews();
                });
            }

            @Override
            public void onError(Exception e) {
                runOnUiThread(() -> {
                    if (livePrice > 0.0) {
                        updateLiveStatus("Live price unavailable. Using last known price.", true);
                    } else {
                        updateLiveStatus("Live price unavailable right now.", true);
                    }

                    setRefreshLoading(false);
                    updateViews();
                });
            }
        });
    }

    private void openTradeWhenReady(TradeBottomSheet.Mode mode) {
        if (FirebaseAuth.getInstance().getCurrentUser() == null) {
            Toast.makeText(this, "Please sign in to trade", Toast.LENGTH_SHORT).show();
            return;
        }

        if (livePrice <= 0.0) {
            Toast.makeText(this, "Still loading live price", Toast.LENGTH_SHORT).show();
            loadLivePrice();
            return;
        }

        TradeBottomSheet.show(
                this,
                symbol,
                companyName,
                livePrice,
                mode,
                () -> {
                    refreshPortfolioOnly();
                    Toast.makeText(this, "Portfolio updated", Toast.LENGTH_SHORT).show();
                }
        );
    }

    private void openChart() {
        Intent intent = new Intent(this, StockGraphActivity.class);
        intent.putExtra("symbol", symbol);
        intent.putExtra("stockSymbol", symbol);
        intent.putExtra("stockName", companyName);
        intent.putExtra("price", livePrice);
        startActivity(intent);
        overridePendingTransition(0, 0);
    }

    private void updateViews() {
        if (tvCompanyName != null) {
            tvCompanyName.setText(companyName);
        }

        if (tvSymbol != null) {
            tvSymbol.setText(symbol);
        }

        if (tvLivePrice != null) {
            tvLivePrice.setText(livePrice > 0.0 ? formatMoney(livePrice) : "Loading...");
        }

        if (tvCashBalance != null) {
            tvCashBalance.setText(cashLoaded ? formatMoney(cashBalance) : "Checking...");
        }

        if (tvOwnedShares != null) {
            tvOwnedShares.setText(holdingsLoaded ? formatQty(ownedShares) : "Checking...");
        }

        if (tvPositionValue != null) {
            double value = livePrice > 0.0 ? ownedShares * livePrice : 0.0;
            tvPositionValue.setText(formatMoney(value));
        }

        boolean canTrade = livePrice > 0.0;

        if (tvTradeHint != null) {
            if (!canTrade) {
                tvTradeHint.setText("Waiting for a live price before trading.");
                tvTradeHint.setTextColor(Color.rgb(255, 180, 180));
            } else if (ownedShares > 0.0) {
                tvTradeHint.setText("You can buy more or sell your current position.");
                tvTradeHint.setTextColor(Color.rgb(158, 224, 176));
            } else {
                tvTradeHint.setText("You do not own this stock yet. Start with a buy order.");
                tvTradeHint.setTextColor(Color.rgb(143, 163, 196));
            }
        }

        setButtonEnabled(btnBuy, canTrade);
        setButtonEnabled(btnSell, canTrade);
    }

    private void updateLiveStatus(String text, boolean warning) {
        if (tvLiveStatus == null) {
            return;
        }

        tvLiveStatus.setText(text);
        tvLiveStatus.setTextColor(warning
                ? Color.rgb(255, 180, 180)
                : Color.rgb(143, 163, 196));
    }

    private void setRefreshLoading(boolean loading) {
        if (btnRefresh == null) {
            return;
        }

        btnRefresh.setText(loading ? "Loading..." : "Refresh");
        btnRefresh.setAlpha(loading ? 0.65f : 1f);
        btnRefresh.setEnabled(!loading);
    }

    private void bindLogo() {
        if (imgLogo == null) {
            return;
        }

        try {
            StockLogoMapper.bind(imgLogo, symbol);
        } catch (Exception ignored) {
            imgLogo.setImageResource(getFallbackLogo(symbol));
        }
    }

    private LinearLayout createCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(makeRoundedDrawable(
                Color.rgb(11, 20, 36),
                dp(28),
                Color.rgb(36, 54, 83)
        ));
        return card;
    }

    private TextView createStatCard(LinearLayout parent, String labelText, String valueText) {
        LinearLayout card = createCard();
        card.setPadding(dp(14), dp(14), dp(14), dp(14));

        TextView label = new TextView(this);
        label.setText(labelText);
        label.setTextColor(Color.rgb(143, 163, 196));
        label.setTextSize(12);

        TextView value = new TextView(this);
        value.setText(valueText);
        value.setTextColor(Color.WHITE);
        value.setTextSize(18);
        value.setTypeface(null, Typeface.BOLD);
        value.setPadding(0, dp(8), 0, 0);

        card.addView(label);
        card.addView(value);

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, dp(82), 1f);
        if (parent.getChildCount() == 0) {
            params.rightMargin = dp(7);
        } else {
            params.leftMargin = dp(7);
        }

        parent.addView(card, params);

        return value;
    }

    private TextView createActionButton(String text, int color) {
        TextView button = new TextView(this);
        button.setText(text);
        button.setTextColor(Color.WHITE);
        button.setTextSize(15);
        button.setTypeface(null, Typeface.BOLD);
        button.setGravity(Gravity.CENTER);
        button.setIncludeFontPadding(false);
        button.setBackground(makeRoundedDrawable(color, dp(22), color));
        button.setPadding(dp(12), 0, dp(12), 0);
        return button;
    }

    private void setButtonEnabled(TextView button, boolean enabled) {
        if (button == null) {
            return;
        }

        button.setEnabled(enabled);
        button.setAlpha(enabled ? 1.0f : 0.45f);
    }

    private android.graphics.drawable.GradientDrawable makeRoundedDrawable(
            int color,
            int radius,
            int strokeColor
    ) {
        android.graphics.drawable.GradientDrawable drawable =
                new android.graphics.drawable.GradientDrawable();

        drawable.setColor(color);
        drawable.setCornerRadius(radius);
        drawable.setStroke(dp(1), strokeColor);

        return drawable;
    }

    private int getFallbackLogo(String symbol) {
        String s = symbol == null ? "" : symbol.trim().toUpperCase(Locale.US);

        switch (s) {
            case "META":
                return R.drawable.meta;
            case "MSFT":
                return R.drawable.msft;
            case "NFLX":
                return R.drawable.nflx;
            case "NVDA":
                return R.drawable.nvda;
            case "AAPL":
                return R.drawable.aapl;
            default:
                return R.drawable.logo;
        }
    }

    private String getCompanyName(String symbol) {
        String s = symbol == null ? "" : symbol.trim().toUpperCase(Locale.US);

        switch (s) {
            case "AAPL":
                return "Apple";
            case "MSFT":
                return "Microsoft";
            case "NVDA":
                return "NVIDIA";
            case "META":
                return "Meta";
            case "NFLX":
                return "Netflix";
            case "GOOGL":
            case "GOOG":
                return "Alphabet";
            case "AMZN":
                return "Amazon";
            case "TSLA":
                return "Tesla";
            case "AMD":
                return "AMD";
            case "INTC":
                return "Intel";
            case "RDDT":
                return "Reddit";
            default:
                return s.isEmpty() ? "Stock" : s;
        }
    }

    private String currentClock() {
        try {
            SimpleDateFormat format = new SimpleDateFormat("h:mm a", Locale.US);
            return format.format(System.currentTimeMillis());
        } catch (Exception e) {
            return "now";
        }
    }

    private String formatMoney(double value) {
        return String.format(Locale.US, "$%,.2f", value);
    }

    private String formatQty(double value) {
        String raw = String.format(Locale.US, "%.4f", value);

        while (raw.contains(".") && (raw.endsWith("0") || raw.endsWith("."))) {
            raw = raw.substring(0, raw.length() - 1);
        }

        return raw;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}