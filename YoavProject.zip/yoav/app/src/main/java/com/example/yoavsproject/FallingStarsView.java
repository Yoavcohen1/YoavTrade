package com.example.yoavsproject;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.view.View;

import java.util.Random;

public class FallingStarsView extends View {

    private static final float SQRT_HALF = 0.70710677f;

    private final Paint shootingCorePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint shootingGlowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint shootingRingPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint shootingTailPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    private final Paint bgStarPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bgStarGlowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    private final Random random = new Random(42L);

    private float density = 1f;
    private long startTimeMs;
    private boolean running = false;

    private BackgroundStar[] backgroundStars;

    private final ShootingStarPattern[] shootingStars = new ShootingStarPattern[]{
            new ShootingStarPattern(0f, 0f, 0f, 1000f),
            new ShootingStarPattern(0f, 80f, 200f, 3000f),
            new ShootingStarPattern(80f, 0f, 400f, 2000f),
            new ShootingStarPattern(0f, 180f, 600f, 1500f),
            new ShootingStarPattern(0f, 400f, 800f, 2500f),
            new ShootingStarPattern(0f, 600f, 1000f, 3000f),
            new ShootingStarPattern(300f, 0f, 1200f, 1750f),
            new ShootingStarPattern(0f, 700f, 1400f, 1250f),
            new ShootingStarPattern(0f, 1000f, 750f, 2250f),
            new ShootingStarPattern(0f, 450f, 2750f, 2750f)
    };

    public FallingStarsView(Context context) {
        super(context);
        init();
    }

    public FallingStarsView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public FallingStarsView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        density = getResources().getDisplayMetrics().density;

        setLayerType(LAYER_TYPE_SOFTWARE, null);

        shootingCorePaint.setStyle(Paint.Style.FILL);
        shootingCorePaint.setColor(Color.WHITE);

        shootingGlowPaint.setStyle(Paint.Style.FILL);

        shootingRingPaint.setStyle(Paint.Style.STROKE);

        shootingTailPaint.setStyle(Paint.Style.STROKE);
        shootingTailPaint.setStrokeCap(Paint.Cap.ROUND);
        shootingTailPaint.setStrokeWidth(dp(1.15f));

        bgStarPaint.setStyle(Paint.Style.FILL);
        bgStarPaint.setColor(Color.WHITE);

        bgStarGlowPaint.setStyle(Paint.Style.FILL);
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        running = true;
        startTimeMs = SystemClock.uptimeMillis();
        postInvalidateOnAnimation();
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        running = false;
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        buildBackgroundStars(w, h);
    }

    private void buildBackgroundStars(int w, int h) {
        if (w <= 0 || h <= 0) return;

        int count = Math.max(14, Math.min(28, (w * h) / 32000));
        backgroundStars = new BackgroundStar[count];

        for (int i = 0; i < count; i++) {
            BackgroundStar s = new BackgroundStar();
            s.x = random.nextFloat() * w;
            s.y = random.nextFloat() * h;
            s.radius = dp(0.5f + (random.nextFloat() * 1.0f));
            s.alpha = 45 + random.nextInt(70);
            s.phase = random.nextFloat() * 6.2831855f;
            s.speed = 0.6f + (random.nextFloat() * 1.4f);
            backgroundStars[i] = s;
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        int width = getWidth();
        int height = getHeight();
        if (width <= 0 || height <= 0) return;

        long elapsed = SystemClock.uptimeMillis() - startTimeMs;

        drawBackgroundStars(canvas, elapsed);
        drawShootingStars(canvas, width, height, elapsed);

        if (running) {
            postInvalidateOnAnimation();
        }
    }

    private void drawBackgroundStars(Canvas canvas, long elapsed) {
        if (backgroundStars == null) return;

        float t = elapsed / 1000f;

        for (BackgroundStar s : backgroundStars) {
            float twinkle = 0.65f + (0.35f * (float) Math.sin((t * s.speed) + s.phase));
            int alpha = clamp((int) (s.alpha * twinkle), 20, 255);

            bgStarGlowPaint.setColor(Color.argb(alpha / 7, 255, 255, 255));
            canvas.drawCircle(s.x, s.y, s.radius * 2.0f, bgStarGlowPaint);

            bgStarPaint.setColor(Color.argb(alpha, 255, 255, 255));
            canvas.drawCircle(s.x, s.y, s.radius, bgStarPaint);
        }
    }

    private void drawShootingStars(Canvas canvas, int width, int height, long elapsed) {
        long cycle = 6000L;

        for (ShootingStarPattern star : shootingStars) {
            long localTime = elapsed % cycle;

            if (localTime < star.delayMs) {
                continue;
            }

            float progress = (localTime - star.delayMs) / (float) star.durationMs;
            if (progress < 0f || progress > 1f) {
                continue;
            }

            float startX = resolveStartX(width, star.rightDp);
            float startY = resolveStartY(star.topDp);

            float travel = Math.max(width, height) + dp(420f);
            float headX = startX - (travel * progress * SQRT_HALF);
            float headY = startY + (travel * progress * SQRT_HALF);

            float tailLength = dp(220f);
            float tailEndX = headX + (tailLength * SQRT_HALF);
            float tailEndY = headY - (tailLength * SQRT_HALF);

            float alphaFactor = computeAlpha(progress);

            drawShootingTail(canvas, headX, headY, tailEndX, tailEndY, alphaFactor);
            drawShootingHead(canvas, headX, headY, alphaFactor);
        }
    }

    private void drawShootingTail(Canvas canvas,
                                  float headX,
                                  float headY,
                                  float tailEndX,
                                  float tailEndY,
                                  float alphaFactor) {

        int headAlpha = clamp((int) (255 * alphaFactor), 0, 255);
        int midAlpha = clamp((int) (90 * alphaFactor), 0, 255);

        Shader shader = new LinearGradient(
                headX, headY,
                tailEndX, tailEndY,
                new int[]{
                        Color.argb(headAlpha, 255, 255, 255),
                        Color.argb(midAlpha, 255, 255, 255),
                        Color.argb(0, 255, 255, 255)
                },
                new float[]{0f, 0.18f, 1f},
                Shader.TileMode.CLAMP
        );

        shootingTailPaint.setShader(shader);
        canvas.drawLine(headX, headY, tailEndX, tailEndY, shootingTailPaint);
        shootingTailPaint.setShader(null);
    }

    private void drawShootingHead(Canvas canvas, float x, float y, float alphaFactor) {
        int coreAlpha = clamp((int) (255 * alphaFactor), 0, 255);
        int glowAlpha = clamp((int) (32 * alphaFactor), 0, 255);
        int ringAlpha = clamp((int) (26 * alphaFactor), 0, 255);

        Shader glowShader = new RadialGradient(
                x, y, dp(16f),
                new int[]{
                        Color.argb(glowAlpha, 255, 255, 255),
                        Color.argb(glowAlpha / 2, 255, 255, 255),
                        Color.argb(0, 255, 255, 255)
                },
                new float[]{0f, 0.45f, 1f},
                Shader.TileMode.CLAMP
        );
        shootingGlowPaint.setShader(glowShader);
        canvas.drawCircle(x, y, dp(16f), shootingGlowPaint);
        shootingGlowPaint.setShader(null);

        shootingRingPaint.setStrokeWidth(dp(4f));
        shootingRingPaint.setColor(Color.argb(ringAlpha, 255, 255, 255));
        canvas.drawCircle(x, y, dp(4f), shootingRingPaint);

        shootingRingPaint.setStrokeWidth(dp(8f));
        shootingRingPaint.setColor(Color.argb(ringAlpha, 255, 255, 255));
        canvas.drawCircle(x, y, dp(8f), shootingRingPaint);

        shootingCorePaint.setColor(Color.argb(coreAlpha, 255, 255, 255));
        canvas.drawCircle(x, y, dp(2.2f), shootingCorePaint);
    }

    private float computeAlpha(float progress) {
        if (progress <= 0.08f) {
            return progress / 0.08f;
        }
        if (progress <= 0.70f) {
            return 1f;
        }
        return Math.max(0f, 1f - ((progress - 0.70f) / 0.30f));
    }

    private float resolveStartX(int width, float rightDp) {
        float x = width - dp(rightDp);
        if (x < dp(12f)) x = dp(12f);
        if (x > width - dp(12f)) x = width - dp(12f);
        return x;
    }

    private float resolveStartY(float topDp) {
        return dp(topDp);
    }

    private int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    private float dp(float value) {
        return value * density;
    }

    private static class ShootingStarPattern {
        final float topDp;
        final float rightDp;
        final long delayMs;
        final long durationMs;

        ShootingStarPattern(float topDp, float rightDp, float delayMs, float durationMs) {
            this.topDp = topDp;
            this.rightDp = rightDp;
            this.delayMs = (long) delayMs;
            this.durationMs = (long) durationMs;
        }
    }

    private static class BackgroundStar {
        float x;
        float y;
        float radius;
        int alpha;
        float phase;
        float speed;
    }
}