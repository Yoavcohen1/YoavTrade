package com.example.yoavsproject;

import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.switchmaterial.SwitchMaterial;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

















public class PriceAlertsActivity extends AppCompatActivity {

    private ImageView btnBack;
    private MaterialButton btnAddAlert;
    private LinearLayout containerAlerts;
    private TextView tvEmptyState;

    private final List<PriceAlert> alerts = new ArrayList<>();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        AppSettingsManager.applySavedUi(this);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_price_alerts);

        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        bindViews();
        setupClicks();
        loadAlerts();
        renderAlerts();

        AppSettingsManager.savePriceAlertsEnabled(this, true);
        PriceAlertMonitor.start(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadAlerts();
        renderAlerts();

        if (AppSettingsManager.arePriceAlertsEnabled(this)) {
            PriceAlertMonitor.start(this);
        }
    }

    private void bindViews() {
        btnBack = findViewById(R.id.btnBackPriceAlerts);
        btnAddAlert = findViewById(R.id.btnAddPriceAlert);
        containerAlerts = findViewById(R.id.containerPriceAlerts);
        tvEmptyState = findViewById(R.id.tvPriceAlertsEmpty);
    }

    private void setupClicks() {
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> finish());
        }

        if (btnAddAlert != null) {
            btnAddAlert.setOnClickListener(v -> showAddAlertDialog());
        }
    }

    private void showAddAlertDialog() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(20);
        root.setPadding(pad, pad, pad, pad);

        EditText etSymbol = new EditText(this);
        etSymbol.setHint("Stock symbol, e.g. AAPL");
        etSymbol.setSingleLine(true);
        etSymbol.setAllCaps(true);
        etSymbol.setTextColor(0xFFFFFFFF);
        etSymbol.setHintTextColor(0xFF7F91B2);
        etSymbol.setBackgroundResource(R.drawable.bg_stocks_search);
        etSymbol.setPadding(dp(16), dp(14), dp(16), dp(14));

        LinearLayout.LayoutParams symbolParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        symbolParams.bottomMargin = dp(12);
        root.addView(etSymbol, symbolParams);

        EditText etTarget = new EditText(this);
        etTarget.setHint("Target price");
        etTarget.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        etTarget.setTextColor(0xFFFFFFFF);
        etTarget.setHintTextColor(0xFF7F91B2);
        etTarget.setBackgroundResource(R.drawable.bg_stocks_search);
        etTarget.setPadding(dp(16), dp(14), dp(16), dp(14));

        LinearLayout.LayoutParams targetParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        targetParams.bottomMargin = dp(14);
        root.addView(etTarget, targetParams);

        TextView modeTitle = new TextView(this);
        modeTitle.setText("Alert condition");
        modeTitle.setTextColor(0xFF1A1D23);
        modeTitle.setTextSize(14);
        modeTitle.setTypeface(modeTitle.getTypeface(), android.graphics.Typeface.BOLD);

        LinearLayout.LayoutParams modeTitleParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        modeTitleParams.bottomMargin = dp(8);
        root.addView(modeTitle, modeTitleParams);

        RadioGroup rgMode = new RadioGroup(this);
        rgMode.setOrientation(RadioGroup.VERTICAL);

        RadioButton rbAbove = new RadioButton(this);
        rbAbove.setId(View.generateViewId());
        rbAbove.setText("Notify when price is above or equal to target");
        rbAbove.setTextColor(0xFF1A1D23);
        rbAbove.setChecked(true);

        RadioButton rbBelow = new RadioButton(this);
        rbBelow.setId(View.generateViewId());
        rbBelow.setText("Notify when price is below or equal to target");
        rbBelow.setTextColor(0xFF1A1D23);

        rgMode.addView(rbAbove);
        rgMode.addView(rbBelow);
        root.addView(rgMode);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Create price alert")
                .setMessage("Choose a stock, target price and condition.")
                .setView(root)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Save", null)
                .create();

        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String symbol = cleanSymbol(etSymbol.getText() == null ? "" : etSymbol.getText().toString());
            String priceText = etTarget.getText() == null ? "" : etTarget.getText().toString().trim();

            if (TextUtils.isEmpty(symbol)) {
                etSymbol.setError("Enter stock symbol");
                return;
            }

            if (!isValidSymbol(symbol)) {
                etSymbol.setError("Use letters only, e.g. AAPL");
                return;
            }

            if (TextUtils.isEmpty(priceText)) {
                etTarget.setError("Enter target price");
                return;
            }

            double target;
            try {
                target = Double.parseDouble(priceText);
            } catch (Exception e) {
                etTarget.setError("Invalid price");
                return;
            }

            if (target <= 0.0) {
                etTarget.setError("Price must be greater than 0");
                return;
            }

            String mode = rbBelow.isChecked()
                    ? PriceAlert.MODE_BELOW
                    : PriceAlert.MODE_ABOVE;

            PriceAlert alert = new PriceAlert(symbol, target, mode);

            PriceAlertStore.addAlert(this, alert);
            AppSettingsManager.savePriceAlertsEnabled(this, true);
            PriceAlertMonitor.start(this);

            loadAlerts();
            renderAlerts();

            Toast.makeText(this, "Price alert added", Toast.LENGTH_SHORT).show();
            dialog.dismiss();
        }));

        dialog.show();
    }

    private void loadAlerts() {
        alerts.clear();

        try {
            List<PriceAlert> stored = PriceAlertStore.getAlerts(this);

            for (PriceAlert alert : stored) {
                if (alert == null) {
                    continue;
                }

                alert.symbol = cleanSymbol(alert.symbol);

                if (TextUtils.isEmpty(alert.symbol) || alert.targetPrice <= 0.0) {
                    continue;
                }

                alerts.add(alert);
            }
        } catch (Exception ignored) {
        }
    }

    private void renderAlerts() {
        if (containerAlerts == null) {
            return;
        }

        containerAlerts.removeAllViews();

        if (alerts.isEmpty()) {
            if (tvEmptyState != null) {
                tvEmptyState.setVisibility(View.VISIBLE);
            }
            return;
        }

        if (tvEmptyState != null) {
            tvEmptyState.setVisibility(View.GONE);
        }

        for (PriceAlert alert : alerts) {
            containerAlerts.addView(createAlertCard(alert));
        }
    }

    private View createAlertCard(@NonNull PriceAlert alert) {
        MaterialCardView card = new MaterialCardView(this);
        card.setCardBackgroundColor(0xFF151921);
        card.setRadius(dp(18));
        card.setStrokeWidth(dp(1));
        card.setStrokeColor(0xFF253754);

        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        cardParams.bottomMargin = dp(12);
        card.setLayoutParams(cardParams);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(16));

        LinearLayout topRow = new LinearLayout(this);
        topRow.setOrientation(LinearLayout.HORIZONTAL);
        topRow.setGravity(Gravity.CENTER_VERTICAL);

        LinearLayout textWrap = new LinearLayout(this);
        textWrap.setOrientation(LinearLayout.VERTICAL);

        LinearLayout.LayoutParams textWrapParams = new LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.WRAP_CONTENT,
                1f
        );
        textWrap.setLayoutParams(textWrapParams);

        TextView tvSymbol = new TextView(this);
        tvSymbol.setText(alert.symbol);
        tvSymbol.setTextColor(0xFFFFFFFF);
        tvSymbol.setTextSize(18);
        tvSymbol.setTypeface(tvSymbol.getTypeface(), android.graphics.Typeface.BOLD);

        TextView tvTarget = new TextView(this);
        tvTarget.setText(buildConditionText(alert));
        tvTarget.setTextColor(0xFF9EB0C7);
        tvTarget.setTextSize(13);
        tvTarget.setPadding(0, dp(5), 0, 0);

        TextView tvLastTriggered = new TextView(this);
        tvLastTriggered.setText(buildLastTriggeredText(alert));
        tvLastTriggered.setTextColor(0xFF6F819F);
        tvLastTriggered.setTextSize(12);
        tvLastTriggered.setPadding(0, dp(5), 0, 0);

        textWrap.addView(tvSymbol);
        textWrap.addView(tvTarget);
        textWrap.addView(tvLastTriggered);

        SwitchMaterial switchEnabled = new SwitchMaterial(this);
        switchEnabled.setChecked(alert.enabled);
        switchEnabled.setOnCheckedChangeListener((buttonView, isChecked) -> {
            alert.enabled = isChecked;
            PriceAlertStore.updateAlert(this, alert);

            if (isChecked) {
                AppSettingsManager.savePriceAlertsEnabled(this, true);
                PriceAlertMonitor.start(this);
            }

            Toast.makeText(
                    this,
                    isChecked ? "Alert enabled" : "Alert paused",
                    Toast.LENGTH_SHORT
            ).show();
        });

        topRow.addView(textWrap);
        topRow.addView(switchEnabled);

        LinearLayout bottomRow = new LinearLayout(this);
        bottomRow.setOrientation(LinearLayout.HORIZONTAL);
        bottomRow.setGravity(Gravity.CENTER_VERTICAL);
        bottomRow.setPadding(0, dp(14), 0, 0);

        MaterialButton btnEdit = new MaterialButton(this);
        btnEdit.setText("Edit");
        btnEdit.setTextColor(0xFFFFFFFF);
        btnEdit.setAllCaps(false);
        btnEdit.setBackgroundResource(R.drawable.bg_pill_outline);
        btnEdit.setOnClickListener(v -> showEditAlertDialog(alert));

        MaterialButton btnDelete = new MaterialButton(this);
        btnDelete.setText("Remove");
        btnDelete.setTextColor(0xFFFFFFFF);
        btnDelete.setAllCaps(false);
        btnDelete.setBackgroundResource(R.drawable.bg_pill_outline);
        btnDelete.setOnClickListener(v -> confirmDelete(alert));

        LinearLayout.LayoutParams editParams = new LinearLayout.LayoutParams(0, dp(44), 1f);
        editParams.rightMargin = dp(7);

        LinearLayout.LayoutParams deleteParams = new LinearLayout.LayoutParams(0, dp(44), 1f);
        deleteParams.leftMargin = dp(7);

        bottomRow.addView(btnEdit, editParams);
        bottomRow.addView(btnDelete, deleteParams);

        root.addView(topRow);
        root.addView(bottomRow);

        card.addView(root);
        return card;
    }

    private void showEditAlertDialog(@NonNull PriceAlert alert) {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(20);
        root.setPadding(pad, pad, pad, pad);

        EditText etSymbol = new EditText(this);
        etSymbol.setHint("Stock symbol");
        etSymbol.setSingleLine(true);
        etSymbol.setText(alert.symbol);
        etSymbol.setAllCaps(true);
        etSymbol.setTextColor(0xFFFFFFFF);
        etSymbol.setHintTextColor(0xFF7F91B2);
        etSymbol.setBackgroundResource(R.drawable.bg_stocks_search);
        etSymbol.setPadding(dp(16), dp(14), dp(16), dp(14));

        LinearLayout.LayoutParams symbolParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        symbolParams.bottomMargin = dp(12);
        root.addView(etSymbol, symbolParams);

        EditText etTarget = new EditText(this);
        etTarget.setHint("Target price");
        etTarget.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        etTarget.setText(String.format(Locale.US, "%.2f", alert.targetPrice));
        etTarget.setTextColor(0xFFFFFFFF);
        etTarget.setHintTextColor(0xFF7F91B2);
        etTarget.setBackgroundResource(R.drawable.bg_stocks_search);
        etTarget.setPadding(dp(16), dp(14), dp(16), dp(14));

        LinearLayout.LayoutParams targetParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        targetParams.bottomMargin = dp(14);
        root.addView(etTarget, targetParams);

        RadioGroup rgMode = new RadioGroup(this);
        rgMode.setOrientation(RadioGroup.VERTICAL);

        RadioButton rbAbove = new RadioButton(this);
        rbAbove.setId(View.generateViewId());
        rbAbove.setText("Notify when price is above or equal to target");
        rbAbove.setTextColor(0xFF1A1D23);

        RadioButton rbBelow = new RadioButton(this);
        rbBelow.setId(View.generateViewId());
        rbBelow.setText("Notify when price is below or equal to target");
        rbBelow.setTextColor(0xFF1A1D23);

        rgMode.addView(rbAbove);
        rgMode.addView(rbBelow);

        if (PriceAlert.MODE_BELOW.equals(alert.mode)) {
            rbBelow.setChecked(true);
        } else {
            rbAbove.setChecked(true);
        }

        root.addView(rgMode);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Edit price alert")
                .setView(root)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Save", null)
                .create();

        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String symbol = cleanSymbol(etSymbol.getText() == null ? "" : etSymbol.getText().toString());
            String priceText = etTarget.getText() == null ? "" : etTarget.getText().toString().trim();

            if (TextUtils.isEmpty(symbol)) {
                etSymbol.setError("Enter stock symbol");
                return;
            }

            if (!isValidSymbol(symbol)) {
                etSymbol.setError("Use letters only, e.g. AAPL");
                return;
            }

            double target;
            try {
                target = Double.parseDouble(priceText);
            } catch (Exception e) {
                etTarget.setError("Invalid price");
                return;
            }

            if (target <= 0.0) {
                etTarget.setError("Price must be greater than 0");
                return;
            }

            alert.symbol = symbol;
            alert.targetPrice = target;
            alert.mode = rbBelow.isChecked() ? PriceAlert.MODE_BELOW : PriceAlert.MODE_ABOVE;
            alert.enabled = true;

            PriceAlertStore.updateAlert(this, alert);
            AppSettingsManager.savePriceAlertsEnabled(this, true);
            PriceAlertMonitor.start(this);

            loadAlerts();
            renderAlerts();

            Toast.makeText(this, "Alert updated", Toast.LENGTH_SHORT).show();
            dialog.dismiss();
        }));

        dialog.show();
    }

    private void confirmDelete(@NonNull PriceAlert alert) {
        new AlertDialog.Builder(this)
                .setTitle("Remove alert?")
                .setMessage("Remove the " + alert.symbol + " price alert?")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Remove", (dialog, which) -> {
                    PriceAlertStore.deleteAlert(this, alert.id);
                    loadAlerts();
                    renderAlerts();
                    Toast.makeText(this, "Alert removed", Toast.LENGTH_SHORT).show();
                })
                .show();
    }

    private String buildConditionText(@NonNull PriceAlert alert) {
        String condition = PriceAlert.MODE_BELOW.equals(alert.mode)
                ? "falls to or below "
                : "reaches or rises above ";

        return "Notify when price " + condition + AppSettingsManager.formatUsdAmount(this, alert.targetPrice);
    }

    private String buildLastTriggeredText(@NonNull PriceAlert alert) {
        if (alert.lastTriggeredAt <= 0L) {
            return "Not triggered yet";
        }

        long diff = Math.max(0L, System.currentTimeMillis() - alert.lastTriggeredAt);
        long minutes = diff / 60_000L;

        if (minutes < 1L) {
            return "Triggered just now";
        }

        if (minutes < 60L) {
            return "Last triggered " + minutes + "m ago";
        }

        long hours = minutes / 60L;
        if (hours < 24L) {
            return "Last triggered " + hours + "h ago";
        }

        return "Last triggered " + (hours / 24L) + "d ago";
    }

    private boolean isValidSymbol(@NonNull String symbol) {
        if (symbol.length() < 1 || symbol.length() > 8) {
            return false;
        }

        for (int i = 0; i < symbol.length(); i++) {
            char c = symbol.charAt(i);

            if (c < 'A' || c > 'Z') {
                return false;
            }
        }

        return true;
    }

    @NonNull
    private String cleanSymbol(String value) {
        if (value == null) {
            return "";
        }

        return value.trim().toUpperCase(Locale.US);
    }

    private int dp(int value) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round(value * density);
    }
}