package com.example.yoavsproject;

import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

















public class NewsApiClient {

    private static final String HOST = AppConfig.NEWS_HOST;
    private static final String BASE_URL = AppConfig.NEWS_BASE_URL + "/search";

    private static final int CONNECT_TIMEOUT_MS = 6500;
    private static final int READ_TIMEOUT_MS = 8000;
    private static final int LIMIT = 25;

    private static final ExecutorService EXEC = Executors.newFixedThreadPool(3);
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    private NewsApiClient() {
    }

    public interface NewsCallback {
        void onSuccess(List<NewsArticle> articles);

        void onError(Exception e);
    }

    public static void fetchNewsAsync(
            @Nullable String query,
            @Nullable String timePublished,
            @Nullable NewsCallback callback
    ) {
        EXEC.execute(() -> {
            try {
                List<NewsArticle> result = fetchNews(query, timePublished);

                MAIN.post(() -> {
                    if (callback != null) {
                        callback.onSuccess(result);
                    }
                });
            } catch (Exception e) {
                MAIN.post(() -> {
                    if (callback != null) {
                        callback.onError(e);
                    }
                });
            }
        });
    }

    @NonNull
    public static List<NewsArticle> fetchNews(
            @Nullable String query,
            @Nullable String timePublished
    ) throws Exception {
        String q = normalizeQuery(query);
        String time = normalizeTime(timePublished);

        String url = buildUrl(q, time);
        String body = doGetWithFallback(url);

        return parseArticles(body);
    }

    @NonNull
    private static String buildUrl(@NonNull String query, @NonNull String timePublished) {
        StringBuilder builder = new StringBuilder(BASE_URL)
                .append("?query=")
                .append(urlencode(query))
                .append("&limit=")
                .append(LIMIT)
                .append("&country=US")
                .append("&lang=en");

        if (!TextUtils.isEmpty(timePublished) && !"anytime".equalsIgnoreCase(timePublished)) {
            builder.append("&time_published=").append(urlencode(timePublished));
        }

        return builder.toString();
    }

    @NonNull
    private static List<NewsArticle> parseArticles(@Nullable String body) throws Exception {
        List<NewsArticle> result = new ArrayList<>();

        if (TextUtils.isEmpty(body)) {
            return result;
        }

        JSONObject root = new JSONObject(body);
        JSONArray data = root.optJSONArray("data");

        if (data == null) {
            return result;
        }

        Map<String, NewsArticle> dedup = new LinkedHashMap<>();

        for (int i = 0; i < data.length(); i++) {
            JSONObject articleJson = data.optJSONObject(i);

            if (articleJson == null) {
                continue;
            }

            NewsArticle article = parseArticle(articleJson);

            if (article == null) {
                continue;
            }

            String key = getDedupKey(article);

            if (TextUtils.isEmpty(key) || dedup.containsKey(key)) {
                continue;
            }

            dedup.put(key, article);
        }

        result.addAll(dedup.values());
        return result;
    }

    @Nullable
    private static NewsArticle parseArticle(@NonNull JSONObject item) {
        String id = firstNonEmpty(
                item.optString("article_id", ""),
                item.optString("id", "")
        );

        String title = clean(item.optString("title", ""));

        if (TextUtils.isEmpty(title)) {
            return null;
        }

        String link = clean(item.optString("link", ""));
        String snippet = firstNonEmpty(
                item.optString("snippet", ""),
                item.optString("description", ""),
                item.optString("summary", "")
        );

        String sourceName = firstNonEmpty(
                item.optString("source_name", ""),
                item.optString("publisher", ""),
                item.optString("source", "")
        );

        String published = firstNonEmpty(
                item.optString("published_datetime_utc", ""),
                item.optString("published_date", ""),
                item.optString("published_at", ""),
                item.optString("date", "")
        );

        String image = cleanImageUrl(firstNonEmpty(
                item.optString("photo_url", ""),
                item.optString("thumbnail_url", ""),
                item.optString("image_url", ""),
                item.optString("urlToImage", "")
        ));

        if (TextUtils.isEmpty(id)) {
            id = !TextUtils.isEmpty(link)
                    ? String.valueOf(link.hashCode())
                    : String.valueOf(title.hashCode());
        }

        if (TextUtils.isEmpty(snippet)) {
            snippet = "Tap to read the full market story, source context and latest details.";
        }

        if (TextUtils.isEmpty(sourceName)) {
            sourceName = domainFromUrl(link);

            if (TextUtils.isEmpty(sourceName)) {
                sourceName = "Market News";
            }
        }

        return new NewsArticle(
                id,
                title,
                link,
                snippet,
                sourceName,
                published,
                image
        );
    }

    @NonNull
    private static String doGetWithFallback(@NonNull String fullUrl) throws Exception {
        Exception lastError = null;

        String[] keys = AppConfig.getNewsKeys();

        if (keys == null || keys.length == 0) {
            throw new Exception("Missing RapidAPI news key. Add a RapidAPI news key to local.properties.");
        }

        for (String key : keys) {
            String cleanKey = clean(key);

            if (TextUtils.isEmpty(cleanKey)) {
                continue;
            }

            try {
                return doGet(fullUrl, cleanKey);
            } catch (Exception e) {
                lastError = e;
            }
        }

        if (lastError != null) {
            throw lastError;
        }

        throw new Exception("All news API keys failed.");
    }

    @NonNull
    private static String doGet(@NonNull String fullUrl, @NonNull String apiKey) throws Exception {
        HttpURLConnection connection = null;
        InputStream stream = null;

        try {
            URL url = new URL(fullUrl);
            connection = (HttpURLConnection) url.openConnection();

            connection.setRequestMethod("GET");
            connection.setConnectTimeout(CONNECT_TIMEOUT_MS);
            connection.setReadTimeout(READ_TIMEOUT_MS);
            connection.setUseCaches(true);

            connection.setRequestProperty("x-rapidapi-host", HOST);
            connection.setRequestProperty("x-rapidapi-key", apiKey);
            connection.setRequestProperty("accept", "application/json");
            connection.setRequestProperty("user-agent", "YoavTrade-Android");

            int code = connection.getResponseCode();
            stream = code >= 200 && code < 300
                    ? connection.getInputStream()
                    : connection.getErrorStream();

            String response = readFully(stream);

            if (code < 200 || code >= 300) {
                throw new Exception(String.format(
                        Locale.US,
                        "News API HTTP %d - %s",
                        code,
                        response
                ));
            }

            return response;
        } finally {
            try {
                if (stream != null) {
                    stream.close();
                }
            } catch (Exception ignored) {
            }

            if (connection != null) {
                connection.disconnect();
            }
        }
    }

    @NonNull
    private static String readFully(@Nullable InputStream stream) throws Exception {
        if (stream == null) {
            return "";
        }

        BufferedReader reader = new BufferedReader(new InputStreamReader(stream));
        StringBuilder builder = new StringBuilder();

        String line;
        while ((line = reader.readLine()) != null) {
            builder.append(line);
        }

        return builder.toString();
    }

    @NonNull
    private static String normalizeQuery(@Nullable String query) {
        String clean = clean(query);

        if (TextUtils.isEmpty(clean)) {
            return "stock market finance investing earnings economy";
        }

        return clean;
    }

    @NonNull
    private static String normalizeTime(@Nullable String timePublished) {
        String clean = clean(timePublished).toLowerCase(Locale.US);

        if (TextUtils.isEmpty(clean)) {
            return "1d";
        }

        if ("any".equals(clean) || "all".equals(clean) || "anytime".equals(clean)) {
            return "anytime";
        }

        if ("1h".equals(clean)
                || "1d".equals(clean)
                || "7d".equals(clean)
                || "1m".equals(clean)
                || "1y".equals(clean)) {
            return clean;
        }

        return "1d";
    }

    @NonNull
    private static String cleanImageUrl(@Nullable String rawUrl) {
        String url = clean(rawUrl);

        if (TextUtils.isEmpty(url)) {
            return "";
        }

        String lower = url.toLowerCase(Locale.US);

        if (!lower.startsWith("http://") && !lower.startsWith("https://")) {
            return "";
        }

        return url;
    }

    @NonNull
    private static String getDedupKey(@NonNull NewsArticle article) {
        String link = clean(article.link);

        if (!TextUtils.isEmpty(link)) {
            return link.toLowerCase(Locale.US);
        }

        return clean(article.title).toLowerCase(Locale.US);
    }

    @NonNull
    private static String domainFromUrl(@Nullable String rawUrl) {
        String url = clean(rawUrl);

        if (TextUtils.isEmpty(url)) {
            return "";
        }

        try {
            String host = new URL(url).getHost();

            if (host == null) {
                return "";
            }

            host = host.toLowerCase(Locale.US).trim();

            if (host.startsWith("www.")) {
                host = host.substring(4);
            }

            if (host.startsWith("m.")) {
                host = host.substring(2);
            }

            return host;
        } catch (Exception ignored) {
            return "";
        }
    }

    @NonNull
    private static String urlencode(@Nullable String value) {
        try {
            return URLEncoder.encode(value == null ? "" : value, "UTF-8");
        } catch (Exception e) {
            return "";
        }
    }

    @NonNull
    private static String firstNonEmpty(@Nullable String... values) {
        if (values == null) {
            return "";
        }

        for (String value : values) {
            String clean = clean(value);

            if (!TextUtils.isEmpty(clean)) {
                return clean;
            }
        }

        return "";
    }

    @NonNull
    private static String clean(@Nullable String value) {
        if (value == null) {
            return "";
        }

        String clean = value.trim();

        if (clean.isEmpty()) {
            return "";
        }

        if ("null".equalsIgnoreCase(clean)
                || "none".equalsIgnoreCase(clean)
                || "undefined".equalsIgnoreCase(clean)
                || "n/a".equalsIgnoreCase(clean)) {
            return "";
        }

        return clean;
    }
}