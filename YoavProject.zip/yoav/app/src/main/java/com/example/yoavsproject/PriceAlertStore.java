package com.example.yoavsproject;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.annotation.NonNull;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.List;

public final class PriceAlertStore {

    private static final String PREFS = "yoav_price_alerts";
    private static final String KEY_ALERTS = "alerts_json";

    private PriceAlertStore() {
    }

    public static List<PriceAlert> getAlerts(@NonNull Context context) {
        List<PriceAlert> alerts = new ArrayList<>();

        SharedPreferences prefs = context.getApplicationContext()
                .getSharedPreferences(PREFS, Context.MODE_PRIVATE);

        String raw = prefs.getString(KEY_ALERTS, "[]");

        try {
            JSONArray array = new JSONArray(raw);

            for (int i = 0; i < array.length(); i++) {
                alerts.add(PriceAlert.fromJson(array.optJSONObject(i)));
            }
        } catch (Exception ignored) {
        }

        return alerts;
    }

    public static void saveAlerts(@NonNull Context context, @NonNull List<PriceAlert> alerts) {
        JSONArray array = new JSONArray();

        for (PriceAlert alert : alerts) {
            array.put(alert.toJson());
        }

        context.getApplicationContext()
                .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit()
                .putString(KEY_ALERTS, array.toString())
                .apply();
    }

    public static void addAlert(@NonNull Context context, @NonNull PriceAlert alert) {
        List<PriceAlert> alerts = getAlerts(context);
        alerts.add(alert);
        saveAlerts(context, alerts);
    }

    public static void deleteAlert(@NonNull Context context, @NonNull String alertId) {
        List<PriceAlert> alerts = getAlerts(context);
        List<PriceAlert> updated = new ArrayList<>();

        for (PriceAlert alert : alerts) {
            if (!alert.id.equals(alertId)) {
                updated.add(alert);
            }
        }

        saveAlerts(context, updated);
    }

    public static void updateAlert(@NonNull Context context, @NonNull PriceAlert updatedAlert) {
        List<PriceAlert> alerts = getAlerts(context);

        for (int i = 0; i < alerts.size(); i++) {
            if (alerts.get(i).id.equals(updatedAlert.id)) {
                alerts.set(i, updatedAlert);
                saveAlerts(context, alerts);
                return;
            }
        }

        alerts.add(updatedAlert);
        saveAlerts(context, alerts);
    }
}