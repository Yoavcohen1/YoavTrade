package com.example.yoavsproject;

import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;







public class AlphaVantageClient {

    private static final String TAG = "AlphaVantageClient";


    private static final String HOST = "alpha-vantage.p.rapidapi.com";
    private static final String BASE_URL = "https://alpha-vantage.p.rapidapi.com/query";

    private static final ExecutorService EXEC = Executors.newFixedThreadPool(1);
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    private static final long MIN_REQUEST_GAP_MS = 1800L;
    private static long lastRequestAtMs = 0L;

    private static final long QUOTE_CACHE_MS = 600000L;
    private static final long INTRADAY_CACHE_MS = 600000L;
    private static final long SEARCH_CACHE_MS = 600000L;
    private static final long DAILY_SERIES_CACHE_MS = 900000L;

    private static final Map<String, CacheEntry<StockQuote>> QUOTE_CACHE = new HashMap<>();
    private static final Map<String, CacheEntry<Double>> LAST_PRICE_CACHE = new HashMap<>();
    private static final Map<String, CacheEntry<Double>> PRICE_MINUTES_AGO_CACHE = new HashMap<>();
    private static final Map<String, CacheEntry<List<MarketStock>>> SEARCH_CACHE = new HashMap<>();
    private static final Map<String, CacheEntry<JSONObject>> JSON_CACHE = new HashMap<>();

    public interface JsonCallback {
        void onSuccess(JSONObject json);
        void onError(Exception e);
    }

    public interface PriceCallback {
        void onSuccess(double price);
        void onError(Exception e);
    }

    private static class CacheEntry<T> {
        final T value;
        final long savedAt;

        CacheEntry(T value, long savedAt) {
            this.value = value;
            this.savedAt = savedAt;
        }

        boolean isFresh(long maxAgeMs) {
            return System.currentTimeMillis() - savedAt <= maxAgeMs;
        }
    }

    public static void searchSymbolsAsync(String keywords, JsonCallback cb) {
        String params = "?datatype=json&keywords=" + urlencode(keywords) + "&function=SYMBOL_SEARCH";
        callJsonAsync(params, cb, "search:" + normalize(keywords), SEARCH_CACHE_MS);
    }

    public static List<MarketStock> searchSymbols(String keywords) {
        String cacheKey = "search:" + normalize(keywords);

        synchronized (SEARCH_CACHE) {
            CacheEntry<List<MarketStock>> entry = SEARCH_CACHE.get(cacheKey);
            if (entry != null && entry.isFresh(SEARCH_CACHE_MS)) {
                return new ArrayList<>(entry.value);
            }
        }

        try {
            String params = "?datatype=json&keywords=" + urlencode(keywords) + "&function=SYMBOL_SEARCH";
            String jsonStr = callWithFallback(params);
            JSONObject root = new JSONObject(jsonStr);
            JSONArray matches = root.optJSONArray("bestMatches");

            if (matches == null) {
                return new ArrayList<>();
            }

            List<MarketStock> out = new ArrayList<>();

            for (int i = 0; i < matches.length() && i < 10; i++) {
                JSONObject match = matches.optJSONObject(i);
                if (match == null) continue;

                String symbol = match.optString("1. symbol", "").trim();
                String name = match.optString("2. name", "").trim();

                if (symbol.isEmpty()) continue;

                out.add(new MarketStock(symbol, name.isEmpty() ? symbol : name));
            }

            synchronized (SEARCH_CACHE) {
                SEARCH_CACHE.put(cacheKey, new CacheEntry<>(new ArrayList<>(out), System.currentTimeMillis()));
            }

            return out;
        } catch (Exception e) {
            Log.w(TAG, "searchSymbols failed: " + e.getMessage());
            return null;
        }
    }

    public static void globalQuoteAsync(String symbol, JsonCallback cb) {
        String params = "?datatype=json&symbol=" + urlencode(symbol) + "&function=GLOBAL_QUOTE";
        callJsonAsync(params, cb, "global_quote:" + normalize(symbol), QUOTE_CACHE_MS);
    }

    





    public static void getDailyTimeSeriesAsync(String symbol, JsonCallback cb) {
        String params = "?datatype=json&symbol=" + urlencode(symbol)
                + "&function=TIME_SERIES_DAILY_ADJUSTED&outputsize=full";

        callJsonAsync(params, cb, "daily_adjusted_full:" + normalize(symbol), DAILY_SERIES_CACHE_MS);
    }

    public static StockQuote getQuote(String symbol) {
        String key = normalize(symbol);

        synchronized (QUOTE_CACHE) {
            CacheEntry<StockQuote> entry = QUOTE_CACHE.get(key);
            if (entry != null && entry.isFresh(QUOTE_CACHE_MS)) {
                return entry.value;
            }
        }

        try {
            String params = "?datatype=json&symbol=" + urlencode(symbol) + "&function=GLOBAL_QUOTE";
            String jsonStr = callWithFallback(params);
            JSONObject root = new JSONObject(jsonStr);

            if (!root.has("Global Quote")) {
                return null;
            }

            JSONObject quote = root.getJSONObject("Global Quote");

            String priceStr = quote.optString("05. price", "").trim();
            if (priceStr.isEmpty()) {
                return null;
            }

            double price = Double.parseDouble(priceStr);

            String pctStr = quote.optString("10. change percent", "").trim();
            double pct = 0.0;

            if (!pctStr.isEmpty()) {
                pctStr = pctStr.replace("%", "").trim();
                pct = Double.parseDouble(pctStr);
            }

            StockQuote result = new StockQuote(price, pct);

            synchronized (QUOTE_CACHE) {
                QUOTE_CACHE.put(key, new CacheEntry<>(result, System.currentTimeMillis()));
            }

            synchronized (LAST_PRICE_CACHE) {
                LAST_PRICE_CACHE.put(key, new CacheEntry<>(price, System.currentTimeMillis()));
            }

            return result;
        } catch (Exception e) {
            Log.w(TAG, "getQuote failed for " + symbol + ": " + e.getMessage());
            return null;
        }
    }

    public static Double getLastPrice(String symbol) {
        String key = normalize(symbol);

        synchronized (LAST_PRICE_CACHE) {
            CacheEntry<Double> entry = LAST_PRICE_CACHE.get(key);
            if (entry != null && entry.isFresh(QUOTE_CACHE_MS)) {
                return entry.value;
            }
        }

        StockQuote quote = getQuote(symbol);

        if (quote == null) {
            return null;
        }

        return quote.price;
    }

    public static Double getApproxPriceMinutesAgo(String symbol, int minutes) {
        String key = normalize(symbol) + ":" + minutes;

        synchronized (PRICE_MINUTES_AGO_CACHE) {
            CacheEntry<Double> entry = PRICE_MINUTES_AGO_CACHE.get(key);
            if (entry != null && entry.isFresh(INTRADAY_CACHE_MS)) {
                return entry.value;
            }
        }

        try {
            int steps = Math.max(1, Math.round(minutes / 5.0f));

            String params = "?datatype=json&symbol=" + urlencode(symbol)
                    + "&function=TIME_SERIES_INTRADAY&interval=5min&outputsize=compact";

            String jsonStr = callWithFallback(params);
            JSONObject root = new JSONObject(jsonStr);
            JSONObject series = root.optJSONObject("Time Series (5min)");

            if (series == null) {
                return null;
            }

            List<String> keys = new ArrayList<>();
            Iterator<String> iterator = series.keys();

            while (iterator.hasNext()) {
                keys.add(iterator.next());
            }

            if (keys.isEmpty()) {
                return null;
            }

            Collections.sort(keys);

            int index = Math.max(0, keys.size() - 1 - steps);
            JSONObject point = series.getJSONObject(keys.get(index));

            String close = point.optString("4. close", "").trim();
            if (close.isEmpty()) {
                return null;
            }

            Double result = Double.parseDouble(close);

            synchronized (PRICE_MINUTES_AGO_CACHE) {
                PRICE_MINUTES_AGO_CACHE.put(key, new CacheEntry<>(result, System.currentTimeMillis()));
            }

            return result;
        } catch (Exception e) {
            Log.w(TAG, "getApproxPriceMinutesAgo failed: " + e.getMessage());
            return null;
        }
    }

    public static void lastPriceAsync(String symbol, PriceCallback cb) {
        if (cb == null) {
            return;
        }

        String key = normalize(symbol);

        synchronized (LAST_PRICE_CACHE) {
            CacheEntry<Double> priceEntry = LAST_PRICE_CACHE.get(key);

            if (priceEntry != null && priceEntry.isFresh(QUOTE_CACHE_MS)) {
                cb.onSuccess(priceEntry.value);
                return;
            }
        }

        synchronized (QUOTE_CACHE) {
            CacheEntry<StockQuote> quoteEntry = QUOTE_CACHE.get(key);

            if (quoteEntry != null && quoteEntry.isFresh(QUOTE_CACHE_MS) && quoteEntry.value != null) {
                cb.onSuccess(quoteEntry.value.price);
                return;
            }
        }

        globalQuoteAsync(symbol, new JsonCallback() {
            @Override
            public void onSuccess(JSONObject root) {
                try {
                    if (!root.has("Global Quote")) {
                        cb.onError(new Exception("No Global Quote in response"));
                        return;
                    }

                    JSONObject quote = root.getJSONObject("Global Quote");
                    String priceStr = quote.optString("05. price", "");

                    if (priceStr == null || priceStr.trim().isEmpty()) {
                        cb.onError(new Exception("Missing price field"));
                        return;
                    }

                    cb.onSuccess(Double.parseDouble(priceStr));
                } catch (Exception e) {
                    cb.onError(e);
                }
            }

            @Override
            public void onError(Exception e) {
                cb.onError(e);
            }
        });
    }

    private static void callJsonAsync(String params, JsonCallback cb, String cacheKey, long cacheMs) {
        synchronized (JSON_CACHE) {
            CacheEntry<JSONObject> entry = JSON_CACHE.get(cacheKey);

            if (entry != null && entry.isFresh(cacheMs)) {
                cb.onSuccess(entry.value);
                return;
            }
        }

        EXEC.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    String jsonStr = callWithFallback(params);
                    JSONObject json = new JSONObject(jsonStr);

                    if (json.has("Error Message") || json.has("Note") || json.has("Information")) {
                        String msg = json.optString(
                                "Error Message",
                                json.optString("Note", json.optString("Information", "Alpha Vantage error"))
                        );

                        throw new Exception(msg);
                    }

                    synchronized (JSON_CACHE) {
                        JSON_CACHE.put(cacheKey, new CacheEntry<>(json, System.currentTimeMillis()));
                    }

                    MAIN.post(new Runnable() {
                        @Override
                        public void run() {
                            cb.onSuccess(json);
                        }
                    });
                } catch (Exception e) {
                    MAIN.post(new Runnable() {
                        @Override
                        public void run() {
                            cb.onError(e);
                        }
                    });
                }
            }
        });
    }

    private static synchronized void throttleBeforeRequest() {
        long now = System.currentTimeMillis();
        long waitMs = MIN_REQUEST_GAP_MS - (now - lastRequestAtMs);

        if (waitMs > 0) {
            try {
                Thread.sleep(waitMs);
            } catch (InterruptedException ignored) {
                Thread.currentThread().interrupt();
            }
        }

        lastRequestAtMs = System.currentTimeMillis();
    }

    private static String callWithFallback(String paramString) throws Exception {
        List<String> keys = getAvailableApiKeys();

        if (keys.isEmpty()) {
            throw new Exception("No RapidAPI keys found.");
        }

        Exception lastError = null;

        for (int i = 0; i < keys.size(); i++) {
            String key = keys.get(i);

            try {
                throttleBeforeRequest();

                String response = doGet(BASE_URL + paramString, key);
                JSONObject json = new JSONObject(response);

                if (json.has("Error Message") || json.has("Note") || json.has("Information")) {
                    String msg = json.optString(
                            "Error Message",
                            json.optString("Note", json.optString("Information", "Alpha Vantage error"))
                    );

                    throw new Exception(msg);
                }

                return response;
            } catch (Exception e) {
                lastError = e;

                String message = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();

                Log.w(TAG, "RapidAPI key failed (" + (i + 1) + "/" + keys.size() + "): " + message);

                if (message.contains("HTTP 429")
                        || message.toLowerCase(Locale.US).contains("limit")
                        || message.toLowerCase(Locale.US).contains("quota")
                        || message.toLowerCase(Locale.US).contains("rate")) {
                    try {
                        Thread.sleep(600L);
                    } catch (InterruptedException ignored) {
                        Thread.currentThread().interrupt();
                    }
                }
            }
        }

        throw lastError != null ? lastError : new Exception("Alpha Vantage request failed");
    }

    private static List<String> getAvailableApiKeys() {
        List<String> keys = new ArrayList<>();
        Set<String> seen = new HashSet<>();

        for (String key : AppConfig.getAlphaVantageKeys()) {
            if (key == null) continue;

            String clean = key.trim();

            if (clean.isEmpty()) continue;
            if (clean.equalsIgnoreCase("null")) continue;
            if (seen.contains(clean)) continue;

            seen.add(clean);
            keys.add(clean);
        }

        return keys;
    }

    private static String doGet(String fullUrl, String apiKey) throws Exception {
        HttpURLConnection conn = null;
        InputStream inputStream = null;

        try {
            URL url = new URL(fullUrl);

            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(12000);
            conn.setReadTimeout(18000);

            conn.setRequestProperty("x-rapidapi-host", HOST);
            conn.setRequestProperty("x-rapidapi-key", apiKey);
            conn.setRequestProperty("accept", "application/json");

            int code = conn.getResponseCode();

            try {
                inputStream = (code >= 200 && code < 300)
                        ? conn.getInputStream()
                        : conn.getErrorStream();
            } catch (Exception ignored) {
                inputStream = conn.getErrorStream();
            }

            String body = readFully(inputStream);

            if (code < 200 || code >= 300) {
                throw new Exception("HTTP " + code + (body.isEmpty() ? "" : " - " + body));
            }

            if (body.trim().isEmpty()) {
                throw new Exception("Empty response from Alpha Vantage");
            }

            return body;
        } finally {
            try {
                if (inputStream != null) {
                    inputStream.close();
                }
            } catch (Exception ignored) {
            }

            if (conn != null) {
                conn.disconnect();
            }
        }
    }

    private static String readFully(InputStream inputStream) throws Exception {
        if (inputStream == null) {
            return "";
        }

        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream, StandardCharsets.UTF_8));
        StringBuilder builder = new StringBuilder();

        String line;
        while ((line = reader.readLine()) != null) {
            builder.append(line);
        }

        return builder.toString();
    }

    private static String urlencode(String value) {
        try {
            return URLEncoder.encode(value == null ? "" : value, "UTF-8");
        } catch (Exception e) {
            return "";
        }
    }

    private static String normalize(String value) {
        return value == null ? "" : value.trim().toUpperCase(Locale.US);
    }
}