package com.example.yoavsproject;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public final class EmailCorrectionUtil {

    private static final Map<String, String> DOMAIN_FIXES = new HashMap<>();
    private static final Map<String, String> TLD_FIXES = new HashMap<>();

    static {
        DOMAIN_FIXES.put("gmeil", "gmail");
        DOMAIN_FIXES.put("gmial", "gmail");
        DOMAIN_FIXES.put("gmai", "gmail");
        DOMAIN_FIXES.put("gmil", "gmail");
        DOMAIN_FIXES.put("gmal", "gmail");
        DOMAIN_FIXES.put("gnail", "gmail");
        DOMAIN_FIXES.put("gmail", "gmail");

        DOMAIN_FIXES.put("hotmial", "hotmail");
        DOMAIN_FIXES.put("hotmai", "hotmail");
        DOMAIN_FIXES.put("hotmal", "hotmail");
        DOMAIN_FIXES.put("hotnail", "hotmail");
        DOMAIN_FIXES.put("hotmail", "hotmail");

        DOMAIN_FIXES.put("outlok", "outlook");
        DOMAIN_FIXES.put("outloo", "outlook");
        DOMAIN_FIXES.put("outlook", "outlook");

        DOMAIN_FIXES.put("yaho", "yahoo");
        DOMAIN_FIXES.put("yahho", "yahoo");
        DOMAIN_FIXES.put("yahoo", "yahoo");

        TLD_FIXES.put("con", "com");
        TLD_FIXES.put("cim", "com");
        TLD_FIXES.put("cmo", "com");
        TLD_FIXES.put("cm", "com");
        TLD_FIXES.put("coom", "com");
        TLD_FIXES.put("comm", "com");

        TLD_FIXES.put("ney", "net");
        TLD_FIXES.put("nett", "net");
    }

    private EmailCorrectionUtil() {
    }

    @NonNull
    public static String correct(@Nullable String rawEmail) {
        if (rawEmail == null) {
            return "";
        }

        String email = rawEmail.trim().replace(" ", "").toLowerCase(Locale.US);

        int at = email.indexOf("@");

        if (at <= 0 || at != email.lastIndexOf("@") || at >= email.length() - 1) {
            return email;
        }

        String local = email.substring(0, at);
        String domain = email.substring(at + 1);

        String correctedDomain = correctDomain(domain);

        return local + "@" + correctedDomain;
    }

    public static boolean wasCorrected(@Nullable String original, @Nullable String corrected) {
        String safeOriginal = original == null ? "" : original.trim().replace(" ", "").toLowerCase(Locale.US);
        String safeCorrected = corrected == null ? "" : corrected.trim().replace(" ", "").toLowerCase(Locale.US);
        return !safeOriginal.equals(safeCorrected);
    }

    @NonNull
    private static String correctDomain(@NonNull String domain) {
        String clean = domain.trim().toLowerCase(Locale.US);

        if (clean.isEmpty()) {
            return clean;
        }

        String[] parts = clean.split("\\.");

        if (parts.length == 0) {
            return clean;
        }

        String host = parts[0];
        String fixedHost = DOMAIN_FIXES.containsKey(host) ? DOMAIN_FIXES.get(host) : host;

        String tld = parts.length > 1 ? parts[parts.length - 1] : "";
        String fixedTld = TLD_FIXES.containsKey(tld) ? TLD_FIXES.get(tld) : tld;

        if ("gmail".equals(fixedHost) && (fixedTld.isEmpty() || "co".equals(fixedTld))) {
            fixedTld = "com";
        }

        if ("hotmail".equals(fixedHost) && fixedTld.isEmpty()) {
            fixedTld = "com";
        }

        if ("outlook".equals(fixedHost) && fixedTld.isEmpty()) {
            fixedTld = "com";
        }

        if ("yahoo".equals(fixedHost) && fixedTld.isEmpty()) {
            fixedTld = "com";
        }

        if (parts.length == 1) {
            return fixedTld.isEmpty() ? fixedHost : fixedHost + "." + fixedTld;
        }

        StringBuilder builder = new StringBuilder();
        builder.append(fixedHost);

        for (int i = 1; i < parts.length - 1; i++) {
            String part = parts[i];

            if (part == null || part.trim().isEmpty()) {
                continue;
            }

            builder.append(".").append(part.trim().toLowerCase(Locale.US));
        }

        if (!fixedTld.isEmpty()) {
            builder.append(".").append(fixedTld);
        }

        return builder.toString();
    }
}
