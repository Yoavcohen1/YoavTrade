package com.example.yoavsproject;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.InputType;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

















public class LoginActivity extends AppCompatActivity {

    private EditText etEmail;
    private EditText etPassword;

    private Button btnLogin;

    private TextView tvForgotPassword;
    private TextView tvGoToRegister;

    private FirebaseAuth auth;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        AppSettingsManager.applySavedUi(this);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        auth = FirebaseAuth.getInstance();

        bindViews();
        setupClicks();
    }

    private void bindViews() {
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);

        btnLogin = findViewById(R.id.btnLogin);

        tvForgotPassword = findViewById(R.id.tvForgotPassword);
        tvGoToRegister = findViewById(R.id.tvGoToRegister);
    }

    private void setupClicks() {
        setupPasswordToggle(etPassword, R.drawable.ic_register_lock);

        if (btnLogin != null) {
            btnLogin.setOnClickListener(v -> attemptLogin());
        }

        if (tvGoToRegister != null) {
            tvGoToRegister.setOnClickListener(v -> {
                Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(intent);
                finish();
            });
        }

        if (etEmail != null) {
            etEmail.setOnFocusChangeListener((v, hasFocus) -> {
                if (!hasFocus && etEmail.getText() != null) {
                    String original = etEmail.getText().toString();
                    String corrected = EmailCorrectionUtil.correct(original);
                    if (EmailCorrectionUtil.wasCorrected(original, corrected)) {
                        etEmail.setText(corrected);
                        etEmail.setSelection(etEmail.getText().length());
                    }
                }
            });
        }

        if (tvForgotPassword != null) {
            tvForgotPassword.setOnClickListener(v -> {
                Intent intent = new Intent(LoginActivity.this, ForgotPasswordActivity.class);
                startActivity(intent);
            });
        }
    }

    private void attemptLogin() {
        String originalEmail = safeText(etEmail);
        String email = EmailCorrectionUtil.correct(originalEmail);

        if (etEmail != null && EmailCorrectionUtil.wasCorrected(originalEmail, email)) {
            etEmail.setText(email);
            etEmail.setSelection(etEmail.getText().length());
        }
        String password = safeText(etPassword);

        if (TextUtils.isEmpty(email) || !Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            etEmail.setError("Enter valid email");
            etEmail.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(password)) {
            etPassword.setError("Enter password");
            etPassword.requestFocus();
            return;
        }

        setLoginLoading(true);

        auth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(task -> {
                    if (!task.isSuccessful()) {
                        setLoginLoading(false);

                        String message = task.getException() != null
                                ? task.getException().getMessage()
                                : "Login failed";

                        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
                        return;
                    }

                    FirebaseUser user = auth.getCurrentUser();

                    if (user == null) {
                        setLoginLoading(false);
                        Toast.makeText(this, "Login failed", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    routeAfterLogin(user);
                });
    }

    private void routeAfterLogin(FirebaseUser user) {
        user.reload().addOnCompleteListener(reloadTask -> {
            setLoginLoading(false);

            FirebaseUser reloadedUser = auth.getCurrentUser();

            if (reloadedUser == null) {
                Toast.makeText(this, "Login failed", Toast.LENGTH_SHORT).show();
                return;
            }

            AppSettingsManager.syncSettingsForCurrentUser(this);

            if (requiresEmailVerification(reloadedUser)) {
                maybeSendVerificationEmail(reloadedUser);
                openEmailVerification();
                return;
            }

            openDashboard();
        });
    }

    private boolean requiresEmailVerification(FirebaseUser user) {
        if (user == null) {
            return true;
        }

        String email = user.getEmail();

        if (email == null || email.trim().isEmpty()) {
            return false;
        }

        return !user.isEmailVerified();
    }

    private void maybeSendVerificationEmail(FirebaseUser user) {
        if (user == null || user.isEmailVerified()) {
            return;
        }

        try {
            user.sendEmailVerification();
        } catch (Exception ignored) {
        }
    }

    private void openEmailVerification() {
        Intent intent = new Intent(this, EmailVerificationActivity.class);
        intent.putExtra(EmailVerificationActivity.EXTRA_AFTER_VERIFY_TO_WELCOME, false);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    private void openDashboard() {
        Intent intent = new Intent(this, TradingDashboardActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    private void setLoginLoading(boolean loading) {
        if (btnLogin == null) {
            return;
        }

        btnLogin.setEnabled(!loading);
        btnLogin.setText(loading ? "Checking..." : "Login");
        btnLogin.setAlpha(loading ? 0.65f : 1.0f);
    }

    private void setupPasswordToggle(EditText editText, int startIcon) {
        if (editText == null) {
            return;
        }

        final boolean[] passwordVisible = new boolean[]{false};

        applyPasswordState(editText, false, startIcon);

        editText.post(() -> {
            passwordVisible[0] = false;
            applyPasswordState(editText, false, startIcon);
        });

        editText.setOnTouchListener((view, event) -> {
            if (event.getAction() != MotionEvent.ACTION_UP) {
                return false;
            }

            if (!didTapPasswordEye(editText, event)) {
                return false;
            }

            passwordVisible[0] = !passwordVisible[0];
            applyPasswordState(editText, passwordVisible[0], startIcon);

            return true;
        });
    }

    private void applyPasswordState(EditText editText, boolean visible, int startIcon) {
        if (editText == null) {
            return;
        }

        int selection = safeSelection(editText);

        editText.setSingleLine(true);
        editText.setInputType(InputType.TYPE_CLASS_TEXT
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
                | (visible
                ? InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                : InputType.TYPE_TEXT_VARIATION_PASSWORD));

        editText.setTransformationMethod(visible
                ? null
                : BulletPasswordTransformationMethod.getInstance());

        int icon = visible ? R.drawable.ic_eye_show : R.drawable.ic_eye_hide;

        editText.setCompoundDrawablePadding(dp(10));
        editText.setCompoundDrawablesRelativeWithIntrinsicBounds(
                startIcon,
                0,
                icon,
                0
        );

        restoreSelection(editText, selection);
    }

    private boolean didTapPasswordEye(EditText editText, MotionEvent event) {
        if (editText == null) {
            return false;
        }

        Drawable eye = editText.getCompoundDrawablesRelative()[2];

        if (eye == null) {
            eye = editText.getCompoundDrawables()[2];
        }

        if (eye == null) {
            return false;
        }

        int drawableWidth = Math.max(eye.getIntrinsicWidth(), dp(24));
        int touchArea = dp(34);

        if (editText.getLayoutDirection() == View.LAYOUT_DIRECTION_RTL) {
            return event.getX() <= editText.getPaddingLeft() + drawableWidth + touchArea;
        }

        return event.getX() >= editText.getWidth()
                - editText.getPaddingRight()
                - drawableWidth
                - touchArea;
    }

    private int safeSelection(EditText editText) {
        int selection = editText.getSelectionStart();

        if (selection < 0) {
            return editText.getText() == null ? 0 : editText.getText().length();
        }

        return selection;
    }

    private void restoreSelection(EditText editText, int selection) {
        int length = editText.getText() == null ? 0 : editText.getText().length();

        if (selection < 0 || selection > length) {
            selection = length;
        }

        editText.setSelection(selection);
    }

    private static final class BulletPasswordTransformationMethod extends PasswordTransformationMethod {
        private static final BulletPasswordTransformationMethod INSTANCE =
                new BulletPasswordTransformationMethod();

        public static BulletPasswordTransformationMethod getInstance() {
            return INSTANCE;
        }

        @Override
        public CharSequence getTransformation(CharSequence source, View view) {
            return new BulletPasswordCharSequence(source);
        }

        private static final class BulletPasswordCharSequence implements CharSequence {
            private final CharSequence source;

            BulletPasswordCharSequence(CharSequence source) {
                this.source = source == null ? "" : source;
            }

            @Override
            public int length() {
                return source.length();
            }

            @Override
            public char charAt(int index) {
                return '•';
            }

            @Override
            public CharSequence subSequence(int start, int end) {
                StringBuilder builder = new StringBuilder();

                for (int i = start; i < end; i++) {
                    builder.append('•');
                }

                return builder.toString();
            }

            @Override
            public String toString() {
                StringBuilder builder = new StringBuilder();

                for (int i = 0; i < source.length(); i++) {
                    builder.append('•');
                }

                return builder.toString();
            }
        }
    }

    private String safeText(EditText editText) {
        return editText == null || editText.getText() == null
                ? ""
                : editText.getText().toString().trim();
    }

    private int dp(int value) {
        return Math.round(getResources().getDisplayMetrics().density * value);
    }
}