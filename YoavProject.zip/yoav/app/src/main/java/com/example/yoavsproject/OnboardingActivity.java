package com.example.yoavsproject;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.viewpager2.widget.ViewPager2;

import java.util.ArrayList;
import java.util.List;

public class OnboardingActivity extends AppCompatActivity {

    private static final String PREFS_NAME = "yoav_app_start";
    private static final String KEY_ONBOARDING_SEEN = "onboarding_seen";

    private ViewPager2 viewPager;
    private LinearLayout layoutDots;
    private TextView btnSkip;
    private Button btnNext;
    private Button btnGetStarted;

    private List<OnboardingSlide> slides;
    private TextView[] dots;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        AppSettingsManager.applySavedUi(this);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_onboarding);

        bindViews();
        setupSlides();
        setupViewPager();
        setupClicks();

        setupDots(0);
        updateButtons(0);
    }

    private void bindViews() {
        viewPager = findViewById(R.id.viewPager);
        layoutDots = findViewById(R.id.layoutDots);
        btnSkip = findViewById(R.id.btnSkip);
        btnNext = findViewById(R.id.btnNext);
        btnGetStarted = findViewById(R.id.btnGetStarted);
    }

    private void setupSlides() {
        slides = new ArrayList<>();

        slides.add(new OnboardingSlide(
                R.drawable.welcome_image1,
                "Welcome to YoavTrade",
                "Start your trading journey with a clean portfolio, market data, charts and stock discovery."
        ));

        slides.add(new OnboardingSlide(
                R.drawable.welcome_image2,
                "Track stocks in real time",
                "Follow your favorite companies, watch price movement, and stay updated with market changes."
        ));

        slides.add(new OnboardingSlide(
                R.drawable.welcome_image3,
                "Build your portfolio",
                "Buy, sell, manage your balance, set price alerts, and follow financial news in one place."
        ));
    }

    private void setupViewPager() {
        if (viewPager == null) {
            return;
        }

        viewPager.setAdapter(new OnboardingAdapter(slides));

        viewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                setupDots(position);
                updateButtons(position);
            }
        });
    }

    private void setupClicks() {
        if (btnSkip != null) {
            btnSkip.setOnClickListener(v -> {
                if (viewPager != null && slides != null && !slides.isEmpty()) {
                    viewPager.setCurrentItem(slides.size() - 1, true);
                }
            });
        }

        if (btnNext != null) {
            btnNext.setOnClickListener(v -> {
                if (viewPager == null || slides == null || slides.isEmpty()) {
                    return;
                }

                int nextPosition = viewPager.getCurrentItem() + 1;

                if (nextPosition < slides.size()) {
                    viewPager.setCurrentItem(nextPosition, true);
                } else {
                    finishOnboardingAndOpenAuth();
                }
            });
        }

        if (btnGetStarted != null) {
            btnGetStarted.setOnClickListener(v -> finishOnboardingAndOpenAuth());
        }
    }

    private void setupDots(int current) {
        if (layoutDots == null || slides == null) {
            return;
        }

        layoutDots.removeAllViews();
        dots = new TextView[slides.size()];

        for (int i = 0; i < dots.length; i++) {
            dots[i] = new TextView(this);
            dots[i].setText("•");
            dots[i].setTextSize(40);
            dots[i].setTextColor(
                    i == current
                            ? Color.parseColor("#315DFF")
                            : Color.parseColor("#3A465D")
            );

            layoutDots.addView(dots[i]);
        }
    }

    private void updateButtons(int position) {
        if (slides == null || slides.isEmpty()) {
            return;
        }

        boolean isLast = position == slides.size() - 1;

        if (btnSkip != null) {
            btnSkip.setVisibility(isLast ? View.INVISIBLE : View.VISIBLE);
        }

        if (btnNext != null) {
            btnNext.setVisibility(isLast ? View.INVISIBLE : View.VISIBLE);
        }

        if (btnGetStarted != null) {
            btnGetStarted.setVisibility(isLast ? View.VISIBLE : View.GONE);
        }
    }

    private void finishOnboardingAndOpenAuth() {
        markOnboardingSeen();

        Intent intent = new Intent(OnboardingActivity.this, AuthChoiceActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    private void markOnboardingSeen() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        prefs.edit()
                .putBoolean(KEY_ONBOARDING_SEEN, true)
                .apply();
    }
}