package com.example.yoavsproject;

import android.os.Handler;
import android.os.Looper;

import java.text.DateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;




public class StockAiContextBuilder {

    public interface Callback {
        void onReady(String context);
        void onError(Exception e);
    }

    private static final ExecutorService EXEC = Executors.newSingleThreadExecutor();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static String cache;
    private static long cacheAt;

    public static void build(final Callback cb) {
        if (cb == null) return;

        if (cache != null && System.currentTimeMillis() - cacheAt < 60000L) {
            cb.onReady(cache);
            return;
        }

        PortfolioManager.getInstance().fetchPortfolio(new PortfolioManager.PortfolioCallback() {
            @Override
            public void onResult(final PortfolioManager.Portfolio portfolio, final String errorMessage) {
                EXEC.execute(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            final String ctx = buildInternal(portfolio, errorMessage);
                            cache = ctx;
                            cacheAt = System.currentTimeMillis();
                            MAIN.post(new Runnable() {
                                @Override
                                public void run() {
                                    cb.onReady(ctx);
                                }
                            });
                        } catch (final Exception e) {
                            MAIN.post(new Runnable() {
                                @Override
                                public void run() {
                                    cb.onError(e);
                                }
                            });
                        }
                    }
                });
            }
        });
    }

    private static String buildInternal(PortfolioManager.Portfolio portfolio, String errorMessage) {
        StringBuilder sb = new StringBuilder();

        sb.append("Time: ")
                .append(DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(new Date()))
                .append("\n\n");

        appendPortfolioContext(sb, portfolio, errorMessage);
        appendArticleContext(sb);

        return sb.toString().trim();
    }

    private static void appendPortfolioContext(StringBuilder sb, PortfolioManager.Portfolio portfolio, String errorMessage) {
        sb.append("PORTFOLIO CONTEXT:\n");

        if (portfolio == null) {
            sb.append("Portfolio unavailable: ")
                    .append(errorMessage == null ? "unknown error" : errorMessage)
                    .append("\n");
            return;
        }

        sb.append("Cash balance: $")
                .append(String.format(Locale.US, "%,.2f", portfolio.cashBalance))
                .append("\n");

        if (portfolio.holdings == null || portfolio.holdings.isEmpty()) {
            sb.append("Holdings: none\n");
        } else {
            sb.append("Holdings:\n");
            int limit = Math.min(10, portfolio.holdings.size());
            for (int i = 0; i < limit; i++) {
                PortfolioManager.Holding h = portfolio.holdings.get(i);
                if (h == null || h.symbol == null || h.symbol.trim().isEmpty()) continue;
                sb.append("- ")
                        .append(h.symbol.toUpperCase(Locale.US))
                        .append(": qty ")
                        .append(String.format(Locale.US, "%.2f", h.quantity))
                        .append(", avg buy $")
                        .append(String.format(Locale.US, "%,.2f", h.avgBuyPrice))
                        .append("\n");
            }
        }
    }

    private static void appendArticleContext(StringBuilder sb) {
        List<NewsArticle> articles = App.getLatestDiscoverArticles();

        sb.append("\nCACHED DISCOVER ARTICLES FOR AI DISCUSSION:\n");

        if (articles == null || articles.isEmpty()) {
            sb.append("No recent articles are currently cached in memory. If the user asks for an article, the assistant screen may fetch one directly.\n");
            return;
        }

        sb.append("Use these articles when the user asks about news, headlines, recent articles, market events, sectors, or stock ideas.\n");
        sb.append("Do not tell the user to tap on an article. Discuss the articles directly inside the chat.\n\n");

        int limit = Math.min(8, articles.size());
        for (int i = 0; i < limit; i++) {
            NewsArticle a = articles.get(i);
            if (a == null) continue;

            String title = clean(NewsArticleCompatUtil.getTitle(a));
            String source = clean(NewsArticleCompatUtil.getSource(a));
            String body = clean(NewsArticleCompatUtil.getBody(a));
            String link = clean(NewsArticleCompatUtil.getLink(a));

            if (title.isEmpty() && body.isEmpty()) continue;

            if (body.length() > 900) {
                body = body.substring(0, 900) + "...";
            }

            sb.append("Article ").append(i + 1).append(":\n");
            if (!title.isEmpty()) sb.append("Title: ").append(title).append("\n");
            if (!source.isEmpty()) sb.append("Source: ").append(source).append("\n");
            if (!body.isEmpty()) sb.append("Snippet: ").append(body).append("\n");
            if (!link.isEmpty()) sb.append("Link available: yes\n");
            sb.append("\n");
        }
    }

    private static String clean(String value) {
        if (value == null) return "";
        String clean = value.trim();
        if (clean.equalsIgnoreCase("null")
                || clean.equalsIgnoreCase("none")
                || clean.equalsIgnoreCase("undefined")
                || clean.equalsIgnoreCase("n/a")) {
            return "";
        }
        return clean;
    }
}
