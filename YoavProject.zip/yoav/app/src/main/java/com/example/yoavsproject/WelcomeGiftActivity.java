package com.example.yoavsproject;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class WelcomeGiftActivity extends AppCompatActivity {

    private static final double STARTER_BALANCE = 10000.0;

    private TextView tvWelcomeTitle;
    private TextView tvWelcomeMessage;
    private TextView tvWelcomeAmount;
    private TextView btnStartTrading;

    private FirebaseAuth auth;
    private FirebaseFirestore db;

    private boolean savingGift = false;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        AppSettingsManager.applySavedUi(this);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome_gift);

        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        auth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        if (!ensureVerifiedUser()) {
            return;
        }

        bindViews();
        setupScreenText();
        setupClicks();
    }


    private boolean ensureVerifiedUser() {
        FirebaseUser user = auth.getCurrentUser();

        if (user == null) {
            openAuthChoice();
            return false;
        }

        if (user.getEmail() != null && !user.isEmailVerified()) {
            Intent intent = new Intent(this, EmailVerificationActivity.class);
            intent.putExtra(EmailVerificationActivity.EXTRA_AFTER_VERIFY_TO_WELCOME, true);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
            return false;
        }

        return true;
    }

    private void bindViews() {
        tvWelcomeTitle = findViewById(R.id.tvWelcomeTitle);
        tvWelcomeMessage = findViewById(R.id.tvWelcomeMessage);
        tvWelcomeAmount = findViewById(R.id.tvWelcomeAmount);
        btnStartTrading = findViewById(R.id.btnStartTrading);
    }

    private void setupScreenText() {
        if (tvWelcomeTitle != null) {
            tvWelcomeTitle.setText("Welcome to YoavTrade!");
        }

        if (tvWelcomeAmount != null) {
            tvWelcomeAmount.setText(formatMoney(STARTER_BALANCE));
        }

        if (tvWelcomeMessage != null) {
            tvWelcomeMessage.setText(
                    "Your starter balance is ready. Use it to explore stocks, build your portfolio, and practice trading."
            );
        }

        if (btnStartTrading != null) {
            btnStartTrading.setText("Start trading");
        }
    }

    private void setupClicks() {
        if (btnStartTrading != null) {
            btnStartTrading.setOnClickListener(v -> saveWelcomeGiftAndContinue());
        }
    }

    private void saveWelcomeGiftAndContinue() {
        if (savingGift) {
            return;
        }

        FirebaseUser user = auth.getCurrentUser();

        if (user == null) {
            Toast.makeText(this, "Please sign in again", Toast.LENGTH_SHORT).show();
            openAuthChoice();
            return;
        }

        savingGift = true;
        setButtonLoading(true);

        Map<String, Object> patch = new HashMap<>();
        patch.put("cashBalance", STARTER_BALANCE);
        patch.put("availableCash", STARTER_BALANCE);
        patch.put("availableBalance", STARTER_BALANCE);
        patch.put("buyingPower", STARTER_BALANCE);
        patch.put("balance", STARTER_BALANCE);
        patch.put("welcomeGiftClaimed", true);
        patch.put("welcomeGiftAmount", STARTER_BALANCE);
        patch.put("welcomeGiftClaimedAt", System.currentTimeMillis());

        db.collection("users")
                .document(user.getUid())
                .set(patch, SetOptions.merge())
                .addOnSuccessListener(unused -> {
                    savingGift = false;
                    setButtonLoading(false);
                    openDashboard();
                })
                .addOnFailureListener(e -> {
                    savingGift = false;
                    setButtonLoading(false);

                    String message = e.getMessage() == null
                            ? "Could not add starter balance"
                            : e.getMessage();

                    Toast.makeText(this, message, Toast.LENGTH_LONG).show();
                });
    }

    private void setButtonLoading(boolean loading) {
        if (btnStartTrading == null) {
            return;
        }

        btnStartTrading.setEnabled(!loading);
        btnStartTrading.setAlpha(loading ? 0.65f : 1.0f);
        btnStartTrading.setText(loading ? "Adding money..." : "Start trading");
    }

    private void openDashboard() {
        Intent intent = new Intent(this, TradingDashboardActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
        overridePendingTransition(0, 0);
    }

    private void openAuthChoice() {
        Intent intent = new Intent(this, AuthChoiceActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
        overridePendingTransition(0, 0);
    }

    private String formatMoney(double value) {
        return String.format(Locale.US, "$%,.0f", value);
    }
}