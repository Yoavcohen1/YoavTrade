package com.example.yoavsproject;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.util.Base64;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatDelegate;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public final class AppSettingsManager {

    private static final String SETTINGS_PREFS = "yoav_app_settings";
    private static final String PROFILE_PREFS = "yoav_profile_prefs";

    private static final String KEY_DISPLAY_NAME = "display_name";
    private static final String KEY_EMAIL = "email";
    private static final String KEY_PROFILE_PHOTO_BASE64 = "profile_photo_base64";
    private static final String KEY_PREFERRED_CURRENCY = "preferred_currency";

    private static final String KEY_PRICE_ALERTS_ENABLED = "price_alerts_enabled";
    private static final String KEY_NEWS_ALERTS_ENABLED = "news_alerts_enabled";

    private AppSettingsManager() {
    }

    public interface MoneyFormatCallback {
        void onFormatted(String formatted);
    }

    public static void applySavedUi(@NonNull Context context) {
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
    }

    public static void forceDarkMode() {
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
    }

    public static void saveProfileLocal(
            @NonNull Context context,
            @Nullable String displayName,
            @Nullable String email,
            @Nullable String photoBase64
    ) {
        getProfilePrefs(context)
                .edit()
                .putString(KEY_DISPLAY_NAME, safe(displayName))
                .putString(KEY_EMAIL, safe(email))
                .putString(KEY_PROFILE_PHOTO_BASE64, safe(photoBase64))
                .apply();
    }

    public static String getLocalDisplayName(@NonNull Context context) {
        return getProfilePrefs(context).getString(KEY_DISPLAY_NAME, "");
    }

    public static String getLocalEmail(@NonNull Context context) {
        return getProfilePrefs(context).getString(KEY_EMAIL, "");
    }

    public static String getLocalProfilePhotoBase64(@NonNull Context context) {
        return getProfilePrefs(context).getString(KEY_PROFILE_PHOTO_BASE64, "");
    }

    public static void savePreferredCurrencyQuick(@NonNull Context context, @Nullable String currency) {
        String normalized = normalizeCurrency(currency);

        getSettingsPrefs(context)
                .edit()
                .putString(KEY_PREFERRED_CURRENCY, normalized)
                .apply();

        savePreferredCurrencyToFirebase(normalized);
    }

    public static String getLocalPreferredCurrency(@NonNull Context context) {
        String value = getSettingsPrefs(context).getString(KEY_PREFERRED_CURRENCY, "USD");
        return normalizeCurrency(value);
    }

    public static String normalizeCurrency(@Nullable String currency) {
        if (currency == null || currency.trim().isEmpty()) {
            return "USD";
        }

        String clean = currency.trim().toUpperCase(Locale.US);

        if ("EUR".equals(clean)) {
            return "EUR";
        }

        if ("ILS".equals(clean) || "NIS".equals(clean)) {
            return "ILS";
        }

        return "USD";
    }

    public static String getCurrencySymbol(@Nullable String currency) {
        String clean = normalizeCurrency(currency);

        if ("EUR".equals(clean)) {
            return "€";
        }

        if ("ILS".equals(clean)) {
            return "₪";
        }

        return "$";
    }

    public static String getCurrencyDisplay(@Nullable String currency) {
        String clean = normalizeCurrency(currency);
        return getCurrencySymbol(clean) + " " + clean;
    }

    public static double getUsdToSelectedCurrencyRate(@NonNull Context context) {
        String currency = getLocalPreferredCurrency(context);

        if ("EUR".equals(currency)) {
            return 0.92;
        }

        if ("ILS".equals(currency)) {
            return 3.65;
        }

        return 1.0;
    }

    public static double convertUsdToSelectedCurrency(@NonNull Context context, double usdAmount) {
        return usdAmount * getUsdToSelectedCurrencyRate(context);
    }

    public static String formatMoney(@NonNull Context context, double amount) {
        String currency = getLocalPreferredCurrency(context);
        return getCurrencySymbol(currency) + String.format(Locale.US, "%,.2f", amount);
    }

    public static String formatMoney(@Nullable String currency, double amount) {
        String clean = normalizeCurrency(currency);
        return getCurrencySymbol(clean) + String.format(Locale.US, "%,.2f", amount);
    }

    public static String formatUsdAmount(@NonNull Context context, double usdAmount) {
        String currency = getLocalPreferredCurrency(context);
        double converted = convertUsdToSelectedCurrency(context, usdAmount);
        return getCurrencySymbol(currency) + String.format(Locale.US, "%,.2f", converted);
    }

    public static void formatUsdAmountAsync(
            @NonNull Context context,
            double usdAmount,
            @Nullable MoneyFormatCallback callback
    ) {
        String formatted = formatUsdAmount(context, usdAmount);

        if (callback != null) {
            callback.onFormatted(formatted);
        }
    }

    public static boolean arePriceAlertsEnabled(@NonNull Context context) {
        return getSettingsPrefs(context).getBoolean(KEY_PRICE_ALERTS_ENABLED, false);
    }

    public static void savePriceAlertsEnabled(@NonNull Context context, boolean enabled) {
        getSettingsPrefs(context)
                .edit()
                .putBoolean(KEY_PRICE_ALERTS_ENABLED, enabled)
                .apply();

        saveBooleanSettingToFirebase("priceAlertsEnabled", enabled);
    }

    public static boolean areNewsAlertsEnabled(@NonNull Context context) {
        return getSettingsPrefs(context).getBoolean(KEY_NEWS_ALERTS_ENABLED, false);
    }

    public static void saveNewsAlertsEnabled(@NonNull Context context, boolean enabled) {
        getSettingsPrefs(context)
                .edit()
                .putBoolean(KEY_NEWS_ALERTS_ENABLED, enabled)
                .apply();

        saveBooleanSettingToFirebase("newsAlertsEnabled", enabled);
    }

    public static Bitmap decodeBase64ToBitmap(@Nullable String base64) {
        if (base64 == null || base64.trim().isEmpty()) {
            return null;
        }

        try {
            byte[] decoded = Base64.decode(base64, Base64.DEFAULT);
            return BitmapFactory.decodeByteArray(decoded, 0, decoded.length);
        } catch (Exception e) {
            return null;
        }
    }

    public static String encodeImageUriToBase64(@NonNull Context context, @NonNull Uri uri) {
        InputStream inputStream = null;

        try {
            inputStream = context.getContentResolver().openInputStream(uri);

            if (inputStream == null) {
                return "";
            }

            Bitmap bitmap = BitmapFactory.decodeStream(inputStream);

            if (bitmap == null) {
                return "";
            }

            Bitmap resized = resizeBitmap(bitmap, 512);

            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            resized.compress(Bitmap.CompressFormat.JPEG, 85, outputStream);

            byte[] bytes = outputStream.toByteArray();

            return Base64.encodeToString(bytes, Base64.DEFAULT);
        } catch (Exception e) {
            return "";
        } finally {
            try {
                if (inputStream != null) {
                    inputStream.close();
                }
            } catch (Exception ignored) {
            }
        }
    }

    private static Bitmap resizeBitmap(@NonNull Bitmap bitmap, int maxSize) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();

        if (width <= maxSize && height <= maxSize) {
            return bitmap;
        }

        float ratio = Math.min((float) maxSize / width, (float) maxSize / height);

        int newWidth = Math.round(width * ratio);
        int newHeight = Math.round(height * ratio);

        return Bitmap.createScaledBitmap(bitmap, newWidth, newHeight, true);
    }

    public static void syncSettingsForCurrentUser(@NonNull Context context) {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();

        if (user == null) {
            return;
        }

        FirebaseFirestore.getInstance()
                .collection("users")
                .document(user.getUid())
                .get()
                .addOnSuccessListener(snapshot -> {
                    String displayName = firstNonEmpty(
                            snapshot.getString("displayName"),
                            snapshot.getString("fullName"),
                            user.getDisplayName(),
                            getLocalDisplayName(context)
                    );

                    String email = firstNonEmpty(
                            user.getEmail(),
                            snapshot.getString("email"),
                            getLocalEmail(context)
                    );

                    String photoBase64 = firstNonEmpty(
                            snapshot.getString("profilePhotoBase64"),
                            getLocalProfilePhotoBase64(context)
                    );

                    String currency = normalizeCurrency(firstNonEmpty(
                            snapshot.getString("preferredCurrency"),
                            getLocalPreferredCurrency(context)
                    ));

                    Boolean priceAlerts = snapshot.getBoolean("priceAlertsEnabled");
                    Boolean newsAlerts = snapshot.getBoolean("newsAlertsEnabled");

                    saveProfileLocal(context, displayName, email, photoBase64);

                    getSettingsPrefs(context)
                            .edit()
                            .putString(KEY_PREFERRED_CURRENCY, currency)
                            .putBoolean(KEY_PRICE_ALERTS_ENABLED, priceAlerts != null && priceAlerts)
                            .putBoolean(KEY_NEWS_ALERTS_ENABLED, newsAlerts != null && newsAlerts)
                            .apply();
                });
    }

    private static void savePreferredCurrencyToFirebase(@NonNull String currency) {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();

        if (user == null) {
            return;
        }

        Map<String, Object> patch = new HashMap<>();
        patch.put("preferredCurrency", currency);

        FirebaseFirestore.getInstance()
                .collection("users")
                .document(user.getUid())
                .set(patch, SetOptions.merge());
    }

    private static void saveBooleanSettingToFirebase(@NonNull String key, boolean value) {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();

        if (user == null) {
            return;
        }

        Map<String, Object> patch = new HashMap<>();
        patch.put(key, value);

        FirebaseFirestore.getInstance()
                .collection("users")
                .document(user.getUid())
                .set(patch, SetOptions.merge());
    }

    private static SharedPreferences getSettingsPrefs(@NonNull Context context) {
        return context.getApplicationContext()
                .getSharedPreferences(SETTINGS_PREFS, Context.MODE_PRIVATE);
    }

    private static SharedPreferences getProfilePrefs(@NonNull Context context) {
        return context.getApplicationContext()
                .getSharedPreferences(PROFILE_PREFS, Context.MODE_PRIVATE);
    }

    private static String safe(@Nullable String value) {
        return value == null ? "" : value.trim();
    }

    private static String firstNonEmpty(String... values) {
        if (values == null) {
            return "";
        }

        for (String value : values) {
            if (value != null && !value.trim().isEmpty()) {
                return value.trim();
            }
        }

        return "";
    }
}