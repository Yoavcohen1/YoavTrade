package com.example.yoavsproject;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MarketsActivity extends AppCompatActivity {

    private RecyclerView recyclerMarkets;
    private BottomNavigationView bottomNav;
    private MarketsAdapter marketsAdapter;

    private TextView chipBigTech;
    private TextView chipStreaming;
    private TextView chipAi;
    private TextView chipSocial;

    private String selectedCategory = CATEGORY_BIG_TECH;
    private int quoteRequestVersion = 0;

    private static final String CATEGORY_BIG_TECH = "big_tech";
    private static final String CATEGORY_STREAMING = "streaming";
    private static final String CATEGORY_AI = "ai";
    private static final String CATEGORY_SOCIAL = "social";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        AppSettingsManager.applySavedUi(this);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_markets);

        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        bindViews();
        setupBottomMenu();
        setupRecycler();
        setupCategoryChips();
        selectCategory(CATEGORY_BIG_TECH);
    }

    private void bindViews() {
        recyclerMarkets = findViewById(R.id.recyclerMarkets);
        bottomNav = findViewById(R.id.bottomNav);

        chipBigTech = findViewById(R.id.chipBigTech);
        chipStreaming = findViewById(R.id.chipStreaming);
        chipAi = findViewById(R.id.chipAi);
        chipSocial = findViewById(R.id.chipSocial);
    }

    private void setupBottomMenu() {
        if (bottomNav != null) {
            NavBarUtil.setup(this, bottomNav, R.id.nav_market);
        }
    }

    private void setupRecycler() {
        if (recyclerMarkets == null) {
            return;
        }

        recyclerMarkets.setLayoutManager(new LinearLayoutManager(this));
        marketsAdapter = new MarketsAdapter(new ArrayList<>(), this::openStockGraph);
        recyclerMarkets.setAdapter(marketsAdapter);
    }

    private void setupCategoryChips() {
        configureChip(chipBigTech, CATEGORY_BIG_TECH);
        configureChip(chipStreaming, CATEGORY_STREAMING);
        configureChip(chipAi, CATEGORY_AI);
        configureChip(chipSocial, CATEGORY_SOCIAL);
    }

    private void configureChip(TextView chip, String category) {
        if (chip == null) {
            return;
        }

        chip.setClickable(true);
        chip.setFocusable(true);
        chip.setOnClickListener(v -> selectCategory(category));
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateMarketList(true);
    }

    private void selectCategory(String category) {
        selectedCategory = normalizeCategory(category);
        updateChipSelection();
        updateMarketList(true);
    }

    private String normalizeCategory(String category) {
        if (category == null || category.trim().isEmpty()) {
            return CATEGORY_BIG_TECH;
        }

        String clean = category.trim().toLowerCase(Locale.US);

        if (CATEGORY_STREAMING.equals(clean)
                || CATEGORY_AI.equals(clean)
                || CATEGORY_SOCIAL.equals(clean)
                || CATEGORY_BIG_TECH.equals(clean)) {
            return clean;
        }

        return CATEGORY_BIG_TECH;
    }

    private void updateMarketList(boolean refreshQuotes) {
        if (marketsAdapter == null) {
            setupRecycler();
        }

        if (marketsAdapter == null) {
            return;
        }

        List<MarketStockItem> items = buildMarketItems(selectedCategory);
        marketsAdapter.setItems(items);

        if (refreshQuotes) {
            refreshLiveQuotes(items);
        }
    }

    private void updateChipSelection() {
        styleChip(chipBigTech, CATEGORY_BIG_TECH.equals(selectedCategory));
        styleChip(chipStreaming, CATEGORY_STREAMING.equals(selectedCategory));
        styleChip(chipAi, CATEGORY_AI.equals(selectedCategory));
        styleChip(chipSocial, CATEGORY_SOCIAL.equals(selectedCategory));
    }

    private void styleChip(TextView chip, boolean selected) {
        if (chip == null) {
            return;
        }

        chip.setSelected(selected);
        chip.setBackgroundResource(selected ? R.drawable.bg_markets_chip_active : R.drawable.bg_markets_chip);
        chip.setTextColor(selected ? 0xFFFFFFFF : 0xFFB8C4D6);
        chip.setTypeface(null, selected ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
    }

    private List<MarketStockItem> buildMarketItems(String category) {
        List<MarketStockItem> items = new ArrayList<>();

        switch (normalizeCategory(category)) {
            case CATEGORY_STREAMING:
                addLoading(items, "NFLX", "Netflix");
                addLoading(items, "DIS", "Disney");
                addLoading(items, "AMZN", "Amazon");
                addLoading(items, "SPOT", "Spotify");
                break;

            case CATEGORY_AI:
                addLoading(items, "NVDA", "NVIDIA");
                addLoading(items, "AMD", "AMD");
                addLoading(items, "MSFT", "Microsoft");
                addLoading(items, "GOOGL", "Alphabet");
                break;

            case CATEGORY_SOCIAL:
                addLoading(items, "META", "Meta");
                addLoading(items, "RDDT", "Reddit");
                addLoading(items, "SNAP", "Snap");
                addLoading(items, "PINS", "Pinterest");
                break;

            case CATEGORY_BIG_TECH:
            default:
                addLoading(items, "AAPL", "Apple");
                addLoading(items, "MSFT", "Microsoft");
                addLoading(items, "GOOGL", "Alphabet");
                addLoading(items, "AMZN", "Amazon");
                addLoading(items, "META", "Meta");
                break;
        }

        return items;
    }

    private void addLoading(List<MarketStockItem> items, String symbol, String name) {
        items.add(new MarketStockItem(
                symbol,
                name,
                "Loading...",
                "Live",
                true,
                StockLogoMapper.getLogoResId(this, symbol)
        ));
    }

    private void refreshLiveQuotes(List<MarketStockItem> items) {
        quoteRequestVersion++;
        int version = quoteRequestVersion;

        for (MarketStockItem item : items) {
            if (item == null || item.symbol == null || item.symbol.trim().isEmpty()) {
                continue;
            }

            String symbol = item.symbol.trim().toUpperCase(Locale.US);

            AlphaVantageClient.globalQuoteAsync(symbol, new AlphaVantageClient.JsonCallback() {
                @Override
                public void onSuccess(JSONObject root) {
                    if (version != quoteRequestVersion || isFinishing() || isDestroyed()) {
                        return;
                    }

                    try {
                        JSONObject quote = root.optJSONObject("Global Quote");

                        if (quote == null) {
                            showQuoteUnavailable(symbol);
                            return;
                        }

                        String priceRaw = quote.optString("05. price", "").trim();
                        String changeRaw = quote.optString("10. change percent", "").trim();

                        if (priceRaw.isEmpty()) {
                            showQuoteUnavailable(symbol);
                            return;
                        }

                        double price = Double.parseDouble(priceRaw);
                        double changePercent = parseChangePercent(changeRaw);
                        boolean positive = changePercent >= 0.0;

                        String priceText = AppSettingsManager.formatUsdAmount(MarketsActivity.this, price);
                        String changeText = String.format(Locale.US, "%+.2f%%", changePercent);

                        marketsAdapter.updateQuote(symbol, priceText, changeText, positive);
                    } catch (Exception e) {
                        showQuoteUnavailable(symbol);
                    }
                }

                @Override
                public void onError(Exception e) {
                    if (version != quoteRequestVersion || isFinishing() || isDestroyed()) {
                        return;
                    }

                    showQuoteUnavailable(symbol);
                }
            });
        }
    }

    private double parseChangePercent(String raw) {
        if (raw == null || raw.trim().isEmpty()) {
            return 0.0;
        }

        String clean = raw.replace("%", "").trim();
        return Double.parseDouble(clean);
    }

    private void showQuoteUnavailable(String symbol) {
        if (marketsAdapter != null) {
            marketsAdapter.updateQuote(symbol, "N/A", "No data", false);
        }
    }

    private void openStockGraph(MarketStockItem item) {
        if (item == null) {
            return;
        }

        Intent intent = new Intent(MarketsActivity.this, StockGraphActivity.class);

        intent.putExtra("SYMBOL", item.symbol);
        intent.putExtra("symbol", item.symbol);
        intent.putExtra("stockSymbol", item.symbol);
        intent.putExtra("stockName", item.name);

        startActivity(intent);
    }
}