package com.example.yoavsproject;

import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.TimeZone;














public class StockGraphActivity extends AppCompatActivity {

    private ImageView btnBack;
    private ImageView imgStockLogo;

    private TextView tvStockName;
    private TextView tvStockSymbol;
    private TextView tvLiveUpdate;
    private TextView tvPrice;
    private TextView tvChange;
    private TextView tvMarketSessionTimer;
    private TextView tvChartInfo;

    private TextView btnRange1W;
    private TextView btnRange1M;
    private TextView btnRange1Y;
    private TextView btnRangeAll;
    private TextView btnExecuteOrder;

    private FrameLayout chartContainer;
    private InteractiveLineChartView lineChartView;

    private final Handler handler = new Handler(Looper.getMainLooper());

    private String symbol = "AAPL";
    private String companyName = "Apple";
    private String selectedRange = "1Y";

    private double currentPrice = 0.0;
    private boolean usingRealHistory = false;

    private final List<ChartPoint> allHistory = new ArrayList<>();
    private final List<ChartPoint> currentRangePoints = new ArrayList<>();

    private final Runnable marketTimerRunnable = new Runnable() {
        @Override
        public void run() {
            updateMarketSessionTimer();
            handler.postDelayed(this, 1000L);
        }
    };

    private final Runnable liveClockRunnable = new Runnable() {
        @Override
        public void run() {
            updateLiveText();
            handler.postDelayed(this, 30_000L);
        }
    };

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        AppSettingsManager.applySavedUi(this);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stock_graph);

        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        readIntent();
        bindViews();
        setupClicks();
        setupChart();
        updateHeader();
        loadLivePrice();
        loadHistoricalPrices();
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.post(marketTimerRunnable);
        handler.post(liveClockRunnable);
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(marketTimerRunnable);
        handler.removeCallbacks(liveClockRunnable);
    }

    private void readIntent() {
        Intent intent = getIntent();

        if (intent == null) {
            companyName = getCompanyName(symbol);
            return;
        }

        String s1 = intent.getStringExtra("symbol");
        String s2 = intent.getStringExtra("stockSymbol");

        if (s1 != null && !s1.trim().isEmpty()) {
            symbol = s1.trim().toUpperCase(Locale.US);
        } else if (s2 != null && !s2.trim().isEmpty()) {
            symbol = s2.trim().toUpperCase(Locale.US);
        }

        String n1 = intent.getStringExtra("stockName");
        String n2 = intent.getStringExtra("companyName");
        String n3 = intent.getStringExtra("name");

        if (n1 != null && !n1.trim().isEmpty()) {
            companyName = n1.trim();
        } else if (n2 != null && !n2.trim().isEmpty()) {
            companyName = n2.trim();
        } else if (n3 != null && !n3.trim().isEmpty()) {
            companyName = n3.trim();
        } else {
            companyName = getCompanyName(symbol);
        }

        double priceExtra = intent.getDoubleExtra("price", 0.0);
        if (priceExtra <= 0.0) {
            priceExtra = intent.getDoubleExtra("lastPrice", 0.0);
        }

        if (priceExtra > 0.0) {
            currentPrice = priceExtra;
        }
    }

    private void bindViews() {
        btnBack = findViewById(R.id.btnBack);
        imgStockLogo = findViewById(R.id.imgStockLogo);

        tvStockName = findViewById(R.id.tvStockName);
        tvStockSymbol = findViewById(R.id.tvStockSymbol);
        tvLiveUpdate = findViewById(R.id.tvLiveUpdate);
        tvPrice = findViewById(R.id.tvPrice);
        tvChange = findViewById(R.id.tvChange);
        tvMarketSessionTimer = findViewById(R.id.tvMarketSessionTimer);
        tvChartInfo = findViewById(R.id.tvChartInfo);

        btnRange1W = findViewById(R.id.btnRange1W);
        btnRange1M = findViewById(R.id.btnRange1M);
        btnRange1Y = findViewById(R.id.btnRange1Y);
        btnRangeAll = findViewById(R.id.btnRangeAll);
        btnExecuteOrder = findViewById(R.id.btnExecuteOrder);

        chartContainer = findViewById(R.id.chartContainer);
    }

    private void setupClicks() {
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> finish());
        }

        if (btnRange1W != null) {
            btnRange1W.setOnClickListener(v -> setRange("1W", true));
        }

        if (btnRange1M != null) {
            btnRange1M.setOnClickListener(v -> setRange("1M", true));
        }

        if (btnRange1Y != null) {
            btnRange1Y.setOnClickListener(v -> setRange("1Y", true));
        }

        if (btnRangeAll != null) {
            btnRangeAll.setOnClickListener(v -> setRange("All", true));
        }

        if (btnExecuteOrder != null) {
            btnExecuteOrder.setOnClickListener(v -> openExecuteOrder());
        }
    }

    private void openExecuteOrder() {
        double price = currentPrice;

        if (price <= 0.0 && !currentRangePoints.isEmpty()) {
            price = currentRangePoints.get(currentRangePoints.size() - 1).price;
        }

        if (price <= 0.0) {
            price = 1.0;
        }

        TradeBottomSheet.show(
                this,
                symbol,
                companyName,
                price,
                TradeBottomSheet.Mode.BUY,
                this::loadLivePrice
        );
    }

    private void setupChart() {
        if (chartContainer == null) {
            return;
        }

        lineChartView = new InteractiveLineChartView(this);
        lineChartView.setOnPointSelectedListener(point -> {
            if (point == null) {
                updatePriceViewsFromRange();
                updateChartInfo(null);
            } else {
                showSelectedPoint(point);
            }
        });

        chartContainer.removeAllViews();
        chartContainer.addView(
                lineChartView,
                new FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT,
                        FrameLayout.LayoutParams.MATCH_PARENT
                )
        );

        buildFallbackHistory();
        setRange(selectedRange, false);
    }

    private void updateHeader() {
        if (tvStockName != null) {
            tvStockName.setText(companyName);
        }

        if (tvStockSymbol != null) {
            tvStockSymbol.setText(symbol);
        }

        if (imgStockLogo != null) {
            try {
                StockLogoUtil.bindLogo(imgStockLogo, symbol);
            } catch (Exception e) {
                imgStockLogo.setImageResource(R.drawable.logo);
            }
        }

        updateLiveText();
        updatePriceViewsFromRange();
    }

    private void updateLiveText() {
        if (tvLiveUpdate == null) {
            return;
        }

        SimpleDateFormat format = new SimpleDateFormat("h:mm a", Locale.US);
        tvLiveUpdate.setText("Live chart updated " + format.format(System.currentTimeMillis()));
    }

    private void loadLivePrice() {
        AlphaVantageClient.lastPriceAsync(symbol, new AlphaVantageClient.PriceCallback() {
            @Override
            public void onSuccess(double price) {
                runOnUiThread(() -> {
                    if (price > 0.0) {
                        currentPrice = price;
                        replaceLatestPointWithLivePrice();
                        setRange(selectedRange, false);
                        updateLiveText();
                    }

                    updatePriceViewsFromRange();
                });
            }

            @Override
            public void onError(Exception e) {
                runOnUiThread(() -> updatePriceViewsFromRange());
            }
        });
    }

    private void loadHistoricalPrices() {
        if (tvChartInfo != null) {
            tvChartInfo.setText("Loading historical prices...");
        }

        AlphaVantageClient.getDailyTimeSeriesAsync(symbol, new AlphaVantageClient.JsonCallback() {
            @Override
            public void onSuccess(JSONObject json) {
                List<ChartPoint> parsed = parseDailyAdjustedSeries(json);

                if (parsed.isEmpty()) {
                    usingRealHistory = false;
                    setRange(selectedRange, true);
                    return;
                }

                allHistory.clear();
                allHistory.addAll(parsed);
                usingRealHistory = true;

                replaceLatestPointWithLivePrice();
                setRange(selectedRange, true);
                updateLiveText();
            }

            @Override
            public void onError(Exception e) {
                usingRealHistory = false;
                setRange(selectedRange, true);
            }
        });
    }

    @NonNull
    private List<ChartPoint> parseDailyAdjustedSeries(@Nullable JSONObject root) {
        List<ChartPoint> points = new ArrayList<>();

        if (root == null) {
            return points;
        }

        JSONObject series = root.optJSONObject("Time Series (Daily)");
        if (series == null) {
            return points;
        }

        List<String> dates = new ArrayList<>();
        Iterator<String> iterator = series.keys();

        while (iterator.hasNext()) {
            dates.add(iterator.next());
        }

        Collections.sort(dates);

        for (String date : dates) {
            JSONObject day = series.optJSONObject(date);
            if (day == null) {
                continue;
            }

            String adjustedClose = day.optString("5. adjusted close", "").trim();
            String close = day.optString("4. close", "").trim();

            String priceText = adjustedClose.isEmpty() ? close : adjustedClose;

            if (priceText.isEmpty()) {
                continue;
            }

            try {
                double price = Double.parseDouble(priceText);
                if (price > 0.0) {
                    points.add(new ChartPoint(date, price, true));
                }
            } catch (Exception ignored) {
            }
        }

        return points;
    }

    private void replaceLatestPointWithLivePrice() {
        if (currentPrice <= 0.0 || allHistory.isEmpty()) {
            return;
        }

        ChartPoint latest = allHistory.get(allHistory.size() - 1);
        allHistory.set(
                allHistory.size() - 1,
                new ChartPoint(latest.label, currentPrice, latest.real)
        );
    }

    private void setRange(String range, boolean resetSelection) {
        selectedRange = range;

        updateRangeButton(btnRange1W, "1W".equals(range));
        updateRangeButton(btnRange1M, "1M".equals(range));
        updateRangeButton(btnRange1Y, "1Y".equals(range));
        updateRangeButton(btnRangeAll, "All".equals(range));

        currentRangePoints.clear();
        currentRangePoints.addAll(sliceHistoryForRange(range));

        if (lineChartView != null) {
            lineChartView.setData(currentRangePoints, resetSelection);
        }

        updatePriceViewsFromRange();
        updateChartInfo(null);
    }

    @NonNull
    private List<ChartPoint> sliceHistoryForRange(String range) {
        if (allHistory.isEmpty()) {
            buildFallbackHistory();
        }

        int count;

        if ("1W".equals(range)) {
            count = 7;
        } else if ("1M".equals(range)) {
            count = 22;
        } else if ("1Y".equals(range)) {
            count = 252;
        } else {
            count = allHistory.size();
        }

        int start = Math.max(0, allHistory.size() - count);
        return new ArrayList<>(allHistory.subList(start, allHistory.size()));
    }

    private void buildFallbackHistory() {
        double basePrice = currentPrice > 0.0 ? currentPrice : getFallbackCurrentPrice(symbol);

        allHistory.clear();

        Random random = new Random(symbol.hashCode());
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_MONTH, -420);

        double value = basePrice * 0.72;

        for (int i = 0; i < 420; i++) {
            calendar.add(Calendar.DAY_OF_MONTH, 1);

            int day = calendar.get(Calendar.DAY_OF_WEEK);
            if (day == Calendar.SATURDAY || day == Calendar.SUNDAY) {
                continue;
            }

            double trend = (basePrice - value) / 180.0;
            double noise = (random.nextDouble() - 0.47) * basePrice * 0.025;
            value += trend * 0.18 + noise;

            if (value < basePrice * 0.45) {
                value = basePrice * 0.45;
            }

            String label = String.format(
                    Locale.US,
                    "%04d-%02d-%02d",
                    calendar.get(Calendar.YEAR),
                    calendar.get(Calendar.MONTH) + 1,
                    calendar.get(Calendar.DAY_OF_MONTH)
            );

            allHistory.add(new ChartPoint(label, value, false));
        }

        if (!allHistory.isEmpty()) {
            allHistory.set(
                    allHistory.size() - 1,
                    new ChartPoint(allHistory.get(allHistory.size() - 1).label, basePrice, false)
            );
        }
    }

    private void updatePriceViewsFromRange() {
        if (currentRangePoints.isEmpty()) {
            return;
        }

        ChartPoint last = currentRangePoints.get(currentRangePoints.size() - 1);
        showPriceAndChange(last, false);
    }

    private void showSelectedPoint(@NonNull ChartPoint point) {
        showPriceAndChange(point, true);
        updateChartInfo(point);
    }

    private void showPriceAndChange(@NonNull ChartPoint point, boolean selected) {
        if (tvPrice != null) {
            tvPrice.setText(formatMoney(point.price));
        }

        if (tvChange == null || currentRangePoints.isEmpty()) {
            return;
        }

        ChartPoint first = currentRangePoints.get(0);
        double change = point.price - first.price;
        double pct = first.price == 0.0 ? 0.0 : (change / first.price) * 100.0;

        String prefix = change >= 0.0 ? "+" : "";
        String selectedPrefix = selected ? "Selected • " : "";

        tvChange.setText(String.format(
                Locale.US,
                "%s%s%.2f%% (%s)",
                selectedPrefix,
                prefix,
                pct,
                formatSignedMoney(change)
        ));

        tvChange.setTextColor(change >= 0.0
                ? Color.rgb(34, 197, 94)
                : Color.rgb(239, 68, 68));
    }

    private void updateChartInfo(@Nullable ChartPoint selectedPoint) {
        if (tvChartInfo == null) {
            return;
        }

        if (selectedPoint != null) {
            tvChartInfo.setText(
                    "Selected point • " + formatDateForDisplay(selectedPoint.label)
                            + " • " + formatMoney(selectedPoint.price)
            );
            return;
        }

        String dataType = usingRealHistory ? "Alpha Vantage adjusted daily data" : "Preview chart data";
        tvChartInfo.setText(dataType + " • " + getTrendText(selectedRange) + " • Tap or drag on the chart");
    }

    private void updateRangeButton(TextView button, boolean selected) {
        if (button == null) {
            return;
        }

        button.setTextColor(Color.WHITE);
        button.setBackgroundResource(selected ? R.drawable.bg_pill_primary : R.drawable.bg_settings_row);
    }

    private String getTrendText(String range) {
        if ("1W".equals(range)) {
            return "Last trading week";
        }

        if ("1M".equals(range)) {
            return "Last trading month";
        }

        if ("1Y".equals(range)) {
            return "Past year trend";
        }

        return "Full available history";
    }

    private void updateMarketSessionTimer() {
        if (tvMarketSessionTimer == null) {
            return;
        }

        TimeZone marketZone = TimeZone.getTimeZone("America/New_York");
        Calendar now = Calendar.getInstance(marketZone);

        Calendar open = Calendar.getInstance(marketZone);
        open.set(Calendar.HOUR_OF_DAY, 9);
        open.set(Calendar.MINUTE, 30);
        open.set(Calendar.SECOND, 0);
        open.set(Calendar.MILLISECOND, 0);

        Calendar close = Calendar.getInstance(marketZone);
        close.set(Calendar.HOUR_OF_DAY, 16);
        close.set(Calendar.MINUTE, 0);
        close.set(Calendar.SECOND, 0);
        close.set(Calendar.MILLISECOND, 0);

        boolean weekend = isWeekend(now);

        if (!weekend && now.after(open) && now.before(close)) {
            long elapsed = now.getTimeInMillis() - open.getTimeInMillis();

            tvMarketSessionTimer.setText(
                    "Market opened at 9:30 AM ET • Open for " + formatDuration(elapsed)
            );
            tvMarketSessionTimer.setTextColor(Color.rgb(187, 247, 208));
        } else {
            Calendar lastClose = getLastMarketClose(now);
            long elapsed = now.getTimeInMillis() - lastClose.getTimeInMillis();

            tvMarketSessionTimer.setText(
                    "Market closed at 4:00 PM ET • Closed for " + formatDuration(elapsed)
            );
            tvMarketSessionTimer.setTextColor(Color.rgb(191, 208, 247));
        }
    }

    private Calendar getLastMarketClose(Calendar now) {
        TimeZone marketZone = TimeZone.getTimeZone("America/New_York");

        Calendar close = Calendar.getInstance(marketZone);
        close.set(Calendar.YEAR, now.get(Calendar.YEAR));
        close.set(Calendar.MONTH, now.get(Calendar.MONTH));
        close.set(Calendar.DAY_OF_MONTH, now.get(Calendar.DAY_OF_MONTH));
        close.set(Calendar.HOUR_OF_DAY, 16);
        close.set(Calendar.MINUTE, 0);
        close.set(Calendar.SECOND, 0);
        close.set(Calendar.MILLISECOND, 0);

        if (!isWeekend(now) && now.after(close)) {
            return close;
        }

        close.add(Calendar.DAY_OF_MONTH, -1);

        while (isWeekend(close)) {
            close.add(Calendar.DAY_OF_MONTH, -1);
        }

        close.set(Calendar.HOUR_OF_DAY, 16);
        close.set(Calendar.MINUTE, 0);
        close.set(Calendar.SECOND, 0);
        close.set(Calendar.MILLISECOND, 0);

        return close;
    }

    private boolean isWeekend(Calendar calendar) {
        int day = calendar.get(Calendar.DAY_OF_WEEK);
        return day == Calendar.SATURDAY || day == Calendar.SUNDAY;
    }

    private String formatDuration(long millis) {
        if (millis < 0) {
            millis = 0;
        }

        long totalSeconds = millis / 1000L;
        long hours = totalSeconds / 3600L;
        long minutes = (totalSeconds % 3600L) / 60L;
        long seconds = totalSeconds % 60L;

        return String.format(Locale.US, "%02dh %02dm %02ds", hours, minutes, seconds);
    }

    private String getCompanyName(String symbol) {
        String s = symbol == null ? "" : symbol.trim().toUpperCase(Locale.US);

        if ("AAPL".equals(s)) return "Apple";
        if ("MSFT".equals(s)) return "Microsoft";
        if ("META".equals(s)) return "Meta";
        if ("NFLX".equals(s)) return "Netflix";
        if ("AMZN".equals(s)) return "Amazon";
        if ("GOOGL".equals(s) || "GOOG".equals(s)) return "Alphabet";
        if ("TSLA".equals(s)) return "Tesla";
        if ("NVDA".equals(s)) return "NVIDIA";
        if ("AMD".equals(s)) return "AMD";
        if ("ABNB".equals(s)) return "Airbnb";
        if ("RDDT".equals(s)) return "Reddit";

        return s.isEmpty() ? "Stock" : s;
    }

    private double getFallbackCurrentPrice(String symbol) {
        String s = symbol == null ? "" : symbol.trim().toUpperCase(Locale.US);

        if ("AAPL".equals(s)) return 270.71;
        if ("MSFT".equals(s)) return 420.24;
        if ("NVDA".equals(s)) return 875.28;
        if ("META".equals(s)) return 485.58;
        if ("NFLX".equals(s)) return 607.33;
        if ("AMZN".equals(s)) return 182.41;
        if ("GOOGL".equals(s) || "GOOG".equals(s)) return 171.95;
        if ("TSLA".equals(s)) return 183.25;
        if ("AMD".equals(s)) return 158.31;
        if ("RDDT".equals(s)) return 58.00;

        return 100.00;
    }

    private String formatMoney(double value) {
        return String.format(Locale.US, "$%,.2f", value);
    }

    private String formatSignedMoney(double value) {
        String prefix = value >= 0.0 ? "+" : "-";
        return prefix + formatMoney(Math.abs(value));
    }

    private String formatDateForDisplay(String rawDate) {
        if (rawDate == null || rawDate.trim().isEmpty()) {
            return "current point";
        }

        return rawDate.trim();
    }

    private static class ChartPoint {
        final String label;
        final double price;
        final boolean real;

        ChartPoint(@NonNull String label, double price, boolean real) {
            this.label = label;
            this.price = price;
            this.real = real;
        }
    }

    public static class InteractiveLineChartView extends View {

        public interface OnPointSelectedListener {
            void onPointSelected(@Nullable ChartPoint point);
        }

        private final Paint gridPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint linePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint axisTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint selectedLinePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint selectedDotPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint selectedDotStrokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint bubblePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint bubbleTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

        private final List<ChartPoint> points = new ArrayList<>();

        private OnPointSelectedListener listener;
        private int selectedIndex = -1;

        public InteractiveLineChartView(android.content.Context context) {
            super(context);

            setFocusable(true);
            setClickable(true);

            gridPaint.setColor(Color.rgb(38, 52, 77));
            gridPaint.setStrokeWidth(1f);

            linePaint.setColor(Color.rgb(34, 197, 94));
            linePaint.setStrokeWidth(5f);
            linePaint.setStyle(Paint.Style.STROKE);
            linePaint.setStrokeCap(Paint.Cap.ROUND);
            linePaint.setStrokeJoin(Paint.Join.ROUND);

            axisTextPaint.setColor(Color.rgb(142, 160, 188));
            axisTextPaint.setTextSize(sp(11));

            selectedLinePaint.setColor(Color.argb(190, 191, 208, 255));
            selectedLinePaint.setStrokeWidth(2f);

            selectedDotPaint.setColor(Color.WHITE);
            selectedDotPaint.setStyle(Paint.Style.FILL);

            selectedDotStrokePaint.setColor(Color.rgb(34, 197, 94));
            selectedDotStrokePaint.setStyle(Paint.Style.STROKE);
            selectedDotStrokePaint.setStrokeWidth(5f);

            bubblePaint.setColor(Color.rgb(16, 27, 46));
            bubblePaint.setStyle(Paint.Style.FILL);

            bubbleTextPaint.setColor(Color.WHITE);
            bubbleTextPaint.setTextSize(sp(12));
            bubbleTextPaint.setFakeBoldText(true);
        }

        public void setOnPointSelectedListener(@Nullable OnPointSelectedListener listener) {
            this.listener = listener;
        }

        public void setData(@Nullable List<ChartPoint> data, boolean resetSelection) {
            points.clear();

            if (data != null) {
                points.addAll(data);
            }

            if (resetSelection) {
                selectedIndex = -1;
            } else if (selectedIndex >= points.size()) {
                selectedIndex = -1;
            }

            invalidate();
        }

        @Override
        public boolean performClick() {
            super.performClick();
            return true;
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            if (points.size() < 2) {
                return super.onTouchEvent(event);
            }

            int action = event.getActionMasked();

            if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_MOVE) {
                if (getParent() != null) {
                    getParent().requestDisallowInterceptTouchEvent(true);
                }

                selectedIndex = findNearestIndex(event.getX());
                invalidate();

                if (listener != null && selectedIndex >= 0 && selectedIndex < points.size()) {
                    listener.onPointSelected(points.get(selectedIndex));
                }

                return true;
            }

            if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
                performClick();

                if (getParent() != null) {
                    getParent().requestDisallowInterceptTouchEvent(false);
                }

                return true;
            }

            return true;
        }

        private int findNearestIndex(float touchX) {
            RectF rect = chartRect();
            float clampedX = Math.max(rect.left, Math.min(rect.right, touchX));
            float ratio = (clampedX - rect.left) / Math.max(1f, rect.width());

            int index = Math.round(ratio * (points.size() - 1));
            return Math.max(0, Math.min(points.size() - 1, index));
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);

            int width = getWidth();
            int height = getHeight();

            if (width <= 0 || height <= 0) {
                return;
            }

            RectF rect = chartRect();

            for (int i = 0; i < 4; i++) {
                float y = rect.top + (rect.height() / 3f) * i;
                canvas.drawLine(rect.left, y, rect.right, y, gridPaint);
            }

            if (points.size() < 2) {
                return;
            }

            double min = points.get(0).price;
            double max = points.get(0).price;

            for (ChartPoint point : points) {
                min = Math.min(min, point.price);
                max = Math.max(max, point.price);
            }

            if (max - min < 1.0) {
                max += 1.0;
                min -= 1.0;
            }

            Path linePath = new Path();
            Path fillPath = new Path();

            for (int i = 0; i < points.size(); i++) {
                float x = xForIndex(i, rect);
                float y = yForPrice(points.get(i).price, min, max, rect);

                if (i == 0) {
                    linePath.moveTo(x, y);
                    fillPath.moveTo(x, rect.bottom);
                    fillPath.lineTo(x, y);
                } else {
                    linePath.lineTo(x, y);
                    fillPath.lineTo(x, y);
                }
            }

            fillPath.lineTo(rect.right, rect.bottom);
            fillPath.close();

            fillPaint.setShader(new LinearGradient(
                    0,
                    rect.top,
                    0,
                    rect.bottom,
                    Color.argb(90, 34, 197, 94),
                    Color.argb(0, 34, 197, 94),
                    Shader.TileMode.CLAMP
            ));

            canvas.drawPath(fillPath, fillPaint);
            canvas.drawPath(linePath, linePaint);

            canvas.drawText(String.format(Locale.US, "%.0f", max), 4, rect.top + dp(6), axisTextPaint);
            canvas.drawText(String.format(Locale.US, "%.0f", min), 4, rect.bottom, axisTextPaint);

            drawSelectedPoint(canvas, rect, min, max);
        }

        private void drawSelectedPoint(Canvas canvas, RectF rect, double min, double max) {
            if (selectedIndex < 0 || selectedIndex >= points.size()) {
                return;
            }

            ChartPoint point = points.get(selectedIndex);

            float x = xForIndex(selectedIndex, rect);
            float y = yForPrice(point.price, min, max, rect);

            canvas.drawLine(x, rect.top, x, rect.bottom, selectedLinePaint);
            canvas.drawCircle(x, y, dp(7), selectedDotPaint);
            canvas.drawCircle(x, y, dp(7), selectedDotStrokePaint);

            String text = String.format(Locale.US, "$%,.2f", point.price);
            float textWidth = bubbleTextPaint.measureText(text);
            float bubbleWidth = textWidth + dp(22);
            float bubbleHeight = dp(34);

            float bubbleLeft = x - bubbleWidth / 2f;
            bubbleLeft = Math.max(rect.left, Math.min(rect.right - bubbleWidth, bubbleLeft));

            float bubbleTop = y - dp(50);
            if (bubbleTop < rect.top) {
                bubbleTop = y + dp(18);
            }

            RectF bubble = new RectF(
                    bubbleLeft,
                    bubbleTop,
                    bubbleLeft + bubbleWidth,
                    bubbleTop + bubbleHeight
            );

            canvas.drawRoundRect(bubble, dp(15), dp(15), bubblePaint);
            canvas.drawText(text, bubble.left + dp(11), bubble.top + dp(22), bubbleTextPaint);
        }

        private RectF chartRect() {
            return new RectF(
                    dp(42),
                    dp(24),
                    Math.max(dp(43), getWidth() - dp(18)),
                    Math.max(dp(25), getHeight() - dp(34))
            );
        }

        private float xForIndex(int index, RectF rect) {
            if (points.size() <= 1) {
                return rect.left;
            }

            return rect.left + rect.width() * index / (points.size() - 1);
        }

        private float yForPrice(double price, double min, double max, RectF rect) {
            double normalized = (price - min) / Math.max(0.0001, max - min);
            return (float) (rect.bottom - normalized * rect.height());
        }

        private int dp(int value) {
            return Math.round(value * getResources().getDisplayMetrics().density);
        }

        private float sp(int value) {
            return value * getResources().getDisplayMetrics().scaledDensity;
        }
    }
}