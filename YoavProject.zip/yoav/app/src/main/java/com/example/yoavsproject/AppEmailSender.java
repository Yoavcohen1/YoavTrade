package com.example.yoavsproject;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.Collections;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public final class AppEmailSender {

    private static final String MAIL_COLLECTION = "mail";

    private AppEmailSender() {
    }

    public static void sendWelcomeEmail(
            @Nullable String email,
            @Nullable String displayName,
            double starterBalance
    ) {
        String cleanEmail = email == null ? "" : email.trim();
        String cleanName = displayName == null ? "" : displayName.trim();

        if (cleanEmail.isEmpty()) {
            return;
        }

        if (cleanName.isEmpty()) {
            cleanName = "Trader";
        }

        Map<String, Object> message = new HashMap<>();
        message.put("subject", "Welcome to YoavTrade");
        message.put("html", buildWelcomeHtml(cleanName, starterBalance));
        message.put("text", buildWelcomeText(cleanName, starterBalance));

        Map<String, Object> mail = new HashMap<>();
        mail.put("to", Collections.singletonList(cleanEmail));
        mail.put("message", message);
        mail.put("type", "welcome");
        mail.put("createdAt", FieldValue.serverTimestamp());

        FirebaseFirestore.getInstance()
                .collection(MAIL_COLLECTION)
                .add(mail);
    }

    private static String buildWelcomeText(@NonNull String name, double starterBalance) {
        return "Hi " + name + ",\n\n" +
                "Welcome to YoavTrade.\n\n" +
                "We are happy to have you here. You received " +
                String.format(Locale.US, "$%,.2f", starterBalance) +
                " to begin your trading journey and start building your first portfolio.\n\n" +
                "Developed by Yoav.";
    }

    private static String buildWelcomeHtml(@NonNull String name, double starterBalance) {
        String safeName = escapeHtml(name);
        String money = String.format(Locale.US, "$%,.2f", starterBalance);

        return "<!DOCTYPE html>" +
                "<html><head><meta charset=\"UTF-8\"><meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\"></head>" +
                "<body style=\"margin:0;padding:0;background:#0B1220;font-family:Arial,Helvetica,sans-serif;\">" +
                "<table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" style=\"background:#0B1220;padding:28px 14px;\">" +
                "<tr><td align=\"center\">" +
                "<table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" style=\"max-width:560px;background:#101A2D;border-radius:28px;overflow:hidden;border:1px solid #1D2B46;\">" +

                "<tr><td style=\"padding:32px 26px 22px 26px;text-align:center;background:linear-gradient(135deg,#315DFF,#5B45FF,#7C3AED);\">" +
                "<div style=\"display:inline-block;background:rgba(255,255,255,0.16);border-radius:22px;padding:14px 18px;color:#FFFFFF;font-size:24px;font-weight:800;\">YT</div>" +
                "<h1 style=\"margin:18px 0 6px 0;color:#FFFFFF;font-size:28px;line-height:34px;\">Welcome to YoavTrade</h1>" +
                "<p style=\"margin:0;color:#DCE6FF;font-size:15px;line-height:22px;\">Your trading journey starts now</p>" +
                "</td></tr>" +

                "<tr><td style=\"padding:28px 26px 10px 26px;color:#FFFFFF;\">" +
                "<h2 style=\"margin:0 0 10px 0;font-size:22px;line-height:28px;color:#FFFFFF;\">Hi " + safeName + ",</h2>" +
                "<p style=\"margin:0;color:#A8B6CE;font-size:15px;line-height:24px;\">" +
                "We’re happy to have you here. Your YoavTrade account was created successfully." +
                "</p>" +
                "</td></tr>" +

                "<tr><td style=\"padding:18px 26px;\">" +
                "<table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" style=\"background:#0B1324;border:1px solid #26344D;border-radius:22px;\">" +
                "<tr><td style=\"padding:24px;text-align:center;\">" +
                "<div style=\"font-size:34px;line-height:34px;\">🎁</div>" +
                "<div style=\"margin-top:12px;color:#8EA0BC;font-size:13px;font-weight:700;text-transform:uppercase;letter-spacing:0.6px;\">Welcome bonus</div>" +
                "<div style=\"margin-top:8px;color:#FFFFFF;font-size:34px;font-weight:900;line-height:40px;\">" + money + "</div>" +
                "<div style=\"margin-top:8px;color:#22C55E;font-size:14px;font-weight:700;\">Added to your trading account</div>" +
                "</td></tr></table>" +
                "</td></tr>" +

                "<tr><td style=\"padding:8px 26px 28px 26px;\">" +
                "<div style=\"background:#14213A;border-radius:18px;padding:16px;color:#BFD0F7;font-size:14px;line-height:22px;\">" +
                "<strong style=\"color:#FFFFFF;\">What you can do now:</strong><br>" +
                "• Discover stocks by category<br>" +
                "• Track charts and prices<br>" +
                "• Track your favorite stocks<br>" +
                "• Manage your trading balance<br>" +
                "• Follow market news and alerts" +
                "</div>" +
                "</td></tr>" +

                "<tr><td style=\"padding:0 26px 30px 26px;text-align:center;\">" +
                "<p style=\"margin:0;color:#64748B;font-size:13px;line-height:20px;\">YoavTrade • Developed by Yoav</p>" +
                "</td></tr>" +

                "</table></td></tr></table></body></html>";
    }

    private static String escapeHtml(@NonNull String value) {
        return value
                .replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&#39;");
    }
}