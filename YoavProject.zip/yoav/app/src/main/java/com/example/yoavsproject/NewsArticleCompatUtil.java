package com.example.yoavsproject;

import java.lang.reflect.Field;





public class NewsArticleCompatUtil {

    public static String getTitle(NewsArticle article) {
        return getStringField(article, "title", "headline", "name");
    }

    public static String getSource(NewsArticle article) {
        return getStringField(article, "sourceName", "source", "publisher", "author");
    }

    public static String getBody(NewsArticle article) {
        String body = getStringField(article, "content", "snippet", "description", "summary", "body", "excerpt");
        return body == null ? "" : body;
    }

    public static String getImageUrl(NewsArticle article) {
        return getStringField(article, "imageUrl", "image", "image_url", "urlToImage", "thumbnailUrl", "pictureUrl");
    }

    public static String getLink(NewsArticle article) {
        return getStringField(article, "link", "url", "articleUrl", "webUrl");
    }

    private static String getStringField(Object obj, String... names) {
        if (obj == null) return "";
        Class<?> c = obj.getClass();

        for (String n : names) {
            try {
                Field f = c.getDeclaredField(n);
                f.setAccessible(true);
                Object value = f.get(obj);
                if (value instanceof String) {
                    String s = (String) value;
                    if (s != null && !s.trim().isEmpty()) return s;
                }
            } catch (Exception ignored) {
            }
        }
        return "";
    }

    private NewsArticleCompatUtil() {
    }
}
