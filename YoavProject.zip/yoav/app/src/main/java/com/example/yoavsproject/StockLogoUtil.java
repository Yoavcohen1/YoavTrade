package com.example.yoavsproject;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Shader;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public final class StockLogoUtil {

    private static final Map<String, Integer> COLORS = new HashMap<>();

    static {
        COLORS.put("AAPL", Color.rgb(110, 110, 110));
        COLORS.put("MSFT", Color.rgb(0, 164, 239));
        COLORS.put("META", Color.rgb(24, 119, 242));
        COLORS.put("NFLX", Color.rgb(229, 9, 20));
        COLORS.put("AMZN", Color.rgb(255, 153, 0));
        COLORS.put("GOOGL", Color.rgb(66, 133, 244));
        COLORS.put("GOOG", Color.rgb(66, 133, 244));
        COLORS.put("TSLA", Color.rgb(204, 0, 0));
        COLORS.put("NVDA", Color.rgb(118, 185, 0));
        COLORS.put("AMD", Color.rgb(80, 80, 80));
        COLORS.put("ABNB", Color.rgb(255, 56, 92));
        COLORS.put("DIS", Color.rgb(20, 50, 120));
        COLORS.put("PYPL", Color.rgb(0, 112, 186));
        COLORS.put("INTC", Color.rgb(0, 113, 197));
        COLORS.put("IBM", Color.rgb(31, 100, 200));
    }

    private StockLogoUtil() {
    }

    public static void bindLogo(@Nullable ImageView imageView, @Nullable String symbol) {
        if (imageView == null) {
            return;
        }

        Context context = imageView.getContext();
        String cleanSymbol = normalizeSymbol(symbol);

        imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        imageView.setPadding(0, 0, 0, 0);

        int drawableId = findExistingLogoDrawable(context, cleanSymbol);

        if (drawableId != 0) {
            imageView.setImageResource(drawableId);
            imageView.setBackgroundResource(R.drawable.bg_stock_logo_container);
            imageView.setClipToOutline(true);
            return;
        }

        imageView.setImageBitmap(createGeneratedLogo(cleanSymbol));
        imageView.setBackgroundResource(R.drawable.bg_stock_logo_container);
        imageView.setClipToOutline(true);
    }

    private static String normalizeSymbol(@Nullable String symbol) {
        if (symbol == null || symbol.trim().isEmpty()) {
            return "?";
        }

        return symbol.trim()
                .toUpperCase(Locale.US)
                .replace(".", "")
                .replace("-", "");
    }

    private static int findExistingLogoDrawable(@NonNull Context context, @NonNull String symbol) {
        String lower = symbol.toLowerCase(Locale.US);

        String[] possibleNames = new String[]{
                "ic_stock_" + lower,
                "stock_" + lower,
                "logo_" + lower,
                "ic_" + lower,
                lower
        };

        for (String name : possibleNames) {
            int id = context.getResources().getIdentifier(
                    name,
                    "drawable",
                    context.getPackageName()
            );

            if (id != 0) {
                return id;
            }
        }

        return 0;
    }

    private static Bitmap createGeneratedLogo(@NonNull String symbol) {
        int size = 160;

        Bitmap bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);

        int baseColor = COLORS.containsKey(symbol)
                ? COLORS.get(symbol)
                : colorFromSymbol(symbol);

        Paint bgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        bgPaint.setShader(new LinearGradient(
                0,
                0,
                size,
                size,
                lighten(baseColor),
                darken(baseColor),
                Shader.TileMode.CLAMP
        ));

        canvas.drawRoundRect(0, 0, size, size, 34, 34, bgPaint);

        Paint overlay = new Paint(Paint.ANTI_ALIAS_FLAG);
        overlay.setStyle(Paint.Style.STROKE);
        overlay.setStrokeWidth(5);
        overlay.setColor(Color.argb(70, 255, 255, 255));
        canvas.drawRoundRect(5, 5, size - 5, size - 5, 30, 30, overlay);

        String letters = getLogoLetters(symbol);

        Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        textPaint.setColor(Color.WHITE);
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setFakeBoldText(true);
        textPaint.setTextSize(letters.length() >= 3 ? 44 : 54);

        Rect bounds = new Rect();
        textPaint.getTextBounds(letters, 0, letters.length(), bounds);

        float x = size / 2f;
        float y = size / 2f - bounds.exactCenterY();

        canvas.drawText(letters, x, y, textPaint);

        return bitmap;
    }

    private static String getLogoLetters(@NonNull String symbol) {
        if (symbol.length() <= 3) {
            return symbol;
        }

        return symbol.substring(0, 3);
    }

    private static int colorFromSymbol(@NonNull String symbol) {
        int hash = Math.abs(symbol.hashCode());

        int r = 60 + (hash % 130);
        int g = 70 + ((hash / 7) % 120);
        int b = 120 + ((hash / 13) % 120);

        return Color.rgb(r, g, Math.min(b, 245));
    }

    private static int lighten(int color) {
        int r = Math.min(255, Color.red(color) + 45);
        int g = Math.min(255, Color.green(color) + 45);
        int b = Math.min(255, Color.blue(color) + 45);

        return Color.rgb(r, g, b);
    }

    private static int darken(int color) {
        int r = Math.max(0, Color.red(color) - 45);
        int g = Math.max(0, Color.green(color) - 45);
        int b = Math.max(0, Color.blue(color) - 45);

        return Color.rgb(r, g, b);
    }
}