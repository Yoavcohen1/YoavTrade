package com.example.yoavsproject;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class HoldingsAdapter extends RecyclerView.Adapter<HoldingsAdapter.HoldingViewHolder> {

    public interface OnHoldingClickListener {
        void onHoldingClick(PortfolioManager.Holding holding, Double lastPrice);
    }

    private final List<PortfolioManager.Holding> holdings;
    private final Map<String, Double> livePrices = new HashMap<>();
    private final OnHoldingClickListener clickListener;

    public HoldingsAdapter(List<PortfolioManager.Holding> holdings, OnHoldingClickListener clickListener) {
        this.holdings = holdings;
        this.clickListener = clickListener;
    }

    public void updatePrice(String symbol, Double price) {
        if (symbol == null || price == null) return;

        livePrices.put(symbol, price);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public HoldingViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_holding, parent, false);

        return new HoldingViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull HoldingViewHolder holder, int position) {
        PortfolioManager.Holding h = holdings.get(position);
        holder.bind(h, livePrices.get(h.symbol), clickListener);
    }

    @Override
    public int getItemCount() {
        return holdings != null ? holdings.size() : 0;
    }

    static class HoldingViewHolder extends RecyclerView.ViewHolder {

        ImageView ivLogo;
        TextView tvSymbol;
        TextView tvQuantity;
        TextView tvAvgPrice;
        TextView tvLastPrice;
        TextView tvPnl;

        HoldingViewHolder(@NonNull View itemView) {
            super(itemView);

            ivLogo = itemView.findViewById(R.id.ivHoldingLogo);
            tvSymbol = itemView.findViewById(R.id.tvSymbol);
            tvQuantity = itemView.findViewById(R.id.tvQuantity);
            tvAvgPrice = itemView.findViewById(R.id.tvAvgPrice);
            tvLastPrice = itemView.findViewById(R.id.tvLastPrice);
            tvPnl = itemView.findViewById(R.id.tvPnl);
        }

        void bind(
                PortfolioManager.Holding h,
                Double lastPrice,
                OnHoldingClickListener clickListener
        ) {
            String symbol = h.symbol != null ? h.symbol.trim().toUpperCase(Locale.US) : "-";
            StockLogoMapper.bind(ivLogo, symbol);

            tvSymbol.setText(symbol);
            tvQuantity.setText(String.format(Locale.US, "Shares %.4f", h.quantity));

            AppSettingsManager.formatUsdAmountAsync(
                    itemView.getContext(),
                    h.avgBuyPrice,
                    formatted -> tvAvgPrice.setText("Bought at " + formatted)
            );

            double current = lastPrice != null ? lastPrice : h.avgBuyPrice;

            AppSettingsManager.formatUsdAmountAsync(
                    itemView.getContext(),
                    current,
                    formatted -> tvLastPrice.setText("Now " + formatted)
            );

            double pnlUsd = (current - h.avgBuyPrice) * h.quantity;

            AppSettingsManager.formatUsdAmountAsync(
                    itemView.getContext(),
                    Math.abs(pnlUsd),
                    formatted -> tvPnl.setText((pnlUsd >= 0 ? "+" : "-") + formatted)
            );

            tvPnl.setTextColor(pnlUsd >= 0 ? 0xFF43D38F : 0xFFFF7B7B);

            itemView.setOnClickListener(v -> {
                if (clickListener != null) {
                    clickListener.onHoldingClick(h, lastPrice != null ? lastPrice : h.avgBuyPrice);
                }
            });

            if (itemView.getTag() == null) {
                itemView.setTag(Boolean.TRUE);
                itemView.setAlpha(0f);
                itemView.setTranslationY(14f);
                itemView.animate()
                        .alpha(1f)
                        .translationY(0f)
                        .setDuration(220)
                        .start();
            }
        }
    }
}