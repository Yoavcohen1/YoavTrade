package com.example.yoavsproject;





public class MarketStock {
    public final String symbol;
    public final String name;

    public MarketStock(String symbol, String name) {
        this.symbol = symbol;
        this.name = name;
    }
}
