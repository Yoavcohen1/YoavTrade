package com.example.yoavsproject;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.net.Uri;
import android.util.Base64;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatDelegate;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

public class ProfilePrefs {

    private static final String PREFS = "yoav_local_prefs";
    private static final String KEY_NAME = "display_name";
    private static final String KEY_EMAIL = "email";
    private static final String KEY_PHOTO_BASE64 = "photo_base64";
    private static final String KEY_PHOTO_URL = "photo_url";
    private static final String KEY_CURRENCY = "currency";
    private static final String KEY_DARK = "dark_mode";
    private static final String KEY_PRIVATE = "profile_private";

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static void saveProfile(Context c, String name, String email, String base64) {
        prefs(c).edit()
                .putString(KEY_NAME, name == null ? "" : name)
                .putString(KEY_EMAIL, email == null ? "" : email)
                .putString(KEY_PHOTO_BASE64, base64 == null ? "" : base64)
                .apply();
    }

    public static String getDisplayName(Context c) {
        return prefs(c).getString(KEY_NAME, "");
    }

    public static void setDisplayName(Context c, String value) {
        prefs(c).edit().putString(KEY_NAME, value == null ? "" : value).apply();
    }

    public static String getEmail(Context c) {
        return prefs(c).getString(KEY_EMAIL, "");
    }

    public static String getPhotoBase64(Context c) {
        return prefs(c).getString(KEY_PHOTO_BASE64, "");
    }

    public static void setPhotoBase64(Context c, String value) {
        prefs(c).edit().putString(KEY_PHOTO_BASE64, value == null ? "" : value).apply();
    }

    public static String getPhotoUrl(Context c) {
        return prefs(c).getString(KEY_PHOTO_URL, "");
    }

    public static void setPhotoUrl(Context c, String value) {
        prefs(c).edit().putString(KEY_PHOTO_URL, value == null ? "" : value).apply();
    }

    public static void clearPhoto(Context c) {
        prefs(c).edit()
                .putString(KEY_PHOTO_BASE64, "")
                .putString(KEY_PHOTO_URL, "")
                .apply();
    }

    public static void savePreferredCurrency(Context c, String value) {
        AppSettingsManager.savePreferredCurrencyQuick(c, value);
    }

    public static void savePreferredCurrencyLocalOnly(Context c, String value) {
        prefs(c).edit()
                .putString(KEY_CURRENCY, AppSettingsManager.normalizeCurrency(value))
                .apply();
    }

    public static String getPreferredCurrency(Context c) {
        return AppSettingsManager.normalizeCurrency(prefs(c).getString(KEY_CURRENCY, "USD"));
    }

    public static void saveDarkMode(Context c, boolean enabled) {
        prefs(c).edit().putBoolean(KEY_DARK, enabled).apply();
    }

    public static boolean isDarkModeEnabled(Context c) {
        return prefs(c).getBoolean(KEY_DARK, true);
    }

    public static void applySavedTheme(Context c) {
        AppCompatDelegate.setDefaultNightMode(
                isDarkModeEnabled(c)
                        ? AppCompatDelegate.MODE_NIGHT_YES
                        : AppCompatDelegate.MODE_NIGHT_NO
        );
    }

    public static void setProfilePrivate(Context c, boolean enabled) {
        prefs(c).edit().putBoolean(KEY_PRIVATE, enabled).apply();
    }

    public static boolean isProfilePrivate(Context c) {
        return prefs(c).getBoolean(KEY_PRIVATE, false);
    }

    @Nullable
    public static Bitmap decodeBase64ToBitmap(String base64) {
        if (base64 == null || base64.trim().isEmpty()) return null;

        try {
            byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
            return BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
        } catch (Exception e) {
            return null;
        }
    }

    public static String encodeImageUriToCircularBase64(Context c, Uri uri, int sizePx) throws Exception {
        InputStream input = null;

        try {
            input = c.getContentResolver().openInputStream(uri);
            if (input == null) throw new Exception("Unable to open image stream");

            Bitmap original = BitmapFactory.decodeStream(input);
            if (original == null) throw new Exception("Unable to decode image");

            Bitmap square = centerCropSquare(original);
            Bitmap scaled = Bitmap.createScaledBitmap(square, sizePx, sizePx, true);
            Bitmap circle = circleCrop(scaled);

            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            circle.compress(Bitmap.CompressFormat.PNG, 100, baos);

            return Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP);
        } finally {
            try {
                if (input != null) input.close();
            } catch (Exception ignored) {
            }
        }
    }

    private static Bitmap centerCropSquare(Bitmap src) {
        int size = Math.min(src.getWidth(), src.getHeight());
        int x = (src.getWidth() - size) / 2;
        int y = (src.getHeight() - size) / 2;

        return Bitmap.createBitmap(src, x, y, size, size);
    }

    private static Bitmap circleCrop(Bitmap src) {
        Bitmap out = Bitmap.createBitmap(src.getWidth(), src.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(out);

        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        Rect rect = new Rect(0, 0, src.getWidth(), src.getHeight());
        RectF rectF = new RectF(rect);

        canvas.drawARGB(0, 0, 0, 0);
        canvas.drawOval(rectF, p);

        p.setXfermode(new android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.SRC_IN));
        canvas.drawBitmap(src, rect, rect, p);

        return out;
    }
}