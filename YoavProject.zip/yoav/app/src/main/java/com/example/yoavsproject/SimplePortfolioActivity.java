package com.example.yoavsproject;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.bottomsheet.BottomSheetDialog;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class SimplePortfolioActivity extends AppCompatActivity {

    private TextView tvPortfolioValue;
    private TextView tvCashBalance;
    private TextView tvHoldingsCount;
    private TextView tvPortfolioRefresh;
    private TextView tvPortfolioRefreshIcon;
    private TextView tvActivityRefresh;
    private TextView tvEmptyPortfolio;
    private TextView tvEmptyActivity;

    private View btnBuyStocks;

    private LinearLayout layoutRecentActivity;

    private RecyclerView recyclerHoldings;
    private BottomNavigationView bottomNav;

    private final List<PortfolioManager.Holding> holdings = new ArrayList<>();
    private final Map<String, Double> livePrices = new HashMap<>();

    private HoldingsAdapter holdingsAdapter;

    private double latestCashBalance = 0.0;
    private boolean loadingPortfolio = false;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        AppSettingsManager.applySavedUi(this);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_simple_portfolio);

        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        bindViews();
        setupRecycler();
        setupClicks();
        setupBottomNav();
        hideLegacyPlusButtons();
        renderRecentActivity();
    }

    @Override
    protected void onResume() {
        super.onResume();
        AppSettingsManager.syncSettingsForCurrentUser(this);
        loadPortfolio();
    }

    private void bindViews() {
        tvPortfolioValue = findViewById(R.id.tvPortfolioValue);
        tvCashBalance = findViewById(R.id.tvCashBalance);
        tvHoldingsCount = findViewById(R.id.tvHoldingsCount);
        tvPortfolioRefresh = findViewById(R.id.tvPortfolioRefresh);
        tvPortfolioRefreshIcon = findViewById(R.id.tvPortfolioRefreshIcon);
        tvActivityRefresh = findViewById(R.id.tvActivityRefresh);
        tvEmptyPortfolio = findViewById(R.id.tvEmptyPortfolio);
        tvEmptyActivity = findViewById(R.id.tvEmptyActivity);

        btnBuyStocks = findViewById(R.id.btnBuyStocks);

        layoutRecentActivity = findViewById(R.id.layoutRecentActivity);

        recyclerHoldings = findViewById(R.id.recyclerHoldings);
        bottomNav = findViewById(R.id.bottomNav);
    }

    private void setupRecycler() {
        holdingsAdapter = new HoldingsAdapter(holdings, this::openHoldingActions);

        if (recyclerHoldings != null) {
            recyclerHoldings.setLayoutManager(new LinearLayoutManager(this));
            recyclerHoldings.setAdapter(holdingsAdapter);
            recyclerHoldings.setNestedScrollingEnabled(false);
            recyclerHoldings.setHasFixedSize(false);
            recyclerHoldings.setItemAnimator(null);
        }
    }

    private void setupClicks() {
        if (tvPortfolioRefresh != null) {
            tvPortfolioRefresh.setOnClickListener(v -> loadPortfolio());
        }

        if (tvActivityRefresh != null) {
            tvActivityRefresh.setOnClickListener(v -> {
                PortfolioActivityLogger.syncSnapshot(this, latestCashBalance, holdings);
                renderRecentActivity();
            });
        }

        if (btnBuyStocks != null) {
            btnBuyStocks.setOnClickListener(v -> openBuyFlow());
        }
    }

    private void setupBottomNav() {
        if (bottomNav != null) {
            NavBarUtil.setup(this, bottomNav, R.id.nav_portfolio);
        }
    }

    private void loadPortfolio() {
        if (loadingPortfolio) {
            return;
        }

        loadingPortfolio = true;
        setRefreshLoading(true);

        PortfolioManager.getInstance().fetchPortfolio((portfolio, errorMessage) -> {
            runOnUiThread(() -> {
                loadingPortfolio = false;
                setRefreshLoading(false);

                if (portfolio == null) {
                    latestCashBalance = 0.0;
                    holdings.clear();
                    livePrices.clear();

                    if (holdingsAdapter != null) {
                        holdingsAdapter.notifyDataSetChanged();
                    }

                    updateSummary();
                    updateEmptyState();
                    renderRecentActivity();
                    return;
                }

                latestCashBalance = portfolio.cashBalance;

                holdings.clear();
                livePrices.clear();

                if (portfolio.holdings != null) {
                    holdings.addAll(portfolio.holdings);
                }

                PortfolioActivityLogger.syncSnapshot(this, latestCashBalance, holdings);

                if (holdingsAdapter != null) {
                    holdingsAdapter.notifyDataSetChanged();
                }

                updateSummary();
                updateEmptyState();
                renderRecentActivity();
                fetchLivePricesForHoldings();
            });
        });
    }

    private void updateSummary() {
        double holdingsValue = calculateHoldingsValue();
        double totalPortfolioValue = latestCashBalance + holdingsValue;

        if (tvPortfolioValue != null) {
            AppSettingsManager.formatUsdAmountAsync(
                    this,
                    totalPortfolioValue,
                    formatted -> tvPortfolioValue.setText(formatted)
            );
        }

        if (tvCashBalance != null) {
            AppSettingsManager.formatUsdAmountAsync(
                    this,
                    latestCashBalance,
                    formatted -> tvCashBalance.setText(formatted)
            );
        }

        if (tvHoldingsCount != null) {
            tvHoldingsCount.setText(String.valueOf(holdings.size()));
        }
    }

    private double calculateHoldingsValue() {
        double value = 0.0;

        for (PortfolioManager.Holding holding : holdings) {
            if (holding == null) {
                continue;
            }

            String symbol = cleanSymbol(holding.symbol);
            Double live = livePrices.get(symbol);
            double price = live != null && live > 0.0 ? live : holding.avgBuyPrice;

            value += holding.quantity * price;
        }

        return value;
    }

    private void updateEmptyState() {
        boolean empty = holdings.isEmpty();

        if (tvEmptyPortfolio != null) {
            tvEmptyPortfolio.setVisibility(empty ? View.VISIBLE : View.GONE);
        }

        if (recyclerHoldings != null) {
            recyclerHoldings.setVisibility(empty ? View.GONE : View.VISIBLE);
        }
    }

    private void fetchLivePricesForHoldings() {
        for (final PortfolioManager.Holding holding : holdings) {
            if (holding == null || holding.symbol == null || holding.symbol.trim().isEmpty()) {
                continue;
            }

            final String symbol = cleanSymbol(holding.symbol);

            new Thread(() -> {
                Double price = AlphaVantageClient.getLastPrice(symbol);

                if (price == null || price <= 0.0) {
                    return;
                }

                runOnUiThread(() -> {
                    livePrices.put(symbol, price);

                    if (holdingsAdapter != null) {
                        holdingsAdapter.updatePrice(symbol, price);
                    }

                    updateSummary();
                });
            }).start();
        }
    }

    private void renderRecentActivity() {
        if (layoutRecentActivity == null) {
            return;
        }

        layoutRecentActivity.removeAllViews();

        List<PortfolioActivityLogger.Entry> entries = PortfolioActivityLogger.getRecent(this, 20);

        boolean empty = entries.isEmpty();

        if (tvEmptyActivity != null) {
            tvEmptyActivity.setVisibility(empty ? View.VISIBLE : View.GONE);
        }

        if (empty) {
            return;
        }

        for (PortfolioActivityLogger.Entry entry : entries) {
            layoutRecentActivity.addView(createActivityRow(entry));
        }
    }

    private View createActivityRow(PortfolioActivityLogger.Entry entry) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(15), dp(14), dp(15), dp(14));
        card.setBackground(makeRoundedDrawable(
                Color.rgb(11, 20, 36),
                dp(24),
                Color.rgb(42, 62, 96)
        ));

        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        cardParams.bottomMargin = dp(12);
        card.setLayoutParams(cardParams);

        TextView icon = new TextView(this);
        icon.setGravity(Gravity.CENTER);
        icon.setTextSize(18);
        icon.setTypeface(null, Typeface.BOLD);
        icon.setTextColor(Color.WHITE);
        icon.setText(getActivityIcon(entry.type));
        icon.setBackground(makeRoundedDrawable(
                getActivityColor(entry.type),
                dp(18),
                getActivityColor(entry.type)
        ));

        LinearLayout.LayoutParams iconParams = new LinearLayout.LayoutParams(dp(42), dp(42));
        iconParams.rightMargin = dp(13);
        card.addView(icon, iconParams);

        LinearLayout textWrap = new LinearLayout(this);
        textWrap.setOrientation(LinearLayout.VERTICAL);

        TextView title = new TextView(this);
        title.setText(entry.title);
        title.setTextColor(Color.WHITE);
        title.setTextSize(15);
        title.setTypeface(null, Typeface.BOLD);

        TextView subtitle = new TextView(this);
        subtitle.setText(entry.subtitle);
        subtitle.setTextColor(Color.rgb(143, 163, 196));
        subtitle.setTextSize(12);
        subtitle.setPadding(0, dp(4), 0, 0);

        TextView time = new TextView(this);
        time.setText(entry.getRelativeTime());
        time.setTextColor(Color.rgb(104, 125, 160));
        time.setTextSize(11);
        time.setPadding(0, dp(4), 0, 0);

        textWrap.addView(title);
        textWrap.addView(subtitle);
        textWrap.addView(time);

        card.addView(textWrap, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        TextView amount = new TextView(this);
        amount.setText(entry.amountText);
        amount.setTextColor(entry.amountText.startsWith("-")
                ? Color.rgb(255, 120, 140)
                : Color.rgb(72, 230, 145));
        amount.setTextSize(14);
        amount.setTypeface(null, Typeface.BOLD);
        amount.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);

        LinearLayout.LayoutParams amountParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        amountParams.leftMargin = dp(10);
        card.addView(amount, amountParams);

        return card;
    }

    private String getActivityIcon(String type) {
        if ("money_in".equals(type)) {
            return "+";
        }

        if ("money_out".equals(type)) {
            return "-";
        }

        if ("buy".equals(type)) {
            return "B";
        }

        if ("sell".equals(type)) {
            return "S";
        }

        return "•";
    }

    private int getActivityColor(String type) {
        if ("money_in".equals(type)) {
            return Color.rgb(22, 130, 78);
        }

        if ("money_out".equals(type)) {
            return Color.rgb(185, 50, 72);
        }

        if ("buy".equals(type)) {
            return Color.rgb(49, 93, 255);
        }

        if ("sell".equals(type)) {
            return Color.rgb(245, 120, 45);
        }

        return Color.rgb(60, 80, 115);
    }

    private void openHoldingActions(PortfolioManager.Holding holding, Double lastPrice) {
        if (holding == null) {
            return;
        }

        String symbol = cleanSymbol(holding.symbol);
        double currentPrice = lastPrice != null && lastPrice > 0.0
                ? lastPrice
                : livePrices.containsKey(symbol)
                ? livePrices.get(symbol)
                : holding.avgBuyPrice;

        BottomSheetDialog dialog = new BottomSheetDialog(this);
        View sheet = getLayoutInflater().inflate(R.layout.bottomsheet_holding_actions, null, false);
        dialog.setContentView(sheet);

        ImageView ivLogo = sheet.findViewById(R.id.ivHoldingActionLogo);
        TextView tvSymbol = sheet.findViewById(R.id.tvHoldingActionSymbol);
        TextView tvShares = sheet.findViewById(R.id.tvHoldingActionShares);
        TextView tvBoughtAt = sheet.findViewById(R.id.tvHoldingActionBoughtAt);
        TextView tvNow = sheet.findViewById(R.id.tvHoldingActionNow);
        TextView tvBuyMore = sheet.findViewById(R.id.btnHoldingBuyMore);
        TextView tvSell = sheet.findViewById(R.id.btnHoldingSell);

        if (ivLogo != null) {
            StockLogoMapper.bind(ivLogo, symbol);
        }

        if (tvSymbol != null) {
            tvSymbol.setText(symbol);
        }

        if (tvShares != null) {
            tvShares.setText("Shares  " + formatQty(holding.quantity));
        }

        if (tvBoughtAt != null) {
            AppSettingsManager.formatUsdAmountAsync(
                    this,
                    holding.avgBuyPrice,
                    formatted -> tvBoughtAt.setText("Bought at  " + formatted)
            );
        }

        if (tvNow != null) {
            AppSettingsManager.formatUsdAmountAsync(
                    this,
                    currentPrice,
                    formatted -> tvNow.setText("Now  " + formatted)
            );
        }

        if (tvBuyMore != null) {
            tvBuyMore.setOnClickListener(v -> {
                dialog.dismiss();

                TradeBottomSheet.show(
                        this,
                        symbol,
                        getCompanyName(symbol),
                        currentPrice,
                        TradeBottomSheet.Mode.BUY,
                        this::loadPortfolio
                );
            });
        }

        if (tvSell != null) {
            tvSell.setOnClickListener(v -> {
                dialog.dismiss();

                TradeBottomSheet.show(
                        this,
                        symbol,
                        getCompanyName(symbol),
                        currentPrice,
                        TradeBottomSheet.Mode.SELL,
                        this::loadPortfolio
                );
            });
        }

        dialog.show();
    }

    private void setRefreshLoading(boolean loading) {
        if (tvPortfolioRefresh == null) {
            return;
        }

        tvPortfolioRefresh.setText(loading ? "Refreshing" : "Refresh");
        tvPortfolioRefresh.setEnabled(!loading);
        tvPortfolioRefresh.setAlpha(loading ? 0.78f : 1f);

        if (tvPortfolioRefreshIcon != null) {
            tvPortfolioRefreshIcon.setEnabled(!loading);
            tvPortfolioRefreshIcon.setAlpha(loading ? 0.78f : 1f);

            if (loading) {
                tvPortfolioRefreshIcon.animate()
                        .cancel();

                tvPortfolioRefreshIcon.setRotation(0f);
                tvPortfolioRefreshIcon.animate()
                        .rotationBy(360f)
                        .setDuration(650)
                        .withEndAction(() -> {
                            if (loadingPortfolio && tvPortfolioRefreshIcon != null) {
                                tvPortfolioRefreshIcon.setRotation(0f);
                                tvPortfolioRefreshIcon.animate()
                                        .rotationBy(360f)
                                        .setDuration(650)
                                        .start();
                            }
                        })
                        .start();
            } else {
                tvPortfolioRefreshIcon.animate().cancel();
                tvPortfolioRefreshIcon.setRotation(0f);
            }
        }

        if (tvPortfolioRefresh.getParent() instanceof View) {
            View parent = (View) tvPortfolioRefresh.getParent();
            parent.setEnabled(!loading);
            parent.setAlpha(loading ? 0.78f : 1f);
        }
    }

    private void hideLegacyPlusButtons() {
        String[] ids = new String[]{
                "fabAddStock",
                "fabAddHolding",
                "btnAddStock",
                "btnAddHolding",
                "ivAddStock",
                "ivAddHolding",
                "btnPlus",
                "fabPlus",
                "btnAddPortfolio",
                "fabPortfolioAdd",
                "imageAddStock",
                "plusButton",
                "fabTrade"
        };

        for (String name : ids) {
            int id = getResources().getIdentifier(name, "id", getPackageName());

            if (id == 0) {
                continue;
            }

            View view = findViewById(id);

            if (view != null) {
                view.setVisibility(View.GONE);
                view.setEnabled(false);
                view.setClickable(false);
            }
        }
    }

    private void openBuyFlow() {
        Intent intent = new Intent(this, StocksActivity.class);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
    }

    private String cleanSymbol(String raw) {
        if (raw == null || raw.trim().isEmpty()) {
            return "-";
        }

        return raw.trim().toUpperCase(Locale.US);
    }

    private String formatQty(double value) {
        String raw = String.format(Locale.US, "%.4f", value);

        while (raw.contains(".") && (raw.endsWith("0") || raw.endsWith("."))) {
            raw = raw.substring(0, raw.length() - 1);
        }

        return raw;
    }

    private String getCompanyName(String symbol) {
        String s = cleanSymbol(symbol);

        switch (s) {
            case "AAPL":
                return "Apple";
            case "MSFT":
                return "Microsoft";
            case "NVDA":
                return "NVIDIA";
            case "META":
                return "Meta";
            case "NFLX":
                return "Netflix";
            case "GOOGL":
            case "GOOG":
                return "Alphabet";
            case "AMZN":
                return "Amazon";
            case "TSLA":
                return "Tesla";
            case "AMD":
                return "AMD";
            case "INTC":
                return "Intel";
            case "RDDT":
                return "Reddit";
            default:
                return s;
        }
    }

    private GradientDrawable makeRoundedDrawable(int color, int radius, int strokeColor) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(radius);
        drawable.setStroke(dp(1), strokeColor);
        return drawable;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}