package com.example.yoavsproject;

import android.content.Context;
import android.text.TextUtils;
import android.widget.ImageView;

import androidx.annotation.Nullable;

import java.util.Locale;

public final class StockLogoMapper {

    private StockLogoMapper() {
    }

    public static int getLogoResId(Context context, @Nullable String symbol) {
        if (context == null || TextUtils.isEmpty(symbol)) {
            return R.drawable.ic_stock_placeholder;
        }

        String clean = symbol.trim().toLowerCase(Locale.US);

        String[] possibleNames = new String[]{
                clean,
                "ic_" + clean,
                "logo_" + clean,
                "stock_" + clean,
                "ic_stock_" + clean
        };

        for (String name : possibleNames) {
            int id = context.getResources().getIdentifier(
                    name,
                    "drawable",
                    context.getPackageName()
            );

            if (id != 0) {
                return id;
            }
        }

        return R.drawable.ic_stock_placeholder;
    }

    public static boolean hasDedicatedLogo(ImageView imageView, @Nullable String symbol) {
        if (imageView == null) {
            return false;
        }

        int id = getLogoResId(imageView.getContext(), symbol);

        return id != R.drawable.ic_stock_placeholder;
    }

    public static void bind(ImageView imageView, @Nullable String symbol) {
        if (imageView == null) {
            return;
        }

        int logoId = getLogoResId(imageView.getContext(), symbol);

        imageView.clearColorFilter();
        imageView.setImageResource(logoId);
        imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);

        int padding = logoId == R.drawable.ic_stock_placeholder
                ? dp(imageView, 10)
                : dp(imageView, 5);

        imageView.setPadding(padding, padding, padding, padding);
    }

    private static int dp(ImageView view, int value) {
        return Math.round(value * view.getResources().getDisplayMetrics().density);
    }
}