package com.example.yoavsproject;

import android.text.method.LinkMovementMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.airbnb.lottie.LottieAnimationView;

import java.util.List;





public class AiChatAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    public interface ArticleActionListener {
        void onOpenArticle(AiChatMessage message);
    }

    private final List<AiChatMessage> messages;
    private final ArticleActionListener listener;

    public AiChatAdapter(List<AiChatMessage> messages, ArticleActionListener listener) {
        this.messages = messages;
        this.listener = listener;
    }

    @Override
    public int getItemViewType(int position) {
        return messages.get(position).type;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        if (viewType == AiChatMessage.TYPE_USER) {
            return new UserVH(inflater.inflate(R.layout.item_ai_message_user, parent, false));
        } else if (viewType == AiChatMessage.TYPE_AI) {
            return new AiVH(inflater.inflate(R.layout.item_ai_message_ai, parent, false));
        } else if (viewType == AiChatMessage.TYPE_ARTICLE) {
            return new ArticleVH(inflater.inflate(R.layout.item_ai_article, parent, false));
        } else {
            return new ThinkingVH(inflater.inflate(R.layout.item_ai_thinking, parent, false));
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        final AiChatMessage msg = messages.get(position);

        if (holder instanceof UserVH) {
            ((UserVH) holder).tvText.setText(MarkdownTextUtil.toRichText(msg.text));
        } else if (holder instanceof AiVH) {
            ((AiVH) holder).tvText.setText(MarkdownTextUtil.toRichText(msg.text));
        } else if (holder instanceof ThinkingVH) {
            ((ThinkingVH) holder).lottie.playAnimation();
        } else if (holder instanceof ArticleVH) {
            ArticleVH vh = (ArticleVH) holder;
            vh.tvTitle.setText(msg.title == null ? "" : msg.title);
            vh.tvSubtitle.setText(msg.subtitle == null ? "" : msg.subtitle);
            vh.tvBody.setText(MarkdownTextUtil.toRichText(msg.body == null ? "" : msg.body));
            vh.tvBody.setMovementMethod(LinkMovementMethod.getInstance());

            String imageUrl = cleanImageUrl(msg.imageUrl);

            if (!imageUrl.isEmpty()) {
                vh.ivArticle.setVisibility(View.VISIBLE);
                com.bumptech.glide.Glide.with(vh.itemView.getContext())
                        .load(imageUrl)
                        .placeholder(R.drawable.ic_article_placeholder)
                        .error(R.drawable.ic_article_placeholder)
                        .fallback(R.drawable.ic_article_placeholder)
                        .centerCrop()
                        .dontAnimate()
                        .into(vh.ivArticle);
            } else {
                vh.ivArticle.setVisibility(View.GONE);
                vh.ivArticle.setImageDrawable(null);
            }

            vh.btnOpenArticle.setOnClickListener(v -> {
                if (listener != null) listener.onOpenArticle(msg);
            });

            vh.itemView.setOnClickListener(v -> {
                if (listener != null) listener.onOpenArticle(msg);
            });
        }
    }

    @Override
    public int getItemCount() {
        return messages == null ? 0 : messages.size();
    }

    private static String cleanImageUrl(String value) {
        if (value == null) {
            return "";
        }

        String clean = value.trim();

        if (clean.isEmpty()) {
            return "";
        }

        if ("null".equalsIgnoreCase(clean)
                || "none".equalsIgnoreCase(clean)
                || "undefined".equalsIgnoreCase(clean)
                || "n/a".equalsIgnoreCase(clean)) {
            return "";
        }

        String lower = clean.toLowerCase();

        if (!lower.startsWith("http://") && !lower.startsWith("https://")) {
            return "";
        }

        return clean;
    }

    static class UserVH extends RecyclerView.ViewHolder {
        final TextView tvText;
        UserVH(@NonNull View itemView) {
            super(itemView);
            tvText = itemView.findViewById(R.id.tvAiMessageUser);
        }
    }

    static class AiVH extends RecyclerView.ViewHolder {
        final TextView tvText;
        AiVH(@NonNull View itemView) {
            super(itemView);
            tvText = itemView.findViewById(R.id.tvAiMessageBot);
        }
    }

    static class ThinkingVH extends RecyclerView.ViewHolder {
        final LottieAnimationView lottie;
        ThinkingVH(@NonNull View itemView) {
            super(itemView);
            lottie = itemView.findViewById(R.id.lottieThinking);
        }
    }

    static class ArticleVH extends RecyclerView.ViewHolder {
        final ImageView ivArticle;
        final TextView tvTitle;
        final TextView tvSubtitle;
        final TextView tvBody;
        final TextView btnOpenArticle;

        ArticleVH(@NonNull View itemView) {
            super(itemView);
            ivArticle = itemView.findViewById(R.id.ivAiArticle);
            tvTitle = itemView.findViewById(R.id.tvAiArticleTitle);
            tvSubtitle = itemView.findViewById(R.id.tvAiArticleSubtitle);
            tvBody = itemView.findViewById(R.id.tvAiArticleBody);
            btnOpenArticle = itemView.findViewById(R.id.btnOpenAiArticle);
        }
    }
}
