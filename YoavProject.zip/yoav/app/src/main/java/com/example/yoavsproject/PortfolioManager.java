package com.example.yoavsproject;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.SetOptions;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class PortfolioManager {

    private static final double STARTER_BALANCE = 10000.0;

    private static PortfolioManager instance;

    public static synchronized PortfolioManager getInstance() {
        if (instance == null) {
            instance = new PortfolioManager();
        }

        return instance;
    }

    private final FirebaseAuth auth = FirebaseAuth.getInstance();
    private final FirebaseFirestore db = FirebaseFirestore.getInstance();

    private PortfolioManager() {
    }

    public static class Holding {
        public String symbol;
        public double quantity;
        public double avgBuyPrice;

        public Holding() {
        }

        public Holding(String symbol, double quantity, double avgBuyPrice) {
            this.symbol = symbol;
            this.quantity = quantity;
            this.avgBuyPrice = avgBuyPrice;
        }
    }

    public static class HistoryEntry {
        public String type;
        public String symbol;
        public double quantity;
        public double price;
        public double amount;
        public double balanceAfter;
        public Timestamp timestamp;

        public HistoryEntry() {
        }
    }

    public static class Portfolio {
        public double cashBalance;
        public List<Holding> holdings = new ArrayList<>();
        public List<HistoryEntry> history = new ArrayList<>();
    }

    public interface SimpleCallback {
        void onComplete(boolean success, String message);
    }

    public interface PortfolioCallback {
        void onResult(Portfolio portfolio, String errorMessage);
    }

    public interface CashCallback {
        void onResult(double cashBalance, String errorMessage);
    }

    public interface HoldingQuantityCallback {
        void onResult(double quantity, String errorMessage);
    }

    private FirebaseUser userOrNull() {
        return auth.getCurrentUser();
    }

    private DocumentReference userDoc() {
        FirebaseUser user = userOrNull();

        if (user == null) {
            return null;
        }

        return db.collection("users").document(user.getUid());
    }

    private CollectionReference holdingsCol() {
        DocumentReference user = userDoc();
        return user.collection("holdings");
    }

    private CollectionReference historyCol() {
        DocumentReference user = userDoc();
        return user.collection("history");
    }

    private Task<Void> ensureUserDoc() {
        DocumentReference user = userDoc();

        if (user == null) {
            return Tasks.forException(new Exception("Not logged in"));
        }

        return user.get().continueWithTask(task -> {
            if (!task.isSuccessful()) {
                return Tasks.forException(task.getException());
            }

            DocumentSnapshot snapshot = task.getResult();

            if (snapshot == null || !snapshot.exists()) {
                Map<String, Object> init = buildCashPatch(STARTER_BALANCE);
                init.put("createdAt", FieldValue.serverTimestamp());
                init.put("starterBonusReceived", true);
                init.put("starterBonusAmount", STARTER_BALANCE);
                return user.set(init, SetOptions.merge());
            }

            double cash = readCash(snapshot, Double.NaN);

            if (!Double.isNaN(cash)) {
                return Tasks.forResult(null);
            }

            return user.set(buildCashPatch(0.0), SetOptions.merge());
        });
    }

    public void fetchPortfolio(@NonNull PortfolioCallback callback) {
        DocumentReference user = userDoc();

        if (user == null) {
            callback.onResult(null, "Not logged in");
            return;
        }

        ensureUserDoc()
                .continueWithTask(task -> user.get())
                .addOnSuccessListener(snapshot -> {
                    Portfolio portfolio = new Portfolio();
                    portfolio.cashBalance = readCash(snapshot, 0.0);

                    holdingsCol()
                            .get()
                            .addOnSuccessListener(holdingsSnapshot -> {
                                portfolio.holdings.clear();

                                for (DocumentSnapshot doc : holdingsSnapshot.getDocuments()) {
                                    String symbol = doc.getId();
                                    Double qty = doc.getDouble("quantity");
                                    Double avg = doc.getDouble("avgBuyPrice");

                                    portfolio.holdings.add(new Holding(
                                            symbol,
                                            qty == null ? 0.0 : qty,
                                            avg == null ? 0.0 : avg
                                    ));
                                }

                                loadHistoryThenReturn(portfolio, callback);
                            })
                            .addOnFailureListener(e -> {
                                
                                loadHistoryThenReturn(portfolio, callback);
                            });
                })
                .addOnFailureListener(e -> callback.onResult(null, safeMessage(e)));
    }

    private void loadHistoryThenReturn(@NonNull Portfolio portfolio, @NonNull PortfolioCallback callback) {
        historyCol()
                .orderBy("timestamp", Query.Direction.DESCENDING)
                .limit(30)
                .get()
                .addOnSuccessListener(historySnapshot -> {
                    portfolio.history.clear();

                    for (DocumentSnapshot doc : historySnapshot.getDocuments()) {
                        HistoryEntry entry = doc.toObject(HistoryEntry.class);

                        if (entry != null) {
                            portfolio.history.add(entry);
                        }
                    }

                    callback.onResult(portfolio, null);
                })
                .addOnFailureListener(e -> {
                    
                    callback.onResult(portfolio, null);
                });
    }

    public void fetchCashBalance(@NonNull CashCallback callback) {
        DocumentReference user = userDoc();

        if (user == null) {
            callback.onResult(0.0, "Not logged in");
            return;
        }

        ensureUserDoc()
                .continueWithTask(task -> user.get())
                .addOnSuccessListener(snapshot -> callback.onResult(readCash(snapshot, 0.0), null))
                .addOnFailureListener(e -> callback.onResult(0.0, safeMessage(e)));
    }

    public void fetchHoldingQuantity(@NonNull String symbol, @NonNull HoldingQuantityCallback callback) {
        DocumentReference user = userDoc();

        if (user == null) {
            callback.onResult(0.0, "Not logged in");
            return;
        }

        String upperSymbol = symbol.trim().toUpperCase(Locale.US);
        DocumentReference holdingRef = holdingsCol().document(upperSymbol);

        ensureUserDoc()
                .continueWithTask(task -> holdingRef.get())
                .addOnSuccessListener(snapshot -> {
                    if (snapshot == null || !snapshot.exists()) {
                        callback.onResult(0.0, null);
                        return;
                    }

                    Double quantity = snapshot.getDouble("quantity");
                    callback.onResult(quantity == null ? 0.0 : quantity, null);
                })
                .addOnFailureListener(e -> callback.onResult(0.0, safeMessage(e)));
    }

    public void buyStock(String symbol, double quantity, double price, @NonNull SimpleCallback callback) {
        trade("BUY", symbol, quantity, price, callback);
    }

    public void sellStock(String symbol, double quantity, double price, @NonNull SimpleCallback callback) {
        trade("SELL", symbol, quantity, price, callback);
    }

    private void trade(String type, String symbol, double quantity, double price, @NonNull SimpleCallback callback) {
        if (symbol == null || symbol.trim().isEmpty()) {
            callback.onComplete(false, "Missing symbol");
            return;
        }

        if (quantity <= 0) {
            callback.onComplete(false, "Quantity must be greater than 0");
            return;
        }

        if (price <= 0) {
            callback.onComplete(false, "Price must be greater than 0");
            return;
        }

        DocumentReference user = userDoc();

        if (user == null) {
            callback.onComplete(false, "Not logged in");
            return;
        }

        String upperSymbol = symbol.trim().toUpperCase(Locale.US);
        DocumentReference holdingRef = holdingsCol().document(upperSymbol);
        DocumentReference historyRef = historyCol().document();

        ensureUserDoc()
                .continueWithTask(task ->
                        db.runTransaction(transaction -> {
                            DocumentSnapshot userSnapshot = transaction.get(user);
                            double cashBalance = readCash(userSnapshot, 0.0);

                            DocumentSnapshot holdingSnapshot = transaction.get(holdingRef);
                            double oldQty = 0.0;
                            double oldAvg = 0.0;

                            if (holdingSnapshot.exists()) {
                                Double q = holdingSnapshot.getDouble("quantity");
                                Double a = holdingSnapshot.getDouble("avgBuyPrice");

                                oldQty = q == null ? 0.0 : q;
                                oldAvg = a == null ? 0.0 : a;
                            }

                            double amount = quantity * price;

                            if ("BUY".equals(type)) {
                                if (cashBalance + 0.000001d < amount) {
                                    throw new RuntimeException(buildInsufficientCashMessage(cashBalance, amount));
                                }

                                double newCash = cashBalance - amount;
                                double newQty = oldQty + quantity;
                                double newAvg = newQty <= 0.0
                                        ? 0.0
                                        : ((oldQty * oldAvg) + (quantity * price)) / newQty;

                                transaction.set(user, buildCashPatch(newCash), SetOptions.merge());

                                Map<String, Object> holdingData = new HashMap<>();
                                holdingData.put("quantity", newQty);
                                holdingData.put("avgBuyPrice", newAvg);
                                holdingData.put("updatedAt", FieldValue.serverTimestamp());
                                transaction.set(holdingRef, holdingData, SetOptions.merge());

                                Map<String, Object> historyData = new HashMap<>();
                                historyData.put("type", "BUY");
                                historyData.put("symbol", upperSymbol);
                                historyData.put("quantity", quantity);
                                historyData.put("price", price);
                                historyData.put("amount", -amount);
                                historyData.put("balanceAfter", newCash);
                                historyData.put("timestamp", FieldValue.serverTimestamp());
                                transaction.set(historyRef, historyData);

                            } else {
                                if (oldQty + 0.000001d < quantity) {
                                    throw new RuntimeException(buildInsufficientSharesMessage(oldQty, quantity, upperSymbol));
                                }

                                double newQty = oldQty - quantity;
                                double newCash = cashBalance + amount;

                                transaction.set(user, buildCashPatch(newCash), SetOptions.merge());

                                if (newQty <= 0.0000001d) {
                                    transaction.delete(holdingRef);
                                } else {
                                    Map<String, Object> holdingData = new HashMap<>();
                                    holdingData.put("quantity", newQty);
                                    holdingData.put("avgBuyPrice", oldAvg);
                                    holdingData.put("updatedAt", FieldValue.serverTimestamp());
                                    transaction.set(holdingRef, holdingData, SetOptions.merge());
                                }

                                Map<String, Object> historyData = new HashMap<>();
                                historyData.put("type", "SELL");
                                historyData.put("symbol", upperSymbol);
                                historyData.put("quantity", quantity);
                                historyData.put("price", price);
                                historyData.put("amount", amount);
                                historyData.put("balanceAfter", newCash);
                                historyData.put("timestamp", FieldValue.serverTimestamp());
                                transaction.set(historyRef, historyData);
                            }

                            return null;
                        })
                )
                .addOnSuccessListener(unused -> {
                    if ("BUY".equals(type)) {
                        callback.onComplete(true, "Purchase completed");
                    } else {
                        callback.onComplete(true, "Sale completed");
                    }
                })
                .addOnFailureListener(e -> callback.onComplete(false, safeMessage(e)));
    }

    public void deposit(double amount, @NonNull SimpleCallback callback) {
        cashMove("DEPOSIT", amount, callback);
    }

    public void withdraw(double amount, @NonNull SimpleCallback callback) {
        cashMove("WITHDRAW", amount, callback);
    }

    private void cashMove(String type, double amount, @NonNull SimpleCallback callback) {
        if (amount <= 0) {
            callback.onComplete(false, "Amount must be greater than 0");
            return;
        }

        DocumentReference user = userDoc();

        if (user == null) {
            callback.onComplete(false, "Not logged in");
            return;
        }

        DocumentReference historyRef = historyCol().document();

        ensureUserDoc()
                .continueWithTask(task ->
                        db.runTransaction(transaction -> {
                            DocumentSnapshot userSnapshot = transaction.get(user);
                            double cashBalance = readCash(userSnapshot, 0.0);

                            if ("WITHDRAW".equals(type) && cashBalance + 0.000001d < amount) {
                                throw new RuntimeException(buildInsufficientCashMessage(cashBalance, amount));
                            }

                            double newCash = "DEPOSIT".equals(type)
                                    ? cashBalance + amount
                                    : cashBalance - amount;

                            transaction.set(user, buildCashPatch(newCash), SetOptions.merge());

                            Map<String, Object> historyData = new HashMap<>();
                            historyData.put("type", type);
                            historyData.put("amount", "DEPOSIT".equals(type) ? amount : -amount);
                            historyData.put("balanceAfter", newCash);
                            historyData.put("timestamp", FieldValue.serverTimestamp());
                            transaction.set(historyRef, historyData);

                            return null;
                        })
                )
                .addOnSuccessListener(unused ->
                        callback.onComplete(true, "DEPOSIT".equals(type) ? "Money added" : "Money withdrawn"))
                .addOnFailureListener(e -> callback.onComplete(false, safeMessage(e)));
    }

    private double readCash(DocumentSnapshot snapshot, double fallback) {
        if (snapshot == null) {
            return fallback;
        }

        Double cashBalance = snapshot.getDouble("cashBalance");

        if (cashBalance != null) {
            return cashBalance;
        }

        Double availableCash = snapshot.getDouble("availableCash");

        if (availableCash != null) {
            return availableCash;
        }

        Double availableBalance = snapshot.getDouble("availableBalance");

        if (availableBalance != null) {
            return availableBalance;
        }

        Double buyingPower = snapshot.getDouble("buyingPower");

        if (buyingPower != null) {
            return buyingPower;
        }

        Double balance = snapshot.getDouble("balance");

        if (balance != null) {
            return balance;
        }

        return fallback;
    }

    @NonNull
    private Map<String, Object> buildCashPatch(double value) {
        Map<String, Object> patch = new HashMap<>();
        patch.put("cashBalance", value);
        patch.put("availableCash", value);
        patch.put("availableBalance", value);
        patch.put("buyingPower", value);
        patch.put("balance", value);
        patch.put("balanceUpdatedAt", FieldValue.serverTimestamp());
        return patch;
    }

    private String buildInsufficientCashMessage(double cashBalance, double amount) {
        double missing = Math.max(0.0d, amount - cashBalance);
        return "Not enough cash. Available " + formatUsd(cashBalance)
                + ", required " + formatUsd(amount)
                + ", missing " + formatUsd(missing);
    }

    private String buildInsufficientSharesMessage(double owned, double requested, String symbol) {
        double missing = Math.max(0.0d, requested - owned);
        return "Not enough " + symbol + " shares. You have "
                + formatQty(owned) + ", tried to sell "
                + formatQty(requested) + ", missing "
                + formatQty(missing);
    }

    private static String safeMessage(Throwable throwable) {
        if (throwable == null) {
            return "Action failed";
        }

        String message = throwable.getMessage();

        if (message == null || message.trim().isEmpty()) {
            return "Action failed";
        }

        return message.trim();
    }

    private String formatUsd(double value) {
        return String.format(Locale.US, "$%,.2f", value);
    }

    private String formatQty(double value) {
        String raw = String.format(Locale.US, "%.4f", value);

        while (raw.contains(".") && (raw.endsWith("0") || raw.endsWith("."))) {
            raw = raw.substring(0, raw.length() - 1);
        }

        return raw;
    }
}
